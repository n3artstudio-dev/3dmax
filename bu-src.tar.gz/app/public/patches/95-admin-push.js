/* ============================================================
   گیمیفای ۲ — تب «🔔 اعلان‌های گوشی» در پنل مدیریت (نسخهٔ ۱)
   این فایل به پنل موجود (90-admin.js) یک تب تازه اضافه می‌کند:
     • آمار زنده (چند مرورگر، چند گوشی، صف، خطاها)
     • ارسال اعلان به همه/واقعی/مهمان/دارای اعلان/آنلاین/یک کاربر
     • پیش‌نمایش همان اعلانی که روی گوشی می‌افتد
     • دکمهٔ اعلان آزمایشی و اجرای فوری صف
     • روشن/خاموش کردن کل سامانه و یادآور روزانهٔ جایزه
   هیچ تغییری در کد پنل قبلی نمی‌دهد؛ فقط یک تب اضافه می‌کند.
   ============================================================ */
(function () {
  "use strict";
  if (window.__gamifiAdminPushV) return;
  window.__gamifiAdminPushV = "95-admin-push v1";

  var TOK_KEY = "gamify2-admin-token";
  var S = { busy: false, stats: null };

  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) { }
    try { if (window.Android && window.Android.toast) return window.Android.toast(m); } catch (e) { }
    alert(m);
  }
  function token() {
    try { if (window.__gamifyAdminToken) { var t = window.__gamifyAdminToken(); if (t) return t; } } catch (e) { }
    try { return localStorage.getItem(TOK_KEY) || ""; } catch (e) { return ""; }
  }
  function api(path, method, body) {
    var h = { "Content-Type": "application/json" };
    var t = token();
    if (t) h["x-admin-token"] = t;
    return fetch(path, {
      method: method || "GET",
      credentials: "include",
      headers: h,
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.text().then(function (txt) {
        var j;
        try { j = JSON.parse(txt); } catch (e) { j = { error: "server " + r.status }; }
        return { status: r.status, body: j };
      });
    }).catch(function () { return { status: 0, body: { error: "network" } }; });
  }

  /* ---------------- پنل ---------------- */

  function bodyEl() {
    var ov = document.getElementById("gm-admin-overlay");
    if (!ov) return null;
    return ov.querySelector(".gm-admin .gamify-body") || ov.querySelector(".gamify-body");
  }

  function tabsEl() {
    var ov = document.getElementById("gm-admin-overlay");
    if (!ov) return null;
    return ov.querySelector(".gm-admin .gm-tabs") || ov.querySelector(".gm-tabs");
  }

  function injectTab() {
    var tabs = tabsEl();
    if (!tabs || tabs.querySelector("[data-gmpush-tab]")) return;
    var b = document.createElement("button");
    b.className = "gamify-btn sm";
    b.setAttribute("data-gmpush-tab", "1");
    b.textContent = "🔔 اعلان‌های گوشی";
    b.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      show();
    });
    tabs.appendChild(b);
  }

  function linkOptions() {
    return [["", "بدون لینک"], ["feed", "فید"], ["tournaments", "تورنمنت‌ها"], ["tribes", "قبیله‌ها"],
      ["pvp", "نبرد زنده"], ["arena", "مرکز پاداش"], ["leaderboard", "رتبه‌بندی"],
      ["messages", "گفت‌وگو"], ["profile", "پروفایل"], ["shop", "فروشگاه"]];
  }

  function panelHtml() {
    var st = S.stats || {};
    var cards = [
      ["🖥️ مرورگرهای فعال", st.web_active],
      ["📱 اپ‌های فعال", st.devices_active],
      ["🕓 در صف ارسال", st.queue],
      ["⚪ غیرفعال‌شده", st.inactive],
      ["⚠️ خطای اخیر", st.errors],
    ];
    var on = st.enabled !== false;
    var rem = st.dailyReminder !== false;
    var errs = Array.isArray(st.lastErrors) ? st.lastErrors : [];

    var h = "";
    h += '<div class="gm-stats">' + cards.map(function (c) {
      return '<div class="gm-stat"><b>' + fa(c[1]) + "</b><span>" + c[0] + "</span></div>";
    }).join("") + "</div>";

    h += '<div class="gm-card"><b>📣 ارسال اعلان (هم اعلان گوشی، هم صندوق اعلان کاربر)</b>'
      + '<div class="gm-row"><label style="flex:1">عنوان <input data-gp="title" placeholder="مثلاً: مسابقهٔ امشب ساعت ۲۱" maxlength="120" style="width:100%"></label></div>'
      + '<div class="gm-row"><label style="flex:1">متن <input data-gp="body" placeholder="یک خط توضیح" maxlength="500" style="width:100%"></label></div>'
      + '<div class="gm-row">'
      + '<label>لینک <select data-gp="link">' + linkOptions().map(function (l) { return '<option value="' + l[0] + '">' + l[1] + "</option>"; }).join("") + "</select></label>"
      + '<label>مخاطب <select data-gp="target">'
      + '<option value="subs">فقط کسانی که اعلان روشن دارند</option>'
      + '<option value="all">همهٔ کاربران</option>'
      + '<option value="real">فقط کاربران واقعی</option>'
      + '<option value="online">آنلاین‌های ۵ دقیقهٔ اخیر</option>'
      + '<option value="guest">فقط مهمان‌ها</option>'
      + "</select></label>"
      + '<label class="gm-toggle"><input type="checkbox" data-gp="urgent"> فوری (بالای صفحه گوشی)</label>'
      + "</div>"
      + '<div class="gm-row" style="align-items:center;gap:10px">'
      + '<button class="gamify-btn primary" data-gp-send>🚀 ارسال اعلان</button>'
      + '<button class="gamify-btn sm" data-gp-test>🧪 اعلان آزمایشی برای خودم</button>'
      + '<button class="gamify-btn sm" data-gp-tick>🔄 اجرای فوری صف</button>'
      + "</div>"
      + '<p style="font-size:12px;color:#cdbde0;margin:6px 0 0">پیش‌نمایش روی گوشی: <b data-gp-prev-title>—</b><span data-gp-prev-body></span></p>'
      + "</div>";

    h += '<div class="gm-card"><b>⚙️ تنظیمات</b><div class="gm-row">'
      + '<label class="gm-toggle"><input type="checkbox" data-gp-on' + (on ? " checked" : "") + "> کل سامانهٔ اعلان‌ها روشن باشد</label>"
      + '<label class="gm-toggle"><input type="checkbox" data-gp-rem' + (rem ? " checked" : "") + "> یادآور روزانهٔ جایزه (ساعت ۱۹ تهران)</label>"
      + "</div><p style=\"font-size:12px;color:#cdbde0\">اگر سامانه خاموش شود، اعلان‌های داخل بازی و صندوق اعلان همچنان کار می‌کنند؛ فقط اعلان گوشی/مرورگر قطع می‌شود.</p></div>";

    if (errs.length) {
      h += '<div class="gm-card"><b>⚠️ خطاهای اخیر ارسال</b><table><tr><th>سرویس</th><th>کد</th><th>خطا</th><th>زمان</th></tr>'
        + errs.slice().reverse().map(function (e) {
          return "<tr><td dir=\"ltr\">" + esc(e.host) + "</td><td>" + fa(e.status) + "</td><td class=\"wrap\" dir=\"ltr\">" + esc(e.error) + "</td><td>" + ago(e.at) + "</td></tr>";
        }).join("") + "</table></div>";
    }

    h += '<div class="gm-card" style="font-size:12px;color:#cdbde0;line-height:1.9">'
      + "🔔 کاربران با زنگولهٔ پایین صفحهٔ بازی اعلان را روشن می‌کنند؛ در اپ اندروید خودکار فعال است.<br>"
      + "📱 اعلان‌ها حداکثر ۱۵ ثانیه بعد از این‌که در صندوق اعلان کاربر ثبت شوند، فرستاده می‌شوند."
      + "</div>";
    return h;
  }

  function ago(ts) {
    if (!ts) return "—";
    var d = Date.now() - ts;
    if (d < 60000) return "همین حالا";
    if (d < 3600000) return fa(Math.floor(d / 60000)) + " دقیقه پیش";
    if (d < 86400000) return fa(Math.floor(d / 3600000)) + " ساعت پیش";
    return fa(Math.floor(d / 86400000)) + " روز پیش";
  }

  function show() {
    var body = bodyEl();
    if (!body) return;
    if (!token()) {
      body.innerHTML = '<div class="gm-card">برای مدیریت اعلان‌ها اول با کد مدیریت وارد شو.</div>';
      return;
    }
    body.innerHTML = panelHtml();
    bind(body);
    if (!S.stats) refresh();
  }

  function refresh() {
    var body = bodyEl();
    if (!body || !token()) return;
    api("/api/push/admin?view=stats").then(function (r) {
      if (r.status === 403) { toast("⚠️ ورود مدیر لازم است"); return; }
      if (r.body && r.body.ok) { S.stats = r.body; show(); }
    });
  }

  function val(body, name) {
    var el = body.querySelector('[data-gp="' + name + '"]');
    return el ? el.value : "";
  }

  function updatePreview(body) {
    var t = body.querySelector("[data-gp-prev-title]");
    var b = body.querySelector("[data-gp-prev-body]");
    if (t) t.textContent = val(body, "title") || (body.querySelector("[data-gp-test]") ? "—" : "—");
    if (b) b.textContent = (val(body, "body") || "").trim() ? " — " + val(body, "body").trim() : "";
  }

  function bind(body) {
    var send = body.querySelector("[data-gp-send]");
    if (send) send.addEventListener("click", function () {
      if (S.busy) return;
      var title = val(body, "title").trim();
      if (!title) return toast("⚠️ عنوان اعلان را بنویس");
      var target = val(body, "target") || "subs";
      if (target !== "all" && target !== "subs") {
        if (!confirm("مطمئنی می‌خواهی برای این گروه («" + target + "») اعلان بفرستی؟")) return;
      }
      S.busy = true;
      var urgent = body.querySelector('[data-gp="urgent"]');
      api("/api/push/admin?action=broadcast", "POST", {
        title: title,
        body: val(body, "body").trim(),
        link: val(body, "link"),
        target: target,
        urgent: !!(urgent && urgent.checked),
      }).then(function (r) {
        S.busy = false;
        if (r.body && r.body.ok) {
          toast("🚀 اعلان ساخته شد: " + fa(r.body.queued) + " کاربر، " + fa(r.body.pushed) + " ارسال فوری");
          var ti = body.querySelector('[data-gp="title"]'); if (ti) ti.value = "";
          var bo = body.querySelector('[data-gp="body"]'); if (bo) bo.value = "";
          updatePreview(body);
          S.stats = null;
          setTimeout(refresh, 1200);
        } else toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "ارسال ناموفق"));
      });
    });

    var tst = body.querySelector("[data-gp-test]");
    if (tst) tst.addEventListener("click", function () {
      if (S.busy) return;
      S.busy = true;
      api("/api/push/admin?action=test", "POST", {}).then(function (r) {
        S.busy = false;
        toast("🧪 " + ((r.body && r.body.message) || (r.body && r.body.ok ? "اعلان آزمایشی فرستاده شد." : "ناموفق")));
        S.stats = null;
        setTimeout(refresh, 1000);
      });
    });

    var tick = body.querySelector("[data-gp-tick]");
    if (tick) tick.addEventListener("click", function () {
      if (S.busy) return;
      S.busy = true;
      api("/api/push/admin?action=tick", "POST", { batch: 60 }).then(function (r) {
        S.busy = false;
        var b2 = r.body || {};
        toast("🔄 " + fa(b2.rows) + " اعلان در صف پردازش شد، " + fa(b2.sent) + " ارسال شد.");
        S.stats = null;
        setTimeout(refresh, 800);
      });
    });

    var on = body.querySelector("[data-gp-on]");
    if (on) on.addEventListener("change", function () {
      api("/api/push/admin?action=setting", "POST", { key: "push_enabled", value: on.checked ? "on" : "off" })
        .then(function (r) { toast(r.body && r.body.ok ? (on.checked ? "🔔 اعلان‌ها روشن شد" : "🔕 اعلان‌های گوشی خاموش شد") : "⚠️ ذخیره نشد"); });
    });

    var rem = body.querySelector("[data-gp-rem]");
    if (rem) rem.addEventListener("change", function () {
      api("/api/push/admin?action=setting", "POST", { key: "push_daily_reminder", value: rem.checked ? "on" : "off" })
        .then(function (r) { toast(r.body && r.body.ok ? (rem.checked ? "⏰ یادآور روزانه روشن شد" : "یادآور روزانه خاموش شد") : "⚠️ ذخیره نشد"); });
    });

    ["title", "body"].forEach(function (n) {
      var el = body.querySelector('[data-gp="' + n + '"]');
      if (el) el.addEventListener("input", function () { updatePreview(body); });
    });
  }

  /* ---------------- راه‌اندازی ---------------- */

  function boot() {
    injectTab();
    // هر بار پنل باز/رندر شد، تب دوباره اضافه شود
    try {
      var mo = new MutationObserver(function () { injectTab(); });
      mo.observe(document.body, { childList: true, subtree: true });
    } catch (e) { /* مرورگر قدیمی */ }
    setInterval(injectTab, 2500);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
