/* ============================================================
   گیمیفای ۲ — اعلان‌ها (نسخهٔ ۱)
   • زنگولهٔ اعلان با شمارندهٔ خوانده‌نشده‌ها
   • فعال‌سازی اعلان مرورگر (Web Push)
   • ثبت دستگاه اندروید برای دریافت اعلان در پس‌زمینه
   • نمایش زندهٔ اعلان تازه با اتصال SSE
   این فایل کاملاً مستقل است و به باندل اصلی بازی دست نمی‌زند.
   ============================================================ */
(function () {
  "use strict";
  if (window.__gamifiPushV) return;
  window.__gamifiPushV = "75-push v1";

  var FAB = "gm-push-fab", PANEL = "gm-push-panel", STYLE = "gm-push-style";
  var LS_DISMISS = "gm_push_dismiss", LS_SEEN = "gm_push_seen_at";
  var state = { open: false, items: [], unread: 0, webSubs: 0, devSubs: 0, busy: false, enabled: false, keys: null };
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function isApp() {
    try {
      if (window.__GAMIFI_APP__) return true;
      var a = window.Android;
      if (!a) return false;
      return typeof a.isApp === "function" ? !!a.isApp() : true;
    } catch (e) { return false; }
  }
  function api(path, opt) {
    var o = opt || {};
    o.credentials = "same-origin";
    o.headers = Object.assign({ "content-type": "application/json" }, o.headers || {});
    if (o.body && typeof o.body !== "string") o.body = JSON.stringify(o.body);
    return fetch(path, o);
  }
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function when(ts) {
    try {
      var d = new Date(Number(ts) || Date.now()), diff = (Date.now() - d.getTime()) / 1000;
      if (diff < 60) return "همین حالا";
      if (diff < 3600) return fa(Math.floor(diff / 60)) + " دقیقه پیش";
      if (diff < 86400) return fa(Math.floor(diff / 3600)) + " ساعت پیش";
      return d.toLocaleDateString("fa-IR");
    } catch (e) { return ""; }
  }

  /* ---------------- ظاهر ---------------- */
  function css() {
    if (document.getElementById(STYLE)) return;
    var s = document.createElement("style");
    s.id = STYLE;
    s.textContent = [
      "#" + FAB + "{position:fixed;inset-inline-start:16px;bottom:86px;z-index:99990;width:50px;height:50px;border-radius:50%;",
      "background:linear-gradient(160deg,#8b5cf6,#6d28d9);color:#fff;border:2px solid rgba(255,255,255,.25);cursor:pointer;",
      "display:grid;place-items:center;font-size:22px;box-shadow:0 8px 24px rgba(109,40,217,.45);transition:transform .15s}",
      "#" + FAB + ":active{transform:scale(.94)}",
      "#" + FAB + " .gm-badge{position:absolute;top:-4px;inset-inline-end:-4px;min-width:20px;height:20px;border-radius:10px;",
      "background:#ef4444;color:#fff;font:700 11px Vazirmatn,sans-serif;display:grid;place-items:center;padding:0 5px}",
      "#" + FAB + " .gm-ring{position:absolute;inset:-4px;border-radius:50%;border:2px solid rgba(167,139,250,.6);animation:gmPulse 2.2s infinite}",
      "@keyframes gmPulse{0%{transform:scale(1);opacity:.9}70%{transform:scale(1.35);opacity:0}100%{opacity:0}}",
      "#" + PANEL + "{position:fixed;inset-inline-start:12px;bottom:146px;z-index:99991;width:min(360px,92vw);max-height:64vh;overflow:auto;",
      "background:#1d1630;color:#e9e2f7;border:1px solid rgba(167,139,250,.35);border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.55);",
      "font:14px Vazirmatn,sans-serif;direction:rtl;padding:12px;display:none}",
      "#" + PANEL + ".gm-open{display:block}",
      "#" + PANEL + " .gm-h{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}",
      "#" + PANEL + " .gm-h b{font-size:15px}",
      "#" + PANEL + " .gm-x{background:none;border:0;color:#b9a8e0;font-size:18px;cursor:pointer}",
      "#" + PANEL + " .gm-row{display:flex;gap:10px;padding:9px 8px;border-radius:12px;margin-bottom:6px;background:rgba(255,255,255,.04)}",
      "#" + PANEL + " .gm-row.gm-new{background:rgba(139,92,246,.16);border:1px solid rgba(167,139,250,.35)}",
      "#" + PANEL + " .gm-ico{font-size:18px;line-height:1.2}",
      "#" + PANEL + " .gm-t{font-weight:700;font-size:13px;margin-bottom:2px}",
      "#" + PANEL + " .gm-b{font-size:12px;color:#cbbfe6;line-height:1.8}",
      "#" + PANEL + " .gm-time{font-size:10px;color:#9d8fc0;margin-top:3px}",
      "#" + PANEL + " .gm-empty{text-align:center;color:#b9a8e0;padding:18px 6px;font-size:13px}",
      "#" + PANEL + " .gm-btn{width:100%;padding:10px;border-radius:12px;border:0;cursor:pointer;font:700 13px Vazirmatn,sans-serif;",
      "background:linear-gradient(160deg,#8b5cf6,#6d28d9);color:#fff;margin-top:8px}",
      "#" + PANEL + " .gm-btn.gm-off{background:rgba(255,255,255,.08);color:#cbbfe6}",
      "#" + PANEL + " .gm-foot{font-size:11px;color:#9d8fc0;text-align:center;margin-top:8px;line-height:1.9}",
      ".gm-toast{position:fixed;inset-inline-start:12px;bottom:20px;z-index:99999;width:min(340px,90vw);background:#221a38;color:#f4efff;",
      "border:1px solid rgba(167,139,250,.4);border-radius:16px;padding:12px 14px;box-shadow:0 14px 40px rgba(0,0,0,.5);",
      "font:13px Vazirmatn,sans-serif;direction:rtl;opacity:0;transform:translateY(14px);transition:.28s}",
      ".gm-toast.gm-in{opacity:1;transform:none}",
      ".gm-toast b{display:block;margin-bottom:4px;font-size:13.5px}",
    ].join("");
    document.head.appendChild(s);
  }

  function toast(title, body, link) {
    try {
      css();
      var t = el("div", "gm-toast", "<b>" + esc(title) + "</b><span>" + esc(body || "") + "</span>");
      t.onclick = function () { if (link) openLink(link); t.remove(); };
      document.body.appendChild(t);
      setTimeout(function () { t.classList.add("gm-in"); }, 30);
      setTimeout(function () { t.classList.remove("gm-in"); setTimeout(function () { t.remove(); }, 400); }, 6500);
    } catch (e) { /* ignore */ }
  }

  function openLink(link) {
    if (!link) return;
    try {
      var l = String(link);
      if (l.indexOf("#") === 0) { location.hash = l; }
      else if (/^https?:/i.test(l)) { window.open(l, "_blank"); }
      else { location.hash = "#" + l.replace(/^#/, ""); }
    } catch (e) { /* ignore */ }
    closePanel();
  }

  /* ---------------- زنگوله و پنل ---------------- */
  function badge(n) {
    var b = document.querySelector("#" + FAB + " .gm-badge");
    if (!b) return;
    if (n > 0) { b.textContent = n > 99 ? "99+" : fa(n); b.style.display = "grid"; }
    else b.style.display = "none";
  }

  function mount() {
    try {
      if (document.getElementById(FAB)) return;
      css();
      var b = el("button", "");
      b.id = FAB;
      b.title = "اعلان‌ها";
      b.innerHTML = '<span class="gm-ring"></span><span class="gm-ico">🔔</span><span class="gm-badge" style="display:none">۰</span>';
      b.onclick = function (ev) { ev.stopPropagation(); togglePanel(); };
      document.body.appendChild(b);

      var p = el("div", "");
      p.id = PANEL;
      p.onclick = function (ev) { ev.stopPropagation(); };
      document.body.appendChild(p);
      document.addEventListener("click", function () { closePanel(); });
    } catch (e) { /* ignore */ }
  }

  function render() {
    var p = document.getElementById(PANEL);
    if (!p) return;
    var head = '<div class="gm-h"><b>🔔 اعلان‌ها</b><button class="gm-x" id="gm-push-close">✕</button></div>';
    var body;
    if (!state.items.length) {
      body = '<div class="gm-empty">هنوز اعلانی نداری.<br>وقتی کسی تو را به مبارزه دعوت کند، همین‌جا می‌بینی ⚔️</div>';
    } else {
      body = state.items.map(function (n) {
        var ico = /دعوت|چالش|نبرد|مبارزه/.test(n.title) ? "⚔️"
          : /جایزه|پاداش|سکه/.test(n.title) ? "🎁"
          : /قبیله/.test(n.title) ? "🛡️"
          : /تأیید|پست|استوری/.test(n.title) ? "✅"
          : /مدیر/.test(n.title) ? "📣" : "🔔";
        return '<div class="gm-row ' + (n.seen ? "" : "gm-new") + '" data-link="' + esc(n.link || "") + '">'
          + '<div class="gm-ico">' + ico + "</div><div style=\"flex:1\"><div class=\"gm-t\">" + esc(n.title) + "</div>"
          + '<div class="gm-b">' + esc(n.body || "") + '</div><div class="gm-time">' + when(n.createdAt || n.created_at) + "</div></div></div>";
      }).join("");
    }
    var foot = state.enabled
      ? '<button class="gm-btn gm-off" id="gm-push-off">🔕 خاموش‌کردن اعلان‌های این دستگاه</button>'
      : '<button class="gm-btn" id="gm-push-on">🔔 روشن‌کردن اعلان‌ها</button>';
    var test = state.enabled ? '<button class="gm-btn gm-off" id="gm-push-test">🧪 ارسال اعلان آزمایشی</button>' : "";
    var info = '<div class="gm-foot">' + (state.webSubs + state.devSubs > 0
      ? "اعلان‌ها روی " + fa(state.webSubs) + " مرورگر و " + fa(state.devSubs) + " دستگاه فعال است."
      : "اعلان‌ها خاموش است؛ با یک ضربه روشنش کن.") + "</div>";
    p.innerHTML = head + body + foot + test + info;
    var c = document.getElementById("gm-push-close"); if (c) c.onclick = closePanel;
    var on = document.getElementById("gm-push-on"); if (on) on.onclick = function (e) { e.stopPropagation(); enable(); };
    var off = document.getElementById("gm-push-off"); if (off) off.onclick = function (e) { e.stopPropagation(); disable(); };
    var te = document.getElementById("gm-push-test"); if (te) te.onclick = function (e) { e.stopPropagation(); sendTest(); };
    Array.prototype.forEach.call(p.querySelectorAll(".gm-row"), function (r) {
      r.onclick = function (ev) { ev.stopPropagation(); openLink(r.getAttribute("data-link")); };
    });
  }

  function togglePanel() {
    var p = document.getElementById(PANEL);
    if (!p) return;
    state.open = !state.open;
    if (state.open) {
      render();
      p.classList.add("gm-open");
      refreshInbox();
      setTimeout(function () { api("/api/push/seen", { method: "POST", body: { ids: "all" } }).then(function () { state.unread = 0; badge(0); }).catch(function () { }); }, 1500);
    } else closePanel();
  }
  function closePanel() {
    var p = document.getElementById(PANEL);
    if (p) p.classList.remove("gm-open");
    state.open = false;
  }

  /* ---------------- داده‌ها ---------------- */
  function refreshInbox() {
    return api("/api/daily?kind=notifications").then(function (r) { return r.ok ? r.json() : []; }).then(function (rows) {
      if (Array.isArray(rows)) {
        state.items = rows.slice(0, 30);
        state.unread = state.items.filter(function (n) { return !n.seen; }).length;
        badge(state.unread);
        if (state.open) render();
      }
    }).catch(function () { });
  }

  function loadKeys() {
    return api("/api/push/keys").then(function (r) { return r.json(); }).then(function (d) {
      state.keys = d; state.enabled = !!d.enabled;
      return d;
    }).catch(function () { return { ok: false }; });
  }

  function b64ToU8(b64) {
    var pad = "=".repeat((4 - (b64.length % 4)) % 4);
    var s = (b64 + pad).replace(/-/g, "+").replace(/_/g, "/");
    var raw = atob(s), arr = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
    return arr;
  }

  /* ---------------- اعلان مرورگر ---------------- */
  function enable() {
    if (state.busy) return;
    state.busy = true;
    if (isApp()) { registerDevice(true); state.busy = false; return; }

    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      toast("پشتیبانی نمی‌شود", "مرورگر تو از اعلان پیشرفته پشتیبانی نمی‌کند. در کروم اندروید یا دسکتاپ امتحان کن.");
      state.busy = false;
      return;
    }
    var go = function () {
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).then(function (reg) {
        return loadKeys().then(function (keys) {
          if (!keys || !keys.publicKey) throw new Error("no-keys");
          return reg.pushManager.getSubscription().then(function (ex) { return ex; }).then(function (ex) {
            if (ex) return ex;
            return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(keys.publicKey) });
          });
        });
      }).then(function (sub) {
        var j = sub.toJSON ? sub.toJSON() : {};
        return api("/api/push/subscribe", {
          method: "POST",
          body: { endpoint: sub.endpoint, keys: j.keys || {}, ua: navigator.userAgent },
        }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); });
      }).then(function (res) {
        state.busy = false;
        if (res && res.ok) {
          toast("🔔 اعلان‌ها روشن شد", "از این پس دعوت به مبارزه و خبرهای مهم را همان‌جا می‌بینی.");
          state.webSubs = 1;
          render();
          try { localStorage.removeItem(LS_DISMISS); } catch (e) { }
        } else {
          var m = (res && res.d && res.d.message) || "برای فعال‌کردن اعلان‌ها اول وارد بازی شو و دوباره تلاش کن.";
          toast("فعال نشد", m);
        }
      }).catch(function (e) {
        state.busy = false;
        var msg = String((e && e.message) || e);
        if (/denied|permission/i.test(msg)) toast("اجازه داده نشد", "برای فعال‌سازی، از تنظیمات مرورگر اجازهٔ اعلان را بده.");
        else toast("فعال نشد", "دوباره تلاش کن: " + msg.slice(0, 90));
      });
    };

    try {
      if (Notification.permission === "granted") { go(); return; }
      Notification.requestPermission().then(function (perm) {
        if (perm === "granted") go();
        else { state.busy = false; toast("اجازه داده نشد", "برای دریافت اعلان باید اجازه بدهی."); }
      }).catch(function () { state.busy = false; });
    } catch (e) { state.busy = false; }
  }

  function disable() {
    try {
      if (isApp()) {
        try { if (window.Android && window.Android.clearDevice) window.Android.clearDevice(); } catch (e) { }
        state.devSubs = 0;
        toast("خاموش شد", "اعلان‌های این دستگاه خاموش شد.");
        render();
        return;
      }
      navigator.serviceWorker.ready.then(function (reg) {
        return reg.pushManager.getSubscription();
      }).then(function (sub) {
        if (!sub) return null;
        var ep = sub.endpoint;
        return sub.unsubscribe().then(function () {
          return api("/api/push/unsubscribe", { method: "POST", body: { endpoint: ep } });
        });
      }).then(function () {
        state.webSubs = 0;
        toast("خاموش شد", "اعلان‌های این مرورگر خاموش شد.");
        render();
      }).catch(function () { });
    } catch (e) { /* ignore */ }
  }

  function sendTest() {
    api("/api/push/test", { method: "POST" }).then(function (r) { return r.json(); }).then(function (d) {
      toast("🧪 اعلان آزمایشی", (d && d.message) || "فرستاده شد.");
      refreshInbox();
    }).catch(function () { toast("خطا", "ارسال اعلان آزمایشی ناموفق بود."); });
  }

  /* ---------------- دستگاه اندروید ---------------- */
  function registerDevice(notify) {
    try {
      var A = window.Android;
      if (!A || typeof A.deviceId !== "function") return;
      var id = A.deviceId();
      if (!id) return;
      api("/api/push/device", { method: "POST", body: { deviceId: String(id), ua: navigator.userAgent } })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.ok && d.token) {
            try { A.setDeviceToken(String(d.token)); } catch (e) { }
            state.devSubs = 1;
            try { localStorage.setItem("gm_dev_ok", "1"); } catch (e) { }
            if (notify) toast("🔔 اعلان‌ها روشن شد", "از این پس اعلان‌ها را روی گوشی می‌گیری.");
            render();
          } else if (notify) {
            toast("در انتظار ورود", "اول وارد بازی شو؛ بعد از ورود اعلان‌ها خودکار فعال می‌شود.");
          }
        }).catch(function () { });
    } catch (e) { /* ignore */ }
  }

  /* ---------------- اتصال زنده ---------------- */
  function live() {
    try {
      if (!("EventSource" in window)) return;
      var es = new EventSource("/api/events");
      var on = function (ev) {
        var d = {};
        try { d = JSON.parse(ev.data); } catch (e) { return; }
        var title = d.title || "🔔 اعلان تازه";
        if (d.broadcast) title = "📣 " + title;
        toast(title, d.body || "", d.link || "");
        state.unread += 1; badge(state.unread);
        refreshInbox();
        try { if (window.Android && window.Android.vibrate) window.Android.vibrate(150); } catch (e) { }
      };
      es.addEventListener("notify", on);
      es.addEventListener("notice", on);
      es.onerror = function () { /* مرورگر خودش وصل می‌شود */ };
    } catch (e) { /* ignore */ }
  }

  /* ---------------- بنر درخواست اجازه ---------------- */
  function banner() {
    try {
      var last = 0;
      try { last = Number(localStorage.getItem(LS_DISMISS) || 0); } catch (e) { }
      if (last && Date.now() - last < 3 * 86400000) return;
      if (Notification && Notification.permission !== "default") return;
      css();
      var b = el("div", "gm-toast");
      b.style.bottom = "20px";
      b.innerHTML = '<b>🔔 اعلان‌ها را روشن کن</b><span>دعوت به مبارزه و خبر مسابقه‌ها را از دست نده. '
        + '</span><div style="display:flex;gap:8px;margin-top:9px">'
        + '<button class="gm-btn" style="margin:0" id="gm-ban-on">روشن کن</button>'
        + '<button class="gm-btn gm-off" style="margin:0" id="gm-ban-no">بعداً</button></div>';
      document.body.appendChild(b);
      setTimeout(function () { b.classList.add("gm-in"); }, 60);
      var kill = function (later) {
        if (later) { try { localStorage.setItem(LS_DISMISS, String(Date.now())); } catch (e) { } }
        b.classList.remove("gm-in");
        setTimeout(function () { b.remove(); }, 400);
      };
      document.getElementById("gm-ban-on").onclick = function (e) { e.stopPropagation(); kill(false); enable(); };
      document.getElementById("gm-ban-no").onclick = function (e) { e.stopPropagation(); kill(true); };
    } catch (e) { /* ignore */ }
  }

  /* ---------------- راه‌اندازی ---------------- */
  function boot() {
    mount();
    refreshInbox();
    loadKeys().then(function (k) {
      if (!k || !k.ok) return;
      if (isApp()) {
        // دستگاه اپ: ثبت خودکار برای اعلان پس‌زمینه
        registerDevice(false);
        setInterval(function () { if (!state.devSubs) registerDevice(false); }, 90000);
      } else {
        // مرورگر: اگر قبلاً اجازه داده شده، بی‌صدا فعال کن
        try {
          if (Notification.permission === "granted" && "serviceWorker" in navigator && "PushManager" in window) {
            navigator.serviceWorker.register("/sw.js", { scope: "/" }).then(function () { enable(); });
          }
        } catch (e) { /* ignore */ }
        setTimeout(banner, 12000);
      }
      refreshDeviceState();
    });
    live();
    setInterval(function () { if (!document.getElementById(FAB)) mount(); }, 5000);
    setInterval(refreshInbox, 60000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) refreshInbox(); });
  }

  function refreshDeviceState() {
    try {
      if (isApp()) { state.devSubs = state.devSubs || 0; }
      else if (navigator.serviceWorker && navigator.serviceWorker.getRegistration) {
        navigator.serviceWorker.getRegistration("/").then(function (reg) {
          if (!reg || !reg.pushManager) return;
          reg.pushManager.getSubscription().then(function (s) {
            state.webSubs = s ? 1 : 0;
            if (state.open) render();
          }).catch(function () { });
        }).catch(function () { });
      }
    } catch (e) { /* ignore */ }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
