/* ⚔️ نبرد واقعی بازیکن‌به‌بازیکن (PvP) — دعوت/پذیرش/پاسخ/نتیجه همه از سرور
   - وقتی به یک بازیکن واقعی دعوت می‌فرستی، باندل اصلی `window.__gamifyPvpInvite` را صدا می‌زند (به‌جای شبیه‌سازی)
   - حریف واقعی از پنل ⚔️ دعوت را می‌بیند و می‌پذیرد؛ هر دو نفر همان سؤال‌ها را جداگانه جواب می‌دهند
   - امتیازدهی و نتیجه فقط سمت سرور محاسبه می‌شود */
(function () {
  "use strict";
  if (window.__gamifyPvp) return;
  window.__gamifyPvp = true;

  var LS_KEY = "gamify2-store-v2";
  var CATS = {
    safety: "ایمنی و نجات", electric: "دنیای برق", general: "اطلاعات عمومی", science: "علم و شگفتی",
    technology: "فناوری و آینده", work: "تجربه‌های کاری", nature: "زمین و زندگی", sport: "ورزش و سرگرمی",
    geography: "جغرافیا و سفر", history: "تاریخ و تمدن", literature: "ادبیات فارسی", math: "ریاضی و منطق",
    space: "نجوم و فضا", art: "هنر و طراحی", music: "موسیقی", cinema: "سینما و روایت", food: "آشپزی و خوراک",
    animals: "دنیای جانوران", english: "زبان انگلیسی", engineering: "مهندسی و ابزار"
  };
  function catName(id) { return CATS[id] || id || "اطلاعات عمومی"; }
// CATEGORIES-LIVE-START — «دسته‌های زنده»: لیست دسته از سرور می‌آید (نه فقط ثابت)
//   • دسته‌ای که مدیر در پنل (🗂️ دسته‌ها) بسازد، اینجا هم می‌آید و برای همهٔ بازیکنان دیده می‌شود.
//   • اگر fetch شکست بخورد، به لیستِ ثابتِ قبلی برمی‌گردد (فول‌بک).
var CATS_ORG = { barq: 1, "safety-org": 1, edu: 1, health: 1, free: 1 }; // دسته‌های سازمانی/رقابتی — در پیکرِ نبرد زنده نشان داده نمی‌شوند
var CATS_LOADED = false;
function loadCats() {
  if (CATS_LOADED) return Promise.resolve(CATS);
  return fetch("/api/questions?category=_categories", { credentials: "include" })
    .then(function (r) { return r.json(); })
    .then(function (rows) {
      if (Array.isArray(rows) && rows.length) {
        var next = {};
        rows.forEach(function (c) {
          var id = String((c && c.id) || "");
          if (id && !CATS_ORG[id]) next[id] = String(c.name || id);
        });
        if (Object.keys(next).length >= 3) { CATS = next; CATS_LOADED = true; }
      }
      return CATS;
    })
    .catch(function () { return CATS; });
}
// CATEGORIES-LIVE-END

  var S = {
    overlay: null, quizOv: null,
    inbox: null, me: null, badge: 0,
    waiting: null,        // نبردی که منتظر پذیرش حریفم
    watching: null,       // نبردی که منتظر جواب حریف پس از پاسخ منم
    quiz: null,           // { battle, qs, idx, answers, startedAt, locked, timerInt }
    result: null,
    openInviteIds: {},    // دعوت‌هایی که مودالشان باز است
    promptedActive: {},   // نبردهای فعالی که برایشان پیشنهاد شروع داده شده
    playersCache: [], playersAt: 0, tab: "invites",
    pollInt: null, stateInt: null
  };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {}
    try {
      var d = document.createElement("div");
      d.textContent = m;
      d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:99999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #a98cf7;font-family:Vazirmatn,sans-serif;";
      document.body.appendChild(d);
      setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
    } catch (e) {}
  }
  function jingle() { try { if (window.__gamifyConfetti) window.__gamifyConfetti(); } catch (e) {} }
  function loggedIn() {
    try { if (window.__gamifySession && window.__gamifySession.isLoggedIn()) return true; } catch (e) {}
    var st = readStore(); return !!(st && st.profile && st.profile.id);
  }
  function api(path, method, body, retried) {
    var ready = window.__gamifyServer && window.__gamifyServer.ensureSynced ? window.__gamifyServer.ensureSynced() : Promise.resolve();
    return ready.catch(function () {}).then(function () {
      return fetch(path, { method: method || "GET", credentials: "include", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined })
        .then(function (r) {
          return r.text().then(function (txt) {
            var j = null; try { j = JSON.parse(txt); } catch (e) { j = { error: "server", message: "سرور پاسخ نامعتبر داد (" + r.status + ")" }; }
            if (r.status === 401 && !retried && window.__gamifyServer && window.__gamifyServer.syncNow) {
              return window.__gamifyServer.syncNow().then(function () { return api(path, method, body, true); });
            }
            return { status: r.status, body: j };
          });
        });
    }).catch(function () { return { status: 0, body: { error: "network", message: "اتصال به سرور برقرار نشد؛ اینترنت را بررسی کن" } }; });
  }
  function avatarSrc(av) {
    var pad = function (n) { return String(n).padStart(2, "0"); };
    if (av && typeof av === "object" && av.img) return "/assets/avatars/" + pad(av.img) + ".png";
    if (typeof av === "number") return "/assets/avatars/" + pad(((av % 20) + 20) % 20 + 1) + ".png";
    if (av && typeof av === "object" && av.seed) return "/assets/avatars/" + pad(((av.seed % 20) + 20) % 20 + 1) + ".png";
    return "/assets/avatars/07.png";
  }
  function avatarHtml(av, name, size) {
    var ini = esc(String(name || "؟").trim().slice(0, 1) || "؟");
    return '<div class="pvp-av" style="width:' + size + "px;height:" + size + 'px"><img src="' + avatarSrc(av) + '" alt="" loading="lazy" onerror="this.remove()"><span>' + ini + "</span></div>";
  }

  // ================= پنل اصلی (ورودی‌ها / در جریان / نتایج / بازیکنان) =================
  function ensureOverlay() {
    if (S.overlay) return S.overlay;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-overlay";
    ov.id = "gamify-pvp-overlay";
    ov.addEventListener("click", function (e) { if (e.target === ov) closePanel(); });
    document.body.appendChild(ov);
    S.overlay = ov;
    return ov;
  }
  function openPanel() {
    var ov = ensureOverlay();
    ov.classList.add("open");
    renderPanel();
    loadCats().then(function () { if (S.overlay && S.overlay.classList.contains("open")) renderPanel(); });
    refreshInbox(true);
    loadPlayers();
  }
  function closePanel() { if (S.overlay) S.overlay.classList.remove("open"); }

  function badgeCount() {
    if (!S.inbox) return 0;
    var n = (S.inbox.incoming || []).length;
    (S.inbox.active || []).forEach(function (b) { if (!b.myDone) n++; });
    (S.inbox.results || []).forEach(function (b) { if (!b.seen) n++; });
    return n;
  }
  function updateFabBadge() {
    var b = document.getElementById("gamify-pvp-fab");
    if (!b) return;
    var old = b.querySelector(".gamify-fab-badge");
    if (old) old.remove();
    var n = badgeCount();
    if (n > 0) { var s = document.createElement("span"); s.className = "gamify-fab-badge"; s.textContent = fa(n); b.appendChild(s); }
  }

  function rowUser(u) {
    return '<div class="pvp-user">' + avatarHtml(u.avatar, u.name, 46) +
      '<div class="pvp-user-i"><b>' + esc(u.name) + '</b><span>' + (u.online ? "🟢 آنلاین" : "⚪ آفلاین") + ' · ⭐ ' + fa(u.xp || 0) + ' · 🏆 ' + fa(u.wins || 0) + "</span></div></div>";
  }

  function panelHtml() {
    var d = S.inbox || { incoming: [], outgoing: [], active: [], results: [] };
    var tabs = [["invites", "📨 دعوت‌ها (" + fa(d.incoming.length) + ")"], ["active", "⚔️ در جریان"], ["results", "🏁 نتایج"], ["players", "🧑‍🤝‍🧑 بازیکنان"]];
    var head = '<div class="gamify-modal-head"><b>⚔️ نبرد زنده</b><button data-act="close" class="gamify-btn sm">✕</button></div>';
    var tabsHtml = '<div class="gamify-tabs">' + tabs.map(function (t) {
      return '<button class="gamify-btn sm ' + (S.tab === t[0] ? "primary" : "") + '" data-act="tab" data-tab="' + t[0] + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var body = "";

    if (S.tab === "invites") {
      if (!d.incoming.length && !d.outgoing.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🕊️</div><p>دعوت تازه‌ای نداری.<br>از تب «بازیکنان» یکی از بازیکنان واقعی را به نبرد بخوان!</p></div>';
      d.incoming.forEach(function (b) {
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 دسته: ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="accept" data-id="' + b.id + '">✅ قبول نبرد</button>' +
          '<button class="gamify-btn sm" data-act="decline" data-id="' + b.id + '">❌ رد</button></div></div>';
      });
      d.outgoing.forEach(function (b) {
        body += '<div class="pvp-card waiting-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">⏳ در انتظار پذیرش… 📚 ' + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn sm" data-act="cancel" data-id="' + b.id + '">لغو دعوت</button></div></div>';
      });
    } else if (S.tab === "active") {
      if (!d.active.length) body = '<div class="gamify-empty"><div style="font-size:44px;">⚔️</div><p>نبرد فعالی نداری.</p></div>';
      d.active.forEach(function (b) {
        var st = b.myDone ? (b.oppDone ? "در حال ثبت نتیجه…" : "⏳ منتظر پاسخ حریف…") : (b.oppDone ? "🔥 حریف تمام کرده — نوبت تو!" : "🎯 آماده برای شروع");
        body += '<div class="pvp-card">' + rowUser(b.opponent) +
          '<div class="pvp-cat">📚 ' + esc(catName(b.category)) + " · " + st + "</div>" +
          '<div class="pvp-acts">' +
          (!b.myDone ? '<button class="gamify-btn primary sm" data-act="play" data-id="' + b.id + '">🎮 شروع/ادامهٔ نبرد</button>' : '<button class="gamify-btn sm" data-act="watch" data-id="' + b.id + '">👀 پیگیری نتیجه</button>') +
          "</div></div>";
      });
    } else if (S.tab === "results") {
      if (!d.results.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🏁</div><p>هنوز نتیجه‌ای ثبت نشده.</p></div>';
      d.results.forEach(function (b) {
        var r = !b.winnerId ? "مساوی ⚖️" : (b.winnerId === S.me ? "بردی 🏆" : "باختی 💪");
        body += '<div class="pvp-card ' + (!b.seen ? "unseen" : "") + '">' + rowUser(b.opponent) +
          '<div class="pvp-cat">' + r + " · " + fa(b.myScore || 0) + " برابر " + fa(b.oppScore || 0) + " · 📚 " + esc(catName(b.category)) + "</div>" +
          '<div class="pvp-acts"><button class="gamify-btn primary sm" data-act="show-result" data-id="' + b.id + '">📊 جزئیات</button>' +
          '<button class="gamify-btn sm" data-act="rematch" data-id="' + b.id + '">🔁 مبارزهٔ مجدد</button></div></div>';
      });
    } else {
      if (!S.playersCache.length) body = '<div class="gamify-loading">در حال دریافت بازیکنان واقعی…</div>';
      var others = S.playersCache.filter(function (p) { return p && p.id !== S.me; });
      if (S.playersCache.length && !others.length) body = '<div class="gamify-empty"><div style="font-size:44px;">🌱</div><p>فعلاً بازیکن واقعی دیگری وارد نشده؛ دوستت را به بازی دعوت کن!</p></div>';
      body += '<div class="pvp-search"><input type="search" id="pvp-search" placeholder="جست‌وجوی بازیکن…" value="' + esc(S.search || "") + '"></div>';
      others = others.filter(function (p) { return !S.search || (p.name || "").indexOf(S.search) >= 0; }).sort(function (a, b2) { return (b2.online ? 1 : 0) - (a.online ? 1 : 0); });
      others.forEach(function (p) {
        body += '<div class="pvp-card">' + rowUser(p) +
          '<div class="pvp-acts"><select class="pvp-sel" data-cat-for="' + esc(p.id) + '">' +
          Object.keys(CATS).map(function (c) { return '<option value="' + c + '"' + (c === "general" ? " selected" : "") + ">" + CATS[c] + "</option>"; }).join("") +
          '</select><button class="gamify-btn primary sm" data-act="invite" data-id="' + esc(p.id) + '">⚔️ دعوت</button></div></div>';
      });
    }
    return '<div class="gamify-modal pvp-modal">' + head + '<div style="height:10px"></div>' + tabsHtml + '<div class="gamify-body pvp-body">' + body + "</div></div>";
  }

  function renderPanel() {
    var ov = ensureOverlay();
    if (!ov.classList.contains("open")) return;
    if (!loggedIn()) {
      try { if (window.__gamifyEnsureGuest) window.__gamifyEnsureGuest(); } catch (e) {}
      if (!loggedIn()) { ov.innerHTML = '<div class="gamify-modal"><div class="gamify-modal-head"><b>⚔️ نبرد زنده</b><button data-act="close" class="gamify-btn sm">✕</button></div><div class="gamify-loading">در حال آماده‌سازی حساب…</div></div>'; bindPanel(ov); setTimeout(renderPanel, 800); return; }
    }
    ov.innerHTML = panelHtml();
    bindPanel(ov);
  }

  function bindPanel(ov) {
    var si = ov.querySelector("#pvp-search");
    if (si) si.addEventListener("input", function () { S.search = si.value.trim(); var t = ov.querySelector(".pvp-body"); if (t) { renderPanel(); var n = ov.querySelector("#pvp-search"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } } });
    ov.querySelectorAll("[data-act]").forEach(function (el) {
      el.addEventListener("click", function () {
        var act = el.getAttribute("data-act");
        var id = el.getAttribute("data-id");
        if (act === "close") return closePanel();
        if (act === "tab") { S.tab = el.getAttribute("data-tab"); return renderPanel(); }
        if (act === "accept") return doAccept(id);
        if (act === "decline") return doSimple(id, "decline", "دعوت رد شد.");
        if (act === "cancel") return doSimple(id, "cancel", "دعوت لغو شد.");
        if (act === "play") return openQuizFromState(id);
        if (act === "watch") return watchResult(id, true);
        if (act === "show-result") return showResultById(id);
        if (act === "rematch") return doRematch(id);
        if (act === "invite") {
          var sel = ov.querySelector('select[data-cat-for="' + id + '"]');
          var cat = sel ? sel.value : "general";
          var p = S.playersCache.filter(function (x) { return String(x.id) === String(id); })[0];
          return sendInvite(p ? p.id : id, p ? p.name : "بازیکن", p ? p.avatar : null, cat);
        }
      });
    });
  }

  // ================= جریان نبرد =================
  function sendInvite(toId, name, avatar, category) {
    toast("⚔️ در حال ارسال دعوت واقعی…");
    api("/api/pvp?action=invite", "POST", { to: toId, category: category }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا در ارسال دعوت")); return null; }
      var b = r.body.battle;
      startWaiting(b);
      return null;
    });
  }

  // نقطهٔ ورود از باندل اصلی (دکمهٔ «دعوت به مسابقه» روی بازیکن واقعی)
  window.__gamifyPvpInvite = function (player, category) {
    if (!player || !player.id) return;
    sendInvite(player.id, player.name, player.avatar, category || "general");
  };

  function doAccept(id) {
    api("/api/pvp?action=accept", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return refreshInbox(true); }
      toast("✅ نبرد پذیرفته شد — آماده باش!");
      openLive(r.body.battle);
    });
  }
  function doSimple(id, action, msg) {
    api("/api/pvp?action=" + action, "POST", { id: id }).then(function () {
      toast(msg);
      var mo = document.getElementById("pvp-invite-modal");
      if (mo) mo.remove();
      delete S.openInviteIds[id];
      refreshInbox(true);
    });
  }
  function doRematch(id) {
    api("/api/pvp?action=rematch", "POST", { id: id }).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      closeResultModal();
      startWaiting(r.body.battle);
      return null;
    });
  }

  // ================= جریان زندهٔ هم‌زمان =================
  var clockOffset = 0; // serverNow - Date.now()
  function syncClock(st) { if (st && typeof st.serverNow === "number") clockOffset = st.serverNow - Date.now(); }
  function srvNow() { return Date.now() + clockOffset; }

  // ---- انتظار پذیرش (چالش‌گر) ----
  function startWaiting(battle) {
    S.waiting = battle;
    syncClock(battle);
    renderWaiting();
    if (S.stateInt) clearInterval(S.stateInt);
    // پشتیبان: اگر رویداد زنده نرسید، هر ۴ ثانیه وضعیت را بپرس
    S.stateInt = setInterval(function () { if (S.waiting) pollWaiting(battle.id); }, 4000);
  }
  function pollWaiting(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) return;
      handleStateChange(r.body);
    });
  }
  function handleStateChange(st) {
    syncClock(st);
    if (st.status === "accepted") {
      stopWaiting();
      if (!S.quiz || S.quiz.battle.id !== st.id) openLive(st);
    } else if (st.status === "declined") {
      stopWaiting(); toast("❌ " + ((st.opponent && st.opponent.name) || "حریف") + " الان برای نبرد آماده نیست."); refreshInbox(true);
    } else if (st.status === "expired" || st.status === "cancelled") {
      stopWaiting(); toast("⌛ دعوت بی‌پاسخ ماند؛ دوباره تلاش کن."); refreshInbox(true);
    } else if (st.status === "finished" && st.result) {
      closeQuiz(); showResult(st);
    }
  }
  function stopWaiting() { if (S.stateInt) { clearInterval(S.stateInt); S.stateInt = null; } S.waiting = null; closeWaiting(); }
  function renderWaiting() {
    closeWaiting();
    var b = S.waiting; if (!b) return;
    var d = document.createElement("div");
    d.className = "pvp-mini-overlay"; d.id = "pvp-waiting-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords pulse">⚔️</div></div>' +
      "<h3>در انتظار پذیرش " + esc(b.opponent.name) + "…</h3>" +
      '<p class="pvp-sub">📚 ' + esc(catName(b.category)) + " · ۵ سؤال هم‌زمان · ۱۵ ثانیه برای هر سؤال</p>" +
      '<div class="pvp-wait-bar"><i></i></div>' +
      '<div class="pvp-acts center"><button class="gamify-btn sm" data-c="1">لغو دعوت</button></div></div>';
    document.body.appendChild(d);
    d.querySelector("[data-c]").addEventListener("click", function () { api("/api/pvp?action=cancel", "POST", { id: b.id }); stopWaiting(); refreshInbox(true); });
  }
  function closeWaiting() { var d = document.getElementById("pvp-waiting-modal"); if (d) d.remove(); }

  // ---- اتاق نبرد زنده ----
  function ensureQuizOverlay() {
    if (S.quizOv) return S.quizOv;
    var ov = document.createElement("div");
    ov.className = "gamify-overlay pvp-quiz-overlay"; ov.id = "gamify-pvp-quiz";
    document.body.appendChild(ov); S.quizOv = ov; return ov;
  }
  function openQuizFromState(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) { toast("⚠️ " + ((r.body && (r.body.message || r.body.error)) || "خطا")); return null; }
      syncClock(r.body);
      if (r.body.status === "finished") return showResult(r.body), null;
      if (r.body.status === "accepted") return openLive(r.body), null;
      toast("این نبرد هنوز شروع نشده."); return null;
    });
  }
  function openQuiz(b) { openLive(b); }
  function openLive(battle) {
    syncClock(battle);
    closeWaiting(); closeWatching(); closePanel();
    var inv = document.getElementById("pvp-invite-modal"); if (inv) inv.remove();
    var ov = ensureQuizOverlay(); ov.classList.add("open");
    var qs = (battle.questions || []).slice();
    S.quiz = { battle: battle, qs: qs, idx: -1, picked: {}, oppAnswered: battle.oppAnswered || [], reveal: battle.reveal || [], timerInt: null, locked: false, myScore: 0, oppScore: 0, myAnswered: battle.myAnswered || [] };
    if (S.quiz.timerInt) clearInterval(S.quiz.timerInt);
    S.quiz.timerInt = setInterval(tickLive, 100);
    tickLive();
  }
  function closeQuiz() {
    if (S.quiz && S.quiz.timerInt) clearInterval(S.quiz.timerInt);
    S.quiz = null;
    if (S.quizOv) { S.quizOv.classList.remove("open"); S.quizOv.innerHTML = ""; }
  }
  function qStart(k) { var b = S.quiz.battle; return b.startedAt + k * (b.seconds * 1000 + b.gap); }
  function tickLive() {
    var q = S.quiz; if (!q) return;
    var b = q.battle, t = srvNow(), n = b.qCount || q.qs.length || 5;
    if (t < b.startedAt) { renderCountdown(Math.ceil((b.startedAt - t) / 1000)); return; }
    var k = Math.min(n - 1, Math.floor((t - b.startedAt) / (b.seconds * 1000 + b.gap)));
    var within = t - qStart(k);
    var inGap = within > b.seconds * 1000;
    if (t >= b.deadline + 800) {
      // مهلت تمام شد؛ منتظر نتیجهٔ سرور
      if (!q.waitingResult) { q.waitingResult = true; renderLiveWaiting(); setTimeout(function () { if (S.quiz && S.quiz.waitingResult) pollWaitingResult(b.id); }, 1500); }
      return;
    }
    if (k !== q.idx) {
      q.idx = k; q.locked = false;
      if (!q.qs[k]) { fetchQuestion(k); }
      renderLiveQ();
    }
    var fill = document.getElementById("pvp-timer-fill");
    var left = Math.max(0, b.seconds * 1000 - within);
    if (fill) { fill.style.width = (left / (b.seconds * 1000) * 100) + "%"; fill.classList.toggle("low", left <= 3000); }
    var tl = document.getElementById("pvp-tleft"); if (tl) tl.textContent = fa(Math.ceil(left / 1000));
    if (inGap && !q.locked) { q.locked = true; markTimeout(); }
    if (inGap && q.reveal[k]) applyReveal(k);
  }
  function fetchQuestion(k) {
    var q = S.quiz; if (!q || q.fetching === k) return; q.fetching = k;
    api("/api/pvp?action=state&id=" + encodeURIComponent(q.battle.id)).then(function (r) {
      if (!S.quiz || !r.body || r.body.error) return;
      syncClock(r.body);
      if (r.body.status === "finished") { closeQuiz(); showResult(r.body); return; }
      (r.body.questions || []).forEach(function (qq, i) { if (qq && !S.quiz.qs[i]) S.quiz.qs[i] = qq; });
      S.quiz.oppAnswered = r.body.oppAnswered || S.quiz.oppAnswered; S.quiz.myAnswered = r.body.myAnswered || S.quiz.myAnswered;
      (r.body.reveal || []).forEach(function (rv, i) { if (rv) S.quiz.reveal[i] = rv; });
      S.quiz.fetching = -1;
      if (S.quiz.idx === k) renderLiveQ();
    });
  }
  function renderCountdown(sec) {
    var ov = S.quizOv, q = S.quiz;
    if (ov.getAttribute("data-mode") !== "cd") {
      ov.setAttribute("data-mode", "cd");
      ov.innerHTML = '<div class="gamify-modal pvp-quiz pvp-cd"><div class="pvp-versus">' + avatarHtml(q.battle.opponent.avatar, q.battle.opponent.name, 72) + '<div class="pvp-swords pulse">⚔️</div></div><h3>نبرد با ' + esc(q.battle.opponent.name) + '</h3><div class="pvp-cd-num" id="pvp-cd-num">' + fa(sec) + "</div><p class=\"pvp-sub\">هر دو هم‌زمان همین سؤال‌ها را می‌بینید — سریع‌تر و درست‌تر برنده است</p></div>";
    } else { var el = document.getElementById("pvp-cd-num"); if (el) el.textContent = fa(sec); }
  }
  function renderLiveQ() {
    var q = S.quiz; if (!q) return;
    var ov = S.quizOv; ov.setAttribute("data-mode", "q");
    var item = q.qs[q.idx], b = q.battle, n = b.qCount || q.qs.length || 5;
    var dots = ""; for (var i = 0; i < n; i++) dots += '<i class="' + (i < q.idx ? "done" : i === q.idx ? "cur" : "") + '"></i>';
    var head = '<div class="gamify-modal-head"><b>⚔️ ' + esc(b.opponent.name) + ' <small class="pvp-live-dot">● زنده</small></b><span class="pvp-count">' + fa(q.idx + 1) + " / " + fa(n) + ' · ⏱ <b id="pvp-tleft">' + fa(b.seconds) + '</b></span><button class="gamify-btn sm" data-exit="1">ترک ↩</button></div>' +
      '<div class="pvp-live-score"><span>تو: <b id="pvp-my-score">' + fa(q.myScore) + '</b></span><span id="pvp-opp-status">' + (q.oppAnswered[q.idx] ? "✅ حریف پاسخ داد" : "⏳ حریف در حال پاسخ…") + '</span><span>حریف: <b id="pvp-opp-score">' + fa(q.oppScore) + "</b></span></div>" +
      '<div class="pvp-progress">' + dots + "</div><div class=\"pvp-timerbar\"><i id=\"pvp-timer-fill\"></i></div>";
    if (!item) { ov.innerHTML = '<div class="gamify-modal pvp-quiz">' + head + '<div class="gamify-loading">در حال دریافت سؤال…</div></div>'; bindExit(); return; }
    ov.innerHTML = '<div class="gamify-modal pvp-quiz">' + head +
      '<h3 class="pvp-qtitle">' + esc(item.title) + "</h3>" +
      '<div class="pvp-opts">' + item.options.map(function (op, i) { return '<button class="pvp-opt" data-i="' + i + '"><span class="pvp-opt-key">' + ["۱", "۲", "۳", "۴", "۵", "۶"][i] + "</span>" + esc(op) + "</button>"; }).join("") + "</div>" +
      '<div class="pvp-feedback" id="pvp-feedback"></div></div>';
    ov.querySelectorAll(".pvp-opt").forEach(function (btn) { btn.addEventListener("click", function () { pick(parseInt(btn.getAttribute("data-i"), 10)); }); });
    bindExit();
    if (q.myAnswered[q.idx] || q.picked[q.idx] != null) { q.locked = true; ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; }); if (q.picked[q.idx] >= 0) { var pb = ov.querySelector('.pvp-opt[data-i="' + q.picked[q.idx] + '"]'); if (pb) pb.classList.add("picked"); } }
    if (q.reveal[q.idx]) applyReveal(q.idx);
  }
  function bindExit() {
    var ex = S.quizOv.querySelector("[data-exit]");
    if (ex) ex.addEventListener("click", function () {
      if (!confirm("ترک نبرد = باخت فنی. مطمئنی؟")) return;
      var id = S.quiz.battle.id; closeQuiz();
      api("/api/pvp?action=forfeit", "POST", { id: id }).then(function () { refreshInbox(true); });
    });
  }
  function pick(i) {
    var q = S.quiz; if (!q || q.locked) return;
    q.locked = true; q.picked[q.idx] = i;
    var ov = S.quizOv, k = q.idx;
    ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; });
    var btn = ov.querySelector('.pvp-opt[data-i="' + i + '"]'); if (btn) btn.classList.add("picked");
    var sendT = Date.now();
    api("/api/pvp?action=answer", "POST", { id: q.battle.id, q: k, i: i }).then(function (r) {
      if (!S.quiz || S.quiz.idx !== k) return;
      var fb = document.getElementById("pvp-feedback");
      if (!r.body || r.body.error) { if (fb) fb.innerHTML = '<span class="no">⚠️ ' + esc((r.body && (r.body.message || r.body.error)) || "ارسال نشد") + "</span>"; return; }
      if (r.body.late) { if (fb) fb.innerHTML = '<span class="no">⏰ دیر رسید!</span>'; return; }
      if (btn) btn.classList.add(r.body.correct ? "ok" : "no");
      if (fb) fb.innerHTML = r.body.correct ? '<span class="ok">✅ درست! ' + (Date.now() - sendT < 400 ? "" : "") + "</span>" : '<span class="no">❌ نادرست</span>';
      if (r.body.correct) { var limit = q.battle.seconds * 1000; var el = srvNow() - qStart(k); q.myScore += 100 + Math.max(0, Math.round(50 * (1 - Math.min(limit, el) / limit))); var ms = document.getElementById("pvp-my-score"); if (ms) ms.textContent = fa(q.myScore); }
    });
  }
  function markTimeout() {
    var q = S.quiz; if (!q) return;
    if (q.picked[q.idx] == null && !q.myAnswered[q.idx]) {
      q.picked[q.idx] = -1;
      var ov = S.quizOv; ov.querySelectorAll(".pvp-opt").forEach(function (b2) { b2.disabled = true; });
      var fb = document.getElementById("pvp-feedback"); if (fb) fb.innerHTML = '<span class="no">⏰ وقت تمام شد</span>';
      api("/api/pvp?action=answer", "POST", { id: q.battle.id, q: q.idx, i: -1 });
    }
  }
  function applyReveal(k) {
    var q = S.quiz; if (!q || q.idx !== k) return;
    var rv = q.reveal[k]; var ov = S.quizOv;
    var c = ov.querySelector('.pvp-opt[data-i="' + rv.correct + '"]'); if (c) c.classList.add("ok");
    var myPick = q.picked[k] != null ? q.picked[k] : rv.myPick;
    if (myPick >= 0 && myPick !== rv.correct) { var w = ov.querySelector('.pvp-opt[data-i="' + myPick + '"]'); if (w) w.classList.add("no"); }
    var fb = document.getElementById("pvp-feedback");
    if (fb && !fb.innerHTML) fb.innerHTML = '<span class="corr">پاسخ درست: ' + esc(q.qs[k] ? q.qs[k].options[rv.correct] : "") + "</span>";
    if (rv.oppPick != null) { var os = document.getElementById("pvp-opp-status"); if (os) os.textContent = rv.oppPick === rv.correct ? "✅ حریف درست زد" : (rv.oppPick < 0 ? "⏰ حریف پاسخ نداد" : "❌ حریف اشتباه زد"); }
    if (rv.explanation && fb) fb.insertAdjacentHTML("beforeend", '<div class="pvp-expl">💡 ' + esc(rv.explanation) + "</div>");
  }
  function renderLiveWaiting() {
    var q = S.quiz; if (!q) return;
    S.quizOv.setAttribute("data-mode", "w");
    S.quizOv.innerHTML = '<div class="gamify-modal pvp-quiz"><div class="gamify-loading">🏁 نبرد تمام شد؛ در حال محاسبهٔ نتیجه در سرور…</div></div>';
  }
  function pollWaitingResult(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error) return;
      if (r.body.status === "finished" && r.body.result) { closeQuiz(); showResult(r.body); refreshInbox(true); }
      else if (S.quiz && S.quiz.waitingResult) setTimeout(function () { pollWaitingResult(id); }, 2500);
    });
  }
  function submitAnswers() {}

  // ---- انتظار نتیجه (برای نبردهای از پنل) ----
  function watchResult(id, fromPanel) {
    S.watching = id; if (fromPanel) closePanel();
    renderWatching();
    if (S.stateInt) clearInterval(S.stateInt);
    S.stateInt = setInterval(function () {
      api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
        if (!r.body || r.body.error) return;
        if (r.body.status === "finished" && r.body.result) { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); showResult(r.body); refreshInbox(true); }
        else if (r.body.status === "accepted") { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); openLive(r.body); }
      });
    }, 3000);
  }
  function renderWatching() {
    closeWatching();
    var d = document.createElement("div"); d.className = "pvp-mini-overlay"; d.id = "pvp-watching-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini"><div class="gamify-loading">⏳ منتظر پایان نبرد…</div><div class="pvp-acts center"><button class="gamify-btn sm" data-x="1">بستن</button></div></div>';
    document.body.appendChild(d);
    d.querySelector("[data-x]").addEventListener("click", function () { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); });
  }
  function closeWatching() { var d = document.getElementById("pvp-watching-modal"); if (d) d.remove(); }

  function showResultById(id) {
    api("/api/pvp?action=state&id=" + encodeURIComponent(id)).then(function (r) {
      if (!r.body || r.body.error || !r.body.result) { toast("⚠️ نتیجه هنوز آماده نیست."); return null; }
      showResult(r.body);
      return null;
    });
  }
  function showResult(b) {
    closeWatching();
    closeWaiting();
    var res = b.result;
    var iWon = res.winnerId && res.winnerId === S.me;
    var draw = !res.winnerId;
    var title = draw ? "مساوی شدید! ⚖️" : iWon ? "بردی! 🏆" : "این دور را باختی 💪";
    var cls = draw ? "draw" : iWon ? "win" : "lose";
    if (S.overlay && S.overlay.classList.contains("open")) S.overlay.classList.remove("open");
    var old = document.getElementById("pvp-result-modal");
    if (old) old.remove();
    var d = document.createElement("div");
    d.id = "pvp-result-modal";
    d.className = "pvp-mini-overlay";
    var per = res.perQ.map(function (q, i) {
      var myOk = q.myPick === q.correct;
      var opOk = q.oppPick === q.correct;
      return '<div class="pvp-perq">' +
        '<div class="t">' + esc(q.title) + "</div>" +
        '<div class="r"><span class="' + (myOk ? "ok" : "no") + '">' + (myOk ? "✅" : "❌") + " تو: " + (q.myPick >= 0 ? esc(q.options[q.myPick]) : "—") + " (+" + fa(q.myPts) + ')</span>' +
        '<span class="' + (opOk ? "ok" : "no") + '">' + (opOk ? "✅" : "❌") + " حریف: " + (q.oppPick >= 0 ? esc(q.options[q.oppPick]) : "—") + " (+" + fa(q.oppPts) + ")</span></div>" +
        (!myOk ? '<div class="corr">پاسخ درست: ' + esc(q.options[q.correct]) + (q.explanation ? " — " + esc(q.explanation) : "") + "</div>" : "") +
        "</div>";
    }).join("");
    d.innerHTML = '<div class="gamify-modal pvp-result ' + cls + '">' +
      '<div class="gamify-modal-head"><b>' + title + '</b><button data-x="1" class="gamify-btn sm">✕</button></div>' +
      '<div class="pvp-score-row">' +
        '<div class="pvp-side me"><div class="lbl">تو</div><div class="sc">' + fa(res.myScore) + '</div><div class="cc">✅ ' + fa(res.myCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
        '<div class="pvp-vs">VS</div>' +
        '<div class="pvp-side op"><div class="lbl">' + esc(b.opponent.name) + '</div><div class="sc">' + fa(res.oppScore) + '</div><div class="cc">✅ ' + fa(res.oppCorrect) + " از " + fa(res.perQ.length) + "</div></div>" +
      "</div>" +
      '<div class="pvp-hint center">+ امتیاز تجربه و سکهٔ نبرد به حسابت اضافه شد 🎁</div>' +
      '<div class="pvp-scroll">' + per + "</div>" +
      '<div class="pvp-acts center">' +
        '<button class="gamify-btn primary sm" data-rematch="' + b.id + '">🔁 مبارزهٔ مجدد</button>' +
        '<button class="gamify-btn sm" data-x="1">بستن</button>' +
      "</div></div>";
    document.body.appendChild(d);
    if (iWon) jingle();
    api("/api/pvp?action=ack", "POST", { id: b.id });
    d.querySelectorAll("[data-x]").forEach(function (el) { el.addEventListener("click", function () { closeResultModal(); }); });
    var rm = d.querySelector("[data-rematch]");
    if (rm) rm.addEventListener("click", function () { doRematch(b.id); });
    refreshInbox(true);
  }
  function closeResultModal() { var d = document.getElementById("pvp-result-modal"); if (d) d.remove(); }

  // ================= دعوت ورودی (مودال فوری) =================
  function showIncoming(b) {
    if (S.openInviteIds[b.id]) return;
    S.openInviteIds[b.id] = 1;
    var d = document.createElement("div");
    d.className = "pvp-mini-overlay";
    d.id = "pvp-invite-modal";
    d.innerHTML = '<div class="gamify-modal pvp-mini pvp-invite-in">' +
      '<div class="pvp-versus">' + avatarHtml(b.opponent.avatar, b.opponent.name, 84) + '<div class="pvp-swords">⚔️</div></div>' +
      "<h3>" + (b.byAdmin ? "🏟️ مسابقهٔ ویژه: " : "") + esc(b.opponent.name) + " تو را به نبرد زنده دعوت کرد!</h3>" +
      '<p class="pvp-sub">📚 دسته: ' + esc(catName(b.category)) + " · ۵ سؤال هم‌زمان · ۱۵ ثانیه هر سؤال</p>" +
      '<div class="pvp-acts center"><button class="gamify-btn primary" data-a="1">✅ قبول نبرد</button><button class="gamify-btn" data-d="1">❌ رد</button></div></div>';
    document.body.appendChild(d);
    jingle();
    d.querySelector("[data-a]").addEventListener("click", function () {
      d.remove(); delete S.openInviteIds[b.id];
      doAccept(b.id);
    });
    d.querySelector("[data-d]").addEventListener("click", function () {
      doSimple(b.id, "decline", "دعوت رد شد.");
    });
    setTimeout(function () { if (document.body.contains(d)) { d.remove(); delete S.openInviteIds[b.id]; refreshInbox(true); } }, 60000);
  }

  // ================= حلقهٔ نظارت =================
  function refreshInbox(silent) {
    if (!loggedIn()) return;
    api("/api/pvp?action=inbox").then(function (r) {
      if (!r.body || r.body.error || Array.isArray(r.body)) return;
      var prev = S.inbox;
      S.inbox = r.body;
      S.me = r.body.me;
      updateFabBadge();
      (r.body.incoming || []).forEach(function (b) { showIncoming(b); });
      // دعوت‌های من که تازه پذیرفته شده‌اند (اگر در حال انتظار نباشم: مثلاً پس از رفرش صفحه)
      (r.body.active || []).forEach(function (b) {
        if (!b.myDone && !S.quiz && !S.waiting && !S.promptedActive[b.id]) {
          var wasPending = prev && (prev.outgoing || []).some(function (o) { return o.id === b.id; });
          if (wasPending) toast("✅ " + (b.opponent.name || "حریف") + " پذیرفت — از پنل ⚔️ نبرد را شروع کن!");
          S.promptedActive[b.id] = 1;
        }
      });
      // نتایج دیده‌نشدهٔ جدید → تست
      (r.body.results || []).forEach(function (b) {
        if (!b.seen && !S.watching && !document.getElementById("pvp-result-modal")) {
          var seenBefore = prev && (prev.results || []).some(function (o) { return o.id === b.id && !o.seen; });
          if (!seenBefore && prev) toast("🏁 نتیجهٔ نبرد با " + (b.opponent.name || "حریف") + " آمد — پنل ⚔️");
        }
      });
      if (!silent && S.overlay && S.overlay.classList.contains("open")) renderPanel();
      else if (S.overlay && S.overlay.classList.contains("open")) renderPanel();
    });
  }

  function loadPlayers() {
    if (Date.now() - S.playersAt < 20000 && S.playersCache.length) { renderPanel(); return; }
    api("/api/players?limit=150&real=1").then(function (r) {
      if (Array.isArray(r.body)) {
        S.playersCache = r.body.filter(function (p) { return p && !p.isDemo; }).map(function (p) {
          return { id: p.id, name: p.name, avatar: p.avatar, xp: p.xp, wins: p.wins, online: p.online };
        });
        S.playersAt = Date.now();
        if (S.tab === "players") renderPanel();
      }
    });
  }

  function mountFab() {
    if (document.getElementById("gamify-pvp-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-pvp-fab";
    b.textContent = "⚔️";
    b.title = "نبرد واقعی بازیکن‌به‌بازیکن";
    b.addEventListener("click", openPanel);
    document.body.appendChild(b);
  }

  function onRt(type, data) {
    if (type === "pvp:invite" && data && data.battle) { syncClock(data.battle); refreshInbox(true); showIncoming(data.battle); }
    else if (type === "pvp:outgoing" && data && data.battle) { if (data.battle.byAdmin && !S.waiting) { toast("🏟️ مدیر برای تو مسابقه ترتیب داد!"); startWaiting(data.battle); } }
    else if (type === "pvp:accepted" && data && data.battle) { handleStateChange(data.battle); }
    else if (type === "pvp:q" && data && S.quiz && S.quiz.battle.id === data.id) { if (typeof data.serverNow === "number") clockOffset = data.serverNow - Date.now(); S.quiz.qs[data.q] = data.question; if (S.quiz.idx === data.q) renderLiveQ(); }
    else if (type === "pvp:reveal" && data && S.quiz && S.quiz.battle.id === data.id) { var ia = S.quiz.battle.iAmA; S.quiz.reveal[data.q] = { correct: data.correct, myPick: ia ? data.aPick : data.bPick, oppPick: ia ? data.bPick : data.aPick, explanation: data.explanation }; if (S.quiz.idx === data.q) applyReveal(data.q); }
    else if (type === "pvp:opp-answered" && data && S.quiz && S.quiz.battle.id === data.id) { S.quiz.oppAnswered[data.q] = true; if (S.quiz.idx === data.q) { var os = document.getElementById("pvp-opp-status"); if (os) os.textContent = "✅ حریف پاسخ داد"; } }
    else if (type === "pvp:finished" && data && data.battle) { if (S.quiz && S.quiz.battle.id === data.battle.id) closeQuiz(); stopWaiting(); if (S.watching === data.battle.id) { clearInterval(S.stateInt); S.stateInt = null; S.watching = null; closeWatching(); } showResult(data.battle); }
    else if (type === "pvp:update" && data) { if (S.waiting && S.waiting.id === data.id) handleStateChange({ id: data.id, status: data.status, opponent: S.waiting.opponent }); var inv = document.getElementById("pvp-invite-modal"); if (inv && (data.status === "cancelled" || data.status === "expired")) { inv.remove(); delete S.openInviteIds[data.id]; } refreshInbox(true); }
    else if (type === "connected") { refreshInbox(true); }
  }
  function boot() {
    mountFab();
    setTimeout(function () { refreshInbox(true); }, 2500);
    // رویدادهای زنده؛ polling فقط پشتیبان کم‌تکرار
    window.addEventListener("gamify:rt", function (e) { try { onRt(e.detail.type, e.detail.data); } catch (err) {} });
    S.pollInt = setInterval(function () { if (!document.hidden && !(window.__gamifyRT && window.__gamifyRT.connected())) refreshInbox(true); }, 12000);
    setInterval(function () { if (!document.hidden) refreshInbox(true); }, 45000);
    setInterval(function () { if (S.overlay && S.overlay.classList.contains("open") && S.tab === "players") { S.playersAt = 0; loadPlayers(); } }, 30000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) refreshInbox(true); });
    window.addEventListener("gamify:players", function () { S.playersAt = 0; });
    window.__gamifyPvpOpen = openPanel;
    window.__gamifyPvP = { open: openPanel, openBattle: openQuizFromState };
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
// PVP-PLUS-START — «نبرد پلاس» را پاک نکن؛ این بلوک را اسکریپت نصب بازنویسی می‌کند
/* ⚔️➕ نبرد پلاس — نسخهٔ ۲
   -----------------------------------------------------------------------------
   الف) نبرد زندهٔ دو بازیکن (پنجرهٔ ⚔️):
        • «🎯 ۵۰/۵۰ حذف دو گزینه» (یک‌بار در هر مسابقه)
        • شمارندهٔ زندهٔ پاسخ‌های درستِ حریف
        • ایموجی حین مبارزه (ست همان ایموجی‌های «مسابقات رقابتی»)
   ب) نبرد قبیله‌ای (پنجرهٔ 🛡️ قبیله‌ها → نبردها → ورود به نبرد):
        • «🎯 ۵۰/۵۰ حذف دو گزینه» (یک‌بار در هر نبرد)
        • امتیاز زندهٔ دو طرف (ما / حریف)
        • ایموجی حین مبارزه
   «راهنما» عمداً حذف شده — فقط حذف دو گزینه (طبق خواستهٔ کارفرما).
   هیچ کدی از خود بازی بازنویسی نمی‌شود؛ همه‌چیز فقط روی پنجره‌ها سوار می‌شود.
*/
(function () {
  "use strict";
  if (window.__gamifyPvpPlus) return;
  window.__gamifyPvpPlus = true;

  /* ───────── تنظیمات ───────── */
  var LS_PVP = "gamify2-pvp-plus-used";     // ۵۰/۵۰ نبرد زنده (به‌ازای هر مسابقه)
  var LS_TB = "gamify2-tribe-plus-used";    // ۵۰/۵۰ نبرد قبیله (به‌ازای هر نبرد)
  var EMOJIS = ["😂", "😢", "😡", "😮", "🤝", "❤️", "👋", "🔥", "👏", "😎"];
  var ZW = "\u200b\u200b\u200b";            // نشانِ نامرئیِ پیام چت برای ایموجی نبرد زنده
  var T_PREFIX = "__eng-e-";                // نشانِ رکورد ایموجی نبرد قبیله (از فید پنهان است)
  var BUBBLE_MS = 2400;
  var POLL_PVP = 2600;                      // فاصلهٔ پرس‌وجوی وضعیت نبرد زنده
  var POLL_TB = 4000;                       // فاصلهٔ پرس‌وجوی امتیاز نبرد قبیله
  var POLL_EMOJI = 3000;                    // فاصلهٔ خواندن ایموجی‌های تازه (قبیله)

  /* ───────── ابزار ───────── */
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function norm(s) { return String(s == null ? "" : s).replace(/[\u200b-\u200f\u202a-\u202e]/g, "").replace(/\s+/g, " ").trim(); }
  function toast(m) {
    try { if (window.__gamifyToast) return window.__gamifyToast(m); } catch (e) {}
    try { console.log("[pvp-plus]", m); } catch (e) {}
  }
  function el(id) { try { return document.getElementById(id); } catch (e) { return null; } }
  function setText(node, s) { try { if (node && node.textContent !== s) node.textContent = s; } catch (e) {} }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function lsGet(key, dflt) { try { var v = JSON.parse(localStorage.getItem(key) || "null"); return v == null ? dflt : v; } catch (e) { return dflt; } }
  function lsSet(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} }
  function faToNum(s) {
    var map = { "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9" };
    var t = String(s == null ? "" : s).replace(/[۰-۹]/g, function (c) { return map[c]; }).replace(/[^0-9]/g, "");
    return t ? Number(t) : NaN;
  }
  var rawFetch = window.fetch ? window.fetch.bind(window) : null;
  function jfetch(url, opt) {
    if (!rawFetch) return Promise.reject(new Error("no-fetch"));
    return rawFetch(url, Object.assign({ credentials: "include" }, opt || {})).then(function (r) { return r.json().catch(function () { return {}; }); });
  }

  /* ───────── بانک سؤال (برای ۵۰/۵۰ نبرد زنده؛ کلید پاسخ‌ها) ───────── */
  function bankList() {
    try { var d = window.__gamifyBankData; if (d && Array.isArray(d.questions) && d.questions.length) return d.questions; } catch (e) {}
    return [];
  }
  function findBankQ(id, title) {
    var list = bankList();
    if (!list.length) return null;
    var i, q = null;
    if (id != null && String(id) !== "") for (i = 0; i < list.length; i++) if (String(list[i].id) === String(id)) { q = list[i]; break; }
    if (!q && title) { var t = norm(title); for (i = 0; i < list.length; i++) if (norm(list[i].title) === t) { q = list[i]; break; } }
    return q || null;
  }
  function correctOf(item, optCount) {
    if (!item) return -1;
    var c = Number(item.correct);
    if (!isFinite(c) || c < 0 || c >= optCount) return -1;
    return Math.round(c);
  }

  /* ───────── ایموجی: پوسته و حباب‌ها ───────── */
  var EMOJI_UI = {};
  var styleDone = false;
  function ensureStyle() {
    if (styleDone) return;
    styleDone = true;
    try {
      var s = document.createElement("style");
      s.id = "pp-style";
      s.textContent =
        "@keyframes pp-in{from{opacity:0;transform:translateY(8px) scale(.9)}to{opacity:1;transform:none}}" +
        ".pp-bubble{animation:pp-in .18s ease-out}" +
        ".pp-emoji-btn:hover,.pp-emoji:hover{transform:scale(1.12)}";
      document.head.appendChild(s);
    } catch (e) {}
  }
  function ensureEmojiUI(key, host) {
    if (!host) return null;
    ensureStyle();
    var ui = EMOJI_UI[key];
    if (!ui || ui.host !== host || !document.body.contains(ui.wrap)) {
      try { if (ui && ui.wrap && ui.wrap.parentNode) ui.wrap.parentNode.removeChild(ui.wrap); } catch (e) {}
      try { if (ui && ui.box && ui.box.parentNode) ui.box.parentNode.removeChild(ui.box); } catch (e) {}
      var wrap = document.createElement("div");
      wrap.setAttribute("style", "position:fixed;left:12px;bottom:12px;z-index:99998;display:flex;flex-direction:column;align-items:flex-start;gap:6px;");
      wrap.innerHTML =
        '<div class="pp-emoji-panel" hidden style="display:none;grid-template-columns:repeat(5,1fr);gap:4px;padding:6px;border-radius:14px;background:rgba(36,26,51,.97);border:1px solid rgba(169,140,247,.55);box-shadow:0 10px 30px rgba(0,0,0,.45);">' +
        EMOJIS.map(function (e) { return '<button class="pp-emoji" data-e="' + e + '" type="button" style="width:40px;height:40px;font-size:22px;line-height:1;border-radius:10px;background:transparent;border:0;cursor:pointer;transition:transform .12s;">' + e + "</button>"; }).join("") +
        "</div>" +
        '<button class="pp-emoji-btn" type="button" title="ارسال ایموجی به حریف" style="width:46px;height:46px;border-radius:50%;font-size:22px;background:rgba(36,26,51,.95);border:1px solid rgba(169,140,247,.65);cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.4);transition:transform .12s;">😊</button>';
      host.appendChild(wrap);
      var panel = wrap.querySelector(".pp-emoji-panel");
      var btn = wrap.querySelector(".pp-emoji-btn");
      btn.addEventListener("click", function () {
        panel.hidden = !panel.hidden;
        panel.style.display = panel.hidden ? "none" : "grid";
      });
      wrap.querySelectorAll(".pp-emoji").forEach(function (b) {
        b.addEventListener("click", function () {
          panel.hidden = true; panel.style.display = "none";
          sendEmoji(key, b.getAttribute("data-e"));
        });
      });
      var box = document.createElement("div");
      box.setAttribute("style", "position:fixed;left:14px;bottom:68px;z-index:99997;display:flex;flex-direction:column-reverse;gap:6px;pointer-events:none;");
      host.appendChild(box);
      ui = EMOJI_UI[key] = { host: host, wrap: wrap, box: box };
    }
    return ui;
  }
  function showBubble(key, emoji, mine, who) {
    var ui = EMOJI_UI[key];
    if (!ui || !ui.box) return null;
    if (!emoji) return null;
    var colors = mine
      ? { bg: "rgba(169,140,247,.22)", bd: "rgba(169,140,247,.75)" }
      : { bg: "rgba(50,38,70,.96)", bd: "rgba(248,197,108,.75)" };
    var b = document.createElement("div");
    b.className = "pp-bubble";
    b.setAttribute("style", "display:flex;align-items:center;gap:6px;padding:5px 10px;border-radius:16px;font-size:20px;line-height:1.5;background:" + colors.bg + ";border:1px solid " + colors.bd + ";box-shadow:0 6px 18px rgba(0,0,0,.35);");
    b.innerHTML = "<span>" + emoji + "</span>" + (who ? '<small style="font-size:11px;opacity:.75;">' + esc(who) + "</small>" : "");
    ui.box.appendChild(b);
    var all = ui.box.querySelectorAll(".pp-bubble");
    if (all.length > 6) all[0].remove();
    setTimeout(function () {
      try {
        b.style.transition = "opacity .35s, transform .35s";
        b.style.opacity = "0"; b.style.transform = "translateY(-6px)";
        setTimeout(function () { try { b.remove(); } catch (e) {} }, 400);
      } catch (e) {}
    }, BUBBLE_MS);
    return b;
  }

  /* ═════════════════════════════════════════════════════════════════
     الف) نبرد زندهٔ دو بازیکن
     ═════════════════════════════════════════════════════════════════ */
  var PVP = { id: null, st: null, off: 0, lastPoll: 0, obs: null, obsEl: null, busy: false };
  var decTimer = null;

  function quizOverlay() {
    var ov = el("gamify-pvp-quiz");
    if (!ov || !ov.classList || !ov.classList.contains("open")) return null;
    return ov;
  }
  function quizModal(ov) { try { return ov.querySelector(".pvp-quiz") || ov; } catch (e) { return null; } }

  function lifePvp(id) { if (!id) return null; var all = lsGet(LS_PVP, {}); return all[id] || null; }
  function lifePvpMark(id, info) { if (!id) return; var all = lsGet(LS_PVP, {}); all[id] = info; lsSet(LS_PVP, all); }

  function pvpIndex(st) {
    if (!st || !st.startedAt || !st.seconds) return -1;
    var t = Date.now() + (Number(PVP.off) || 0);
    if (t < st.startedAt) return -1;
    var step = st.seconds * 1000 + (st.gap || 0);
    var n = st.qCount || (st.questions ? st.questions.length : 5);
    var k = Math.floor((t - st.startedAt) / step);
    if (k < 0) k = 0;
    if (k > n - 1) k = n - 1;
    return k;
  }
  function pvpCur(st) {
    var k = pvpIndex(st);
    if (k < 0 || !st || !st.questions || !st.questions[k]) return null;
    return { k: k, q: st.questions[k] };
  }
  function pvpTally(st) {
    var out = { correct: 0, answered: 0, revealed: 0, total: 0 };
    if (!st) return out;
    out.total = st.qCount || (st.reveal ? st.reveal.length : 0) || 0;
    var rv = st.reveal || [];
    for (var i = 0; i < rv.length; i++) {
      var r = rv[i];
      if (!r) continue;
      out.revealed++;
      if (r.oppPick != null && r.oppPick >= 0) { out.answered++; if (r.oppPick === r.correct) out.correct++; }
    }
    return out;
  }
  function applyElim(modal, idxs) {
    if (!modal || !idxs || !idxs.length) return 0;
    var opts = modal.querySelectorAll(".pvp-opt");
    var n = 0;
    for (var i = 0; i < idxs.length; i++) {
      var b = opts[idxs[i]];
      if (!b || (b.classList && b.classList.contains("pvp-plus-elim"))) continue;
      try { b.classList.add("pvp-plus-elim"); } catch (e) {}
      b.disabled = true;
      try { b.style.opacity = "0.35"; b.style.filter = "grayscale(1)"; b.setAttribute("title", "با کمک «۵۰/۵۰» حذف شد"); } catch (e) {}
      n++;
    }
    return n;
  }
  function domAnswered(modal) {
    try {
      var all = modal.querySelectorAll(".pvp-opt");
      for (var i = 0; i < all.length; i++) {
        var b = all[i];
        if (b.disabled && !(b.classList && b.classList.contains("pvp-plus-elim"))) return true;
      }
    } catch (e) {}
    return false;
  }

  function ensurePvpBar(modal) {
    if (!modal) return null;
    var bar = modal.querySelector("#pvp-plus-bar");
    if (bar) return bar;
    var anchor = modal.querySelector(".pvp-timerbar") || modal.querySelector(".pvp-progress") || null;
    if (!anchor || !anchor.parentNode) return null;
    bar = document.createElement("div");
    bar.id = "pvp-plus-bar";
    bar.setAttribute("style", "display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin:8px 0 2px;");
    bar.innerHTML =
      '<span style="display:flex;gap:6px;flex-wrap:wrap;">' +
      '<button id="pvp-plus-fifty" class="gamify-btn sm" type="button">🎯 ۵۰/۵۰ حذف دو گزینه</button>' +
      "</span>" +
      '<span id="pvp-plus-tally" style="font-size:12px;opacity:.85;"></span>';
    anchor.parentNode.insertBefore(bar, anchor.nextSibling);
    var bf = bar.querySelector("#pvp-plus-fifty");
    if (bf) bf.addEventListener("click", function () { usePvpFifty(); });
    return bar;
  }

  function scheduleDecorate() { if (decTimer) return; decTimer = setTimeout(function () { decTimer = null; decoratePvp(); }, 60); }

  function decoratePvp() {
    if (PVP.busy) return;
    PVP.busy = true;
    try {
      var ov = quizOverlay();
      if (!ov) return;
      if (PVP.obsEl !== ov) attachPvpObserver(ov);
      var modal = quizModal(ov);
      if (!modal || !modal.querySelector(".pvp-opts")) return;
      var bar = ensurePvpBar(modal);
      if (!bar) return;
      ensureEmojiUI("pvp", ov);

      var st = PVP.st, id = PVP.id;
      var cur = st ? pvpCur(st) : null;
      var k = cur ? cur.k : -1;
      var t = pvpTally(st);

      var tallyEl = bar.querySelector("#pvp-plus-tally");
      var tallyTxt = "حریف: " + fa(t.correct) + " درست از " + fa(t.answered) + " پاسخ" + (t.total && t.revealed < t.total ? " · " + fa(t.total - t.revealed) + " سؤال مانده" : "");
      if (tallyEl) setText(tallyEl, tallyTxt);

      var os = el("pvp-opp-score");
      if (os) {
        setText(os, fa(t.correct));
        var sp = os.parentNode;
        if (sp) {
          if (!sp.querySelector(".pvp-plus-tag")) {
            var tag = document.createElement("small");
            tag.className = "pvp-plus-tag";
            tag.setAttribute("style", "opacity:.75;font-size:11px;");
            tag.textContent = " درست";
            sp.appendChild(tag);
          }
          if (sp.getAttribute("title") !== "تعداد پاسخ‌های درست حریف تا این لحظه — امتیاز نهایی را سرور در پایان حساب می‌کند") {
            sp.setAttribute("title", "تعداد پاسخ‌های درست حریف تا این لحظه — امتیاز نهایی را سرور در پایان حساب می‌کند");
          }
        }
      }

      var life = lifePvp(id);
      var mineDone = false;
      try { mineDone = !!(st && st.myAnswered && st.myAnswered[k]) || domAnswered(modal); } catch (e) {}
      var bf = bar.querySelector("#pvp-plus-fifty");
      if (bf) {
        bf.disabled = !!life || mineDone || !st;
        setText(bf, life ? "🎯 ۵۰/۵۰ استفاده شد (این مسابقه)" : "🎯 ۵۰/۵۰ حذف دو گزینه");
      }
      if (k >= 0 && life && life.q === k && life.elim && life.elim.length) applyElim(modal, life.elim);
    } finally {
      PVP.busy = false;
    }
  }

  function attachPvpObserver(ov) {
    try { if (PVP.obs) PVP.obs.disconnect(); } catch (e) {}
    PVP.obsEl = ov; PVP.obs = null;
    try {
      if (window.MutationObserver) {
        PVP.obs = new window.MutationObserver(function () { scheduleDecorate(); });
        PVP.obs.observe(ov, { childList: true, subtree: true });
      }
    } catch (e) {}
  }

  function usePvpFifty() {
    var st = PVP.st, cur = st ? pvpCur(st) : null;
    if (!st || !cur) { toast("الان سؤالی در جریان نیست."); return; }
    var id = PVP.id, k = cur.k, q = cur.q;
    if (lifePvp(id)) { toast("🎯 در این مسابقه یک‌بار از «۵۰/۵۰» استفاده کرده‌ای — هر مسابقه فقط یک‌بار."); return; }
    if (!bankList().length) { toast("🎯 بانک سؤال روی این صفحه نیست؛ اول بستهٔ «بانک سؤال مشترک» را نصب/به‌روزرسانی کن."); return; }
    var item = findBankQ(q.id, q.title);
    var n = (q.options || []).length;
    var c = correctOf(item, n);
    if (c < 0) { toast("🎯 برای این سؤال در «بانک سؤال» اطلاعاتی نیست؛ کمک مصرف نشد."); return; }
    var ov = quizOverlay();
    var modal = ov ? quizModal(ov) : null;
    if (!modal) return;
    var wrong = [];
    for (var i = 0; i < n; i++) if (i !== c) wrong.push(i);
    var pick = shuffle(wrong).slice(0, Math.min(2, wrong.length));
    applyElim(modal, pick);
    lifePvpMark(id, { kind: "fifty", q: k, elim: pick });
    toast("🎯 دو گزینهٔ غلط حذف شد.");
    decoratePvp();
  }

  function applyPvpBattle(b) {
    if (!b || !b.id) return;
    PVP.id = b.id;
    PVP.st = b;
    if (typeof b.serverNow === "number") PVP.off = b.serverNow - Date.now();
    PVP.lastPoll = Date.now();
    scheduleDecorate();
  }
  function pollPvp() {
    if (!PVP.id || !rawFetch) return;
    jfetch("/api/pvp?action=state&id=" + encodeURIComponent(PVP.id)).then(function (j) { if (j && j.id) applyPvpBattle(j); }).catch(function () {});
  }

  /* ── ایموجی نبرد زنده: از راه پیام چت (نشانِ نامرئی) ── */
  function sendPvpEmoji(e) {
    showBubble("pvp", e, true, "");
    var st = PVP.st;
    if (!st || !st.opponent || !st.opponent.id || !rawFetch) return;
    try {
      jfetch("/api/messages", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: st.opponent.id, text: ZW + e })
      }).then(function (j) {
        if (j && j.blocked) toast("چت بین شما بسته است؛ ایموجی نرسید.");
        else if (j && j.error) toast("⚠️ ایموجی نرسید.");
      }).catch(function () {});
    } catch (err) {}
  }
  function onChatForEmoji(d) {
    try {
      if (!d || !d.from || !d.text) return;
      var txt = String(d.text);
      if (txt.indexOf(ZW) !== 0) return;
      var emoji = txt.slice(ZW.length).trim();
      if (!emoji) return;
      if (!quizOverlay()) return;  // پنجرهٔ نبرد باز نیست → کاری نکن
      var st = PVP.st;
      if (!st || !st.opponent || String(d.from) !== String(st.opponent.id)) return;
      showBubble("pvp", emoji, false, d.fromName || st.opponent.name || "");
    } catch (e) {}
  }

  /* ═════════════════════════════════════════════════════════════════
     ب) نبرد قبیله‌ای
     ═════════════════════════════════════════════════════════════════ */
  var TB = {
    battleId: null, myTribeId: null, me: null, meAt: 0,
    data: null, lastBattles: 0, lastEmoji: 0, seen: {}, busy: false,
    obs: null, obsEl: null, clickHook: false, lastClick: 0
  };

  function tribeOverlay() {
    var ov = el("gamify-tribes-overlay");
    if (!ov || !ov.classList || !ov.classList.contains("open")) return null;
    return ov;
  }
  function tribeQuiz(ov) {
    if (!ov) return null;
    var modal = ov.querySelector(".gamify-modal");
    if (!modal) return null;
    var opts = modal.querySelectorAll("[data-opt]");
    if (!opts.length) return null;
    var qEl = modal.querySelector("h3.gamify-q");
    if (!qEl) return null;
    return { ov: ov, modal: modal, opts: opts, q: norm(qEl.textContent), top: modal.querySelector(".gamify-quiz-top") || modal, timer: modal.querySelector(".gamify-timer") };
  }

  function hookBattleClicks() {
    if (TB.clickHook) return;
    TB.clickHook = true;
    document.addEventListener("click", function (ev) {
      try {
        var t = ev.target;
        while (t && t !== document.body) {
          if (t.getAttribute && t.getAttribute("data-battle")) {
            var id = t.getAttribute("data-battle");
            if (id && id !== TB.battleId) { TB.battleId = id; TB.data = null; TB.lastBattles = 0; }
            TB.lastClick = Date.now();
            return;
          }
          t = t.parentNode;
        }
      } catch (e) {}
    }, true);
  }

  function fetchMe(cb) {
    if (TB.me) { cb && cb(); return; }
    jfetch("/api/me").then(function (j) { if (j && j.id) { TB.me = j; TB.meAt = Date.now(); } cb && cb(); }).catch(function () { cb && cb(); });
  }
  function fetchMyTribe(cb) {
    if (TB.myTribeId) { cb && cb(); return; }
    jfetch("/api/tribes?mine=1").then(function (j) {
      if (j && j.tribe && j.tribe.id) TB.myTribeId = j.tribe.id;
      cb && cb();
    }).catch(function () { cb && cb(); });
  }
  function fetchBattles(force) {
    if (!TB.myTribeId) return;
    if (!force && Date.now() - TB.lastBattles < POLL_TB) return;
    TB.lastBattles = Date.now();
    jfetch("/api/tribes/" + encodeURIComponent(TB.myTribeId) + "?action=battles").then(function (rows) {
      if (Array.isArray(rows)) { TB.data = rows; decorateTribe(); }
    }).catch(function () {});
  }
  function pickBattle() {
    if (!TB.data || !TB.data.length) return null;
    var i;
    if (TB.battleId) for (i = 0; i < TB.data.length; i++) if (String(TB.data[i].id) === String(TB.battleId)) return TB.data[i];
    // پشتیبان: آخرین نبرد فعال
    var act = TB.data.filter(function (b) { return b && b.status === "active"; }).sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });
    if (act[0]) { TB.battleId = act[0].id; return act[0]; }
    return null;
  }
  function currentTribeQuestion(battle, quiz) {
    if (!battle || !Array.isArray(battle.questions) || !battle.questions.length) return null;
    var idx = NaN;
    try {
      if (quiz && quiz.top) {
        var m = /(?:سؤال\s*)?([۰-۹0-9]+)\s*(?:از|سؤال)/.exec(norm(quiz.top.textContent));
        if (m) idx = faToNum(m[1]) - 1;
      }
    } catch (e) {}
    if (isFinite(idx) && idx >= 0 && idx < battle.questions.length) {
      var byIdx = battle.questions[idx];
      if (byIdx && (!quiz || !quiz.q || norm(byIdx.title) === quiz.q)) return { k: idx, q: byIdx };
    }
    if (quiz && quiz.q) {
      for (var i = 0; i < battle.questions.length; i++) if (norm(battle.questions[i].title) === quiz.q) return { k: i, q: battle.questions[i] };
    }
    return isFinite(idx) && idx >= 0 && idx < battle.questions.length ? { k: idx, q: battle.questions[idx] } : null;
  }

  function lifeTb(id) { if (!id) return null; var all = lsGet(LS_TB, {}); return all[id] || null; }
  function lifeTbMark(id, info) { if (!id) return; var all = lsGet(LS_TB, {}); all[id] = info; lsSet(LS_TB, all); }

  function ensureTribeBar(quiz) {
    if (!quiz || !quiz.modal) return null;
    var bar = quiz.modal.querySelector("#pp-tribe-bar");
    if (bar) return bar;
    var anchor = quiz.timer || quiz.modal.querySelector(".gamify-timer") || quiz.modal.querySelector(".gamify-opts");
    if (!anchor || !anchor.parentNode) return null;
    bar = document.createElement("div");
    bar.id = "pp-tribe-bar";
    bar.setAttribute("style", "display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin:8px 0 2px;");
    bar.innerHTML =
      '<button id="pp-tribe-fifty" class="gamify-btn sm" type="button">🎯 ۵۰/۵۰ حذف دو گزینه</button>' +
      '<span id="pp-tribe-score" style="font-size:12px;opacity:.9;"></span>';
    anchor.parentNode.insertBefore(bar, anchor.nextSibling);
    var bf = bar.querySelector("#pp-tribe-fifty");
    if (bf) bf.addEventListener("click", function () { useTribeFifty(); });
    return bar;
  }

  function decorateTribe() {
    if (TB.busy) return;
    TB.busy = true;
    try {
      var ov = tribeOverlay();
      if (!ov) return;
      var quiz = tribeQuiz(ov);
      if (!quiz) return;
      if (TB.obsEl !== ov) attachTribeObserver(ov);
      ensureEmojiUI("tribe", ov);
      var bar = ensureTribeBar(quiz);
      if (!bar) return;

      var battle = pickBattle();
      var cur = battle ? currentTribeQuestion(battle, quiz) : null;
      var life = lifeTb(TB.battleId);

      var bf = bar.querySelector("#pp-tribe-fifty");
      if (bf) {
        bf.disabled = !!life || !battle || !cur;
        setText(bf, life ? "🎯 ۵۰/۵۰ استفاده شد (این نبرد)" : "🎯 ۵۰/۵۰ حذف دو گزینه");
      }
      var sc = bar.querySelector("#pp-tribe-score");
      if (sc) {
        if (battle && TB.myTribeId) {
          var iAmA = String(battle.tribeA) === String(TB.myTribeId);
          var mine = Number(iAmA ? battle.scoreA : battle.scoreB) || 0;
          var theirs = Number(iAmA ? battle.scoreB : battle.scoreA) || 0;
          setText(sc, "🛡️ ما: " + fa(mine) + " · ⚔️ حریف: " + fa(theirs));
          sc.setAttribute("title", "امتیاز زندهٔ دو قبیله — هر عضو بعد از پایان مسابقهٔ خودش به این عدد اضافه می‌کند");
        } else {
          setText(sc, "");
        }
      }
      if (cur && life && life.k === cur.k && life.elim && life.elim.length) {
        for (var i = 0; i < life.elim.length; i++) {
          var b = quiz.opts[life.elim[i]];
          if (!b || (b.classList && b.classList.contains("pp-tb-elim"))) continue;
          try { b.classList.add("pp-tb-elim"); } catch (e) {}
          b.disabled = true;
          try { b.style.opacity = "0.35"; b.style.filter = "grayscale(1)"; b.setAttribute("title", "با کمک «۵۰/۵۰» حذف شد"); } catch (e) {}
        }
      }
    } finally {
      TB.busy = false;
    }
  }

  function attachTribeObserver(ov) {
    try { if (TB.obs) TB.obs.disconnect(); } catch (e) {}
    TB.obsEl = ov; TB.obs = null;
    try {
      if (window.MutationObserver) {
        TB.obs = new window.MutationObserver(function () { TB.busy = false; decorateTribe(); });
        TB.obs.observe(ov, { childList: true, subtree: true });
      }
    } catch (e) {}
  }

  function useTribeFifty() {
    var ov = tribeOverlay();
    var quiz = ov ? tribeQuiz(ov) : null;
    if (!quiz) { toast("الان مسابقه‌ای در جریان نیست."); return; }
    var battle = pickBattle();
    if (!battle) { toast("🎯 اطلاعات این نبرد هنوز نرسیده؛ یک لحظه بعد دوباره بزن."); return; }
    var cur = currentTribeQuestion(battle, quiz);
    if (!cur) { toast("🎯 سؤال جاری پیدا نشد؛ یک لحظه بعد دوباره بزن."); return; }
    if (lifeTb(TB.battleId)) { toast("🎯 در این نبرد یک‌بار از «۵۰/۵۰» استفاده کرده‌ای — هر نبرد فقط یک‌بار."); return; }
    var q = cur.q, n = (q.options || []).length;
    var c = Number(q.correct);
    if (!isFinite(c) || c < 0 || c >= n) {
      var item = findBankQ(q.id, q.title);
      c = correctOf(item, n);
    }
    if (!isFinite(c) || c < 0 || c >= n) { toast("🎯 برای این سؤال اطلاعاتی نیست؛ کمک مصرف نشد."); return; }
    var wrong = [];
    for (var i = 0; i < n; i++) if (i !== c) wrong.push(i);
    var pick = shuffle(wrong).slice(0, Math.min(2, wrong.length));
    for (var j = 0; j < pick.length; j++) {
      var b = quiz.opts[pick[j]];
      if (!b) continue;
      try { b.classList.add("pp-tb-elim"); } catch (e) {}
      b.disabled = true;
      try { b.style.opacity = "0.35"; b.style.filter = "grayscale(1)"; b.setAttribute("title", "با کمک «۵۰/۵۰» حذف شد"); } catch (e) {}
    }
    lifeTbMark(TB.battleId, { kind: "fifty", k: cur.k, elim: pick });
    toast("🎯 دو گزینهٔ غلط حذف شد.");
    decorateTribe();
  }

  /* ── ایموجی نبرد قبیله: از راه رکورد استوری (فید پنهان) ── */
  function sendTribeEmoji(e) {
    showBubble("tribe", e, true, "");
    if (!TB.battleId || !rawFetch) return;
    fetchMe(function () {
      var uid36 = (TB.me && TB.me.id ? String(TB.me.id).slice(-8) : "u") + "-";
      var rid = T_PREFIX + uid36 + Date.now().toString(36) + "-" + Math.floor(Math.random() * 46656).toString(36);
      var body = JSON.stringify({ k: "e", e: e, b: TB.battleId, t: TB.myTribeId || "", u: (TB.me && TB.me.id) || "", n: (TB.me && TB.me.name) || "", at: Date.now() });
      jfetch("/api/feed?type=story", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: rid, category: "eng", title: "به‌روزرسانی همراهی", options: [], correct: 0, explanation: "", media: body })
      }).then(function (j) {
        if (!j || !j.ok) toast("⚠️ ایموجی نرسید (استوری ثبت نشد).");
        else if (j.status === "pending") toast("⚠️ ایموجی به بقیه نمی‌رسد: «بررسی استوری‌ها پیش از انتشار» روشن است.");
      }).catch(function () {});
    });
  }
  function pollTribeEmojis() {
    if (!TB.battleId || !rawFetch) return;
    if (Date.now() - TB.lastEmoji < POLL_EMOJI) return;
    TB.lastEmoji = Date.now();
    var meId = TB.me && TB.me.id;
    jfetch("/api/feed?type=stories", { cache: "no-store" }).then(function (rows) {
      if (!Array.isArray(rows)) return;
      var fresh = [];
      rows.forEach(function (r) {
        if (!r || String(r.id || "").indexOf(T_PREFIX) !== 0) return;
        var rec = null;
        try { rec = JSON.parse(String(r.media || "")); } catch (e) { return; }
        if (!rec || rec.k !== "e" || String(rec.b) !== String(TB.battleId)) return;
        if (meId && String(rec.u) === String(meId)) return;
        if (TB.seen[r.id]) return;
        TB.seen[r.id] = 1;
        var at = Number(rec.at) || Number(r.createdAt) || 0;
        if (Date.now() - at > 120000) return;   // فقط ایموجی‌های تازه
        fresh.push(rec);
      });
      fresh.slice(-5).forEach(function (rec) { showBubble("tribe", rec.e, false, rec.n || ""); });
    }).catch(function () {});
  }

  /* ═════════════════════════════════════════════════════════════════
     حلقهٔ سبک + رویدادها
     ═════════════════════════════════════════════════════════════════ */
  function sendEmoji(key, e) {
    if (key === "pvp") sendPvpEmoji(e);
    else if (key === "tribe") sendTribeEmoji(e);
  }

  function tick() {
    var ov = quizOverlay();
    if (ov) {
      decoratePvp();
      if (PVP.id && Date.now() - PVP.lastPoll > POLL_PVP) { PVP.lastPoll = Date.now(); pollPvp(); }
    } else PVP.lastPoll = 0;

    var tov = tribeOverlay();
    if (tov) {
      hookBattleClicks();
      var quiz = tribeQuiz(tov);
      if (quiz) {
        if (TB.obsEl !== tov) attachTribeObserver(tov);
        decorateTribe();
        fetchMyTribe(function () { fetchBattles(false); });
        pollTribeEmojis();
      }
    }
  }
  setInterval(tick, 900);

  window.addEventListener("gamify:rt", function (e) {
    try {
      var d = e.detail && e.detail.data, type = e.detail && e.detail.type;
      if (!type) return;
      if (type === "chat:message") onChatForEmoji(d);
      else if (type === "pvp:accepted" && d && d.battle) applyPvpBattle(d.battle);
      else if ((type === "pvp:q" || type === "pvp:reveal" || type === "pvp:opp-answered") && d && PVP.id && d.id === PVP.id) { PVP.lastPoll = 0; pollPvp(); scheduleDecorate(); }
      else if (type === "pvp:finished" && d && d.battle && d.battle.id === PVP.id) { PVP.st = d.battle; PVP.id = null; }
    } catch (err) {}
  });

  /* قلاب تست (فقط برای آزمون خودکار؛ در بازی کاری نمی‌کند) */
  window.__gamifyPvpPlusTest = {
    PVP: PVP, TB: TB, emojis: EMOJIS, zw: ZW, tPrefix: T_PREFIX,
    findBankQ: findBankQ, correctOf: correctOf, pvpTally: pvpTally, pvpIndex: pvpIndex, pvpCur: pvpCur,
    decoratePvp: decoratePvp, decorateTribe: decorateTribe, tribeQuiz: tribeQuiz, pickBattle: pickBattle,
    currentTribeQuestion: currentTribeQuestion, useTribeFifty: useTribeFifty, usePvpFifty: usePvpFifty,
    sendPvpEmoji: sendPvpEmoji, sendTribeEmoji: sendTribeEmoji, onChatForEmoji: onChatForEmoji,
    showBubble: showBubble, EMOJI_UI: EMOJI_UI, lifePvp: lifePvp, lifeTb: lifeTb,
    pollTribeEmojis: pollTribeEmojis, fetchBattles: fetchBattles, fetchMyTribe: fetchMyTribe, fetchMe: fetchMe
  };
})();
// PVP-PLUS-END
