/* 🖼️ همگام‌سازی + اصلاح آواتار — نسخهٔ ۲
   ۱) عکس واقعی هر بازیکن را از سرور می‌گیرد و روی پست/استوری/پیام/گفت‌وگو می‌نشاند.
   ۲) هر آواتار «ناقص» را در کل حافظهٔ بازی اصلاح می‌کند:
      آواتاری که فقط { seed: N } است یا {} خالی، در بازی به شکل SVG با رنگ‌های
      نامعتبر کشیده و «دایرهٔ مشکی» دیده می‌شود. برای چنین کاربری یک عکس واقعی
      (۱ تا ۲۰) بر اساس نامش انتخاب می‌شود — با همان روش خودِ بازی.
   ۳) آواتار سالم (عکس انتخابی کاربر یا پروفایل کامل SVG) هرگز تغییر نمی‌کند.
   سبک است و فقط روی حافظهٔ محلی کار می‌کند. */
(function () {
  "use strict";
  if (window.__gamifyAvatarSync) return;
  window.__gamifyAvatarSync = true;
  var AVATAR_SYNC_V = 2;

  var LS_KEY = "gamify2-store-v2";

  // ---- همان روش خودِ بازی برای انتخاب عکس از روی نام ----
  var FEM_RE = /^(سارا|مریم|زهرا|فاطمه|نرگس|لیلا|الهام|شیرین|سمیرا|پریسا|نازنین|مینا|مهسا|نیلوفر|سحر|شبنم|آزاده|معصومه|زینب|ریحانه|هانیه|فرشته|مهناز|شهلا|پروین|اعظم|سمانه|سپیده|نسرین|مونا|غزل|یاسمن|نگار|نیکا|آیدا|رویا|راضیه|محبوبه|صدیقه|طاهره|کبری|سکینه|خدیجه|مرضیه|فائزه|ملیکا|هستی|ترانه|بهار|ندا|لاله|شقایق|ژیلا|آرزو|افسانه|مهری|منیژه|فریبا|فرزانه|شیوا|شهره|الناز|گلناز|پریا|پانته‌آ|نوشین|نسیم|مهتاب|ستاره|درسا|دنیا|آتنا|آناهیتا|هدیه|هلیا|کیمیا|روژان|نیایش|پرنیان)/;
  var F = [2, 4, 6, 9, 15, 16, 18];
  var M = [1, 3, 5, 7, 8, 10, 11, 12, 13, 14, 17, 19, 20];

  function pickByName(name) {
    var n = String(name == null ? "" : name).trim();
    var L = FEM_RE.test(n) ? F : M;
    var h = 0;
    for (var i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) >>> 0;
    return { img: L[h % L.length] };
  }
  function imgOf(a) {
    if (typeof a === "number") return (a >= 1 && a <= 20) ? Math.round(a) : 0;
    if (!a || typeof a !== "object") return 0;
    var i = Math.round(Number(a.img) || 0);
    return (i >= 1 && i <= 20) ? i : 0;
  }
  function isFullSvg(a) {
    if (!a || typeof a !== "object") return false;
    return !!(a.bg && a.skin && a.outfit && a.hair && a.hairColor && a.eyes);
  }
  function usable(a) { return imgOf(a) > 0 || isFullSvg(a); }

  // آواتار «ناقص»: {} خالی، یا آبجکتی که فقط seed (و حداکثر id) دارد
  function isBadAvatar(v) {
    if (!v || typeof v !== "object" || Array.isArray(v)) return false;
    if (usable(v)) return false;
    var k = Object.keys(v);
    if (k.length === 0) return true;
    for (var i = 0; i < k.length; i++) { if (k[i] !== "seed" && k[i] !== "id") return false; }
    return true;
  }
  function normAvatar(a, name) {
    if (typeof a === "number") { var i = Math.round(a); return (i >= 1 && i <= 20) ? { img: i } : pickByName(name); }
    if (usable(a)) return a;
    return pickByName(name);
  }

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function liveStore() {
    try { if (window.__gamifyLiveGet) { var s = window.__gamifyLiveGet(); if (s && typeof s === "object") return s; } } catch (e) {}
    return readStore();
  }
  function setStore(fn) {
    try {
      if (window.__gamifyLiveSet) { window.__gamifyLiveSet(function (s) { var n = fn(s); return n || s; }); return true; }
      var st = readStore(); if (!st) return false; var n2 = fn(st);
      if (n2) localStorage.setItem(LS_KEY, JSON.stringify(n2));
      return true;
    } catch (e) { return false; }
  }
  function same(a, b) { try { return JSON.stringify(a) === JSON.stringify(b); } catch (e) { return false; } }
  function isReal(p) {
    if (!p || !p.id) return false;
    if (p.isReal || p.kind === "real") return true;
    try { if (window.__gamifyServer && typeof window.__gamifyServer.isReal === "function" && window.__gamifyServer.isReal(p.id)) return true; } catch (e) {}
    return false;
  }

  // ---------- پویش عمیق: شناسایی آواتارهای ناقص در هر گوشهٔ حافظهٔ بازی ----------
  var AV_KEYS = { avatar: 1, av: 1, photo: 1, pic: 1, image: 1 };
  function hintOf(o, prev) {
    if (!o || typeof o !== "object") return prev;
    var h = o.name, a = o.author, d = o.displayName, u = o.username, t = o.title;
    if (typeof h === "string" && h) return h;
    if (typeof a === "string" && a) return a;
    if (typeof d === "string" && d) return d;
    if (typeof u === "string" && u) return u;
    if (typeof t === "string" && t) return t;
    if (a && typeof a === "object" && typeof a.name === "string" && a.name) return a.name;
    return prev;
  }
  function scan(node, depth) {
    if (depth > 12 || !node || typeof node !== "object") return 0;
    var n = 0, k, i;
    if (Array.isArray(node)) {
      for (i = 0; i < node.length; i++) n += scan(node[i], depth + 1);
      return n;
    }
    for (k in node) {
      if (!Object.prototype.hasOwnProperty.call(node, k)) continue;
      var v = node[k];
      if (isBadAvatar(v)) { n++; continue; }
      if (v && typeof v === "object") {
        if (AV_KEYS[k] && isBadAvatar(v)) { n++; continue; }
        n += scan(v, depth + 1);
      }
    }
    return n;
  }
  function deepFix(node, hint, depth) {
    if (depth > 12 || !node || typeof node !== "object") return 0;
    var n = 0, k, i;
    if (Array.isArray(node)) {
      for (i = 0; i < node.length; i++) {
        var el = node[i];
        if (isBadAvatar(el)) { node[i] = useMap(el, hint); n++; continue; }
        if (el && typeof el === "object") n += deepFix(el, hintOf(el, hint), depth + 1);
      }
      return n;
    }
    for (k in node) {
      if (!Object.prototype.hasOwnProperty.call(node, k)) continue;
      var v = node[k];
      if (isBadAvatar(v)) { node[k] = useMap(node, hint); n++; continue; }
      if (v && typeof v === "object") {
        if (AV_KEYS[k] && isBadAvatar(v)) { node[k] = useMap(node, hint); n++; continue; }
        n += deepFix(v, hintOf(node, hint), depth + 1);
      }
    }
    return n;
  }
  // ---------- نقشهٔ «شناسه/نام → عکس واقعی» تا همهٔ پنل‌ها یک عکس را نشان دهند ----------
  var MAP_ID = {}, MAP_NAME = {};
  function useMap(obj, hint) {
    if (obj && typeof obj === "object" && !Array.isArray(obj)) {
      var id = obj.id;
      if (typeof id === "string" && MAP_ID[id]) return MAP_ID[id];
      if (typeof id === "number" && MAP_ID[String(id)]) return MAP_ID[String(id)];
      var nm = hintOf(obj, hint);
      if (nm && MAP_NAME[nm]) return MAP_NAME[nm];
      return pickByName(nm || hint);
    }
    return pickByName(hint);
  }

  function clone(o) { try { return JSON.parse(JSON.stringify(o)); } catch (e) { return null; } }

  function normalize() {
    var s = liveStore(); if (!s) return false;
    var changed = false;

    // ---------- ۰) نقشهٔ «شناسه/نام → عکس» از فهرست بازیکنان (قبل از اصلاح) ----------
    MAP_ID = {}; MAP_NAME = {};
    (s.players || []).forEach(function (p) {
      if (!p || !p.id || !usable(p.avatar)) return;
      if (isReal(p)) MAP_ID[String(p.id)] = p.avatar;
      if (p.name && !MAP_NAME[p.name]) MAP_NAME[p.name] = p.avatar;
    });

    // ---------- ۱) آواتار هر بازیکنِ ناقص را اصلاح کن ----------
    var players = (s.players || []).map(function (p) {
      if (!p || !p.id) return p;
      if (usable(p.avatar)) return p;
      changed = true;
      var o = {}; for (var k in p) if (Object.prototype.hasOwnProperty.call(p, k)) o[k] = p[k];
      o.avatar = useMap(p, p.name);
      return o;
    });

    // ---------- ۲) نقشهٔ عکس واقعی هر بازیکن (برای هم‌تراز کردن داده‌های قدیمی) ----------
    var map = {};
    players.forEach(function (p) { if (isReal(p) && usable(p.avatar)) map[p.id] = p.avatar; });

    function fixList(list) {
      return (list || []).map(function (it) {
        if (!it || !it.id) return it;
        var aid = it.authorId;
        if (aid && map[aid]) {
          if (!same(it.avatar, map[aid])) { changed = true; return Object.assign({}, it, { avatar: map[aid] }); }
          return it;
        }
        if (!usable(it.avatar) && (it.author || it.name)) {
          changed = true;
          return Object.assign({}, it, { avatar: normAvatar(it.avatar, it.author || it.name) });
        }
        return it;
      });
    }
    var np = fixList(s.posts), ns = fixList(s.stories);
    var nmsgs = (s.messages || []).map(function (m) {
      if (!m) return m;
      var key = m.thread;
      if (key && map[key] && !same(m.avatar, map[key])) { changed = true; return Object.assign({}, m, { avatar: map[key] }); }
      if (key && isBadAvatar(m.avatar)) {
        changed = true;
        var mp = players.filter(function (p) { return p.id === key; })[0] || {};
        return Object.assign({}, m, { avatar: useMap(mp.id ? mp : { id: key, name: mp.name }, mp.name) });
      }
      return m;
    });

    // ---------- ۳) آواتار خودِ کاربر (اگر ناقص باشد) ----------
    var prof = s.profile, nprofile = prof;
    if (prof && isBadAvatar(prof.avatar)) {
      changed = true;
      nprofile = Object.assign({}, prof, { avatar: useMap(prof, prof.name) });
    }

    // ---------- ۴) اول با عکس واقعیِ بازیکنان هم‌تراز کن، بعد کل حافظه را پویش کن ----------
    var aligned = Object.assign({}, s, {
      players: players, posts: np, stories: ns, messages: nmsgs,
      profile: nprofile || s.profile
    });
    var bad = 0;
    try { bad = scan(aligned, 0); } catch (e) { bad = 0; }
    var out = aligned;
    if (bad > 0) {
      var cl2 = clone(aligned);
      if (cl2) {
        var fixed = 0;
        try { fixed = deepFix(cl2, "", 0); } catch (e) { fixed = 0; }
        if (fixed > 0) { out = cl2; changed = true; }
      }
    }

    if (!changed) return false;
    setStore(function () { return out; });
    return true;
  }

  function bump() { try { normalize(); } catch (e) {} }
  setInterval(bump, 5000);
  setTimeout(bump, 2000);
  setTimeout(bump, 8000);
  try { window.addEventListener("gamify:players", bump); } catch (e) {}
  try { window.addEventListener("gamify:synced", bump); } catch (e) {}
  try { document.addEventListener("visibilitychange", function () { if (!document.hidden) bump(); }); } catch (e) {}
  try { window.__gamifyAvatarNorm = normAvatar; window.__gamifyAvatarSyncV = AVATAR_SYNC_V; } catch (e) {}
})();
