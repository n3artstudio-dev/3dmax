import { cookies, headers } from "next/headers";
import { fixAvatar } from "@/lib/avatar-guard";
import { NextResponse } from "next/server";
import { randomBytes, randomUUID } from "node:crypto";
import { eq, and, lt, or } from "drizzle-orm";
import { db } from "@/db";
import { users, sessions, type UserRow } from "@/db/schema";

export const uid = (p = "") => p + randomUUID().replace(/-/g, "").slice(0, 12);
export const now = () => Date.now();

export function pub(u: UserRow) {
  return {
    id: u.id,
    name: u.name,
    avatar: fixAvatar(u.avatar, u.name),
    bio: u.bio,
    role: u.role,
    email: u.email,
    phone: u.phone,
    provider: u.provider,
    orgId: u.orgId,
    xp: u.xp,
    coins: u.coins,
    cups: u.cups,
    streak: u.streak,
    wins: u.wins,
    played: u.played,
    rating: u.rating,
    weekXp: u.weekXp,
    level: u.level ?? Math.floor((u.xp ?? 0) / 250) + 1,
    interests: u.interests ?? [],
    friends: u.friends ?? [],
    private: !!u.isPrivate,
    isDemo: !!u.isDemo,
    isReal: !u.isDemo,
    last_seen: u.lastSeen,
    lastSeen: u.lastSeen,
    created_at: u.createdAt,
    createdAt: u.createdAt,
  };
}

export async function getCurrentToken(): Promise<string> {
  try {
    const jar = await cookies();
    const h = await headers();
    return jar.get("gtok")?.value || jar.get("gm_session")?.value || h.get("x-gamify-token") || "";
  } catch {
    return "";
  }
}

export async function getSessionUser(): Promise<UserRow | null> {
  try {
    // 🔒 هویت فقط از نشست معتبر (کوکی یا توکن) خوانده می‌شود.
    // هدرهای شناسه (x-gamify-user-id / local-id / phone / email / profile) هیچ‌گاه
    // برای انتخاب یا ساخت کاربر استفاده نمی‌شوند — جلوگیری از جعل هویت.
    let tok = "";
    try {
      const jar = await cookies();
      tok = jar.get("gtok")?.value || jar.get("gm_session")?.value || "";
    } catch { /* ignore */ }
    if (!tok) {
      try {
        const h = await headers();
        tok = h.get("x-gamify-token") || (h.get("authorization") || "").replace(/^Bearer\s+/i, "") || "";
      } catch { /* ignore */ }
    }
    if (!tok) return null;
    const s = await db.select().from(sessions).where(eq(sessions.token, tok)).limit(1);
    if (!s[0] || s[0].expires < now()) return null;
    const rows = await db.select().from(users).where(and(eq(users.id, s[0].userId), eq(users.banned, false))).limit(1);
    if (!rows[0]) return null;
    await db.update(users).set({ lastSeen: now() }).where(eq(users.id, rows[0].id));
    return { ...rows[0], lastSeen: now() };
  } catch {
    return null;
  }
}

export async function getSessionUserFromToken(tok: string | undefined | null): Promise<UserRow | null> {
  if (!tok) return null;
  try {
    const s = await db.select().from(sessions).where(eq(sessions.token, tok)).limit(1);
    if (!s[0] || s[0].expires < now()) return null;
    const rows = await db.select().from(users).where(eq(users.id, s[0].userId)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export function newToken() {
  return "t" + randomBytes(24).toString("hex");
}

export async function createSession(userId: string) {
  const token = newToken();
  const csrf = randomBytes(16).toString("hex");
  await db.insert(sessions).values({ token, userId, csrf, expires: now() + 30 * 86400000 });
  try { await db.delete(sessions).where(lt(sessions.expires, now())); } catch { /* ignore */ }
  return { token, csrf };
}

export function setAuthCookie(res: NextResponse, token: string) {
  const isSecure = (process.env.BASE_URL || "").startsWith("https");
  res.cookies.set("gtok", token, {
    path: "/",
    httpOnly: true,
    sameSite: isSecure ? "none" : "lax",
    secure: isSecure,
    maxAge: 30 * 86400,
  });
  res.cookies.set("gm_session", token, {
    path: "/",
    httpOnly: true,
    sameSite: isSecure ? "none" : "lax",
    secure: isSecure,
    maxAge: 30 * 86400,
  });
  res.headers.set("x-gamify-token", token);
  return res;
}

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}
