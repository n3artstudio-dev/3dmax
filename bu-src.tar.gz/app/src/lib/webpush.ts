/**
 * 🔔 موتور ارسال Web Push — پیاده‌سازی کامل RFC 8291 (رمزنگاری) + RFC 8188 (aes128gcm) + RFC 8292 (VAPID)
 *
 * چرا دستی؟ چون هیچ بستهٔ npm اضافه‌ای روی سرور نصب نمی‌شود؛ فقط از ماژول داخلی node:crypto
 * استفاده می‌کنیم. نتیجه: نصب سبک، بدون ریسک شکستن بسته‌ها، بدون نیاز به دسترسی اینترنت سرور.
 *
 * صحت رمزنگاری با «بردار تست رسمی RFC 8291 پیوست A» سنجیده شده است (فایل تست جداگانه).
 */
import {
  createCipheriv, createECDH, createPrivateKey, createSign, hkdfSync, randomBytes,
} from "node:crypto";

export type VapidKeys = { publicKey: string; privateKey: string };

const RS = 4096; // اندازهٔ رکورد (استاندارد صنعتی)
export const b64u = (b: Buffer) => b.toString("base64url");
export const unb64u = (s: string) => Buffer.from(String(s), "base64url");

/* ------------------------------------------------------------------ */
/*  کلیدهای VAPID                                                      */
/* ------------------------------------------------------------------ */

/** ساخت یک جفت کلید تازهٔ VAPID (P-256) — خروجی base64url خام */
export function newVapidKeys(): VapidKeys {
  const e = createECDH("prime256v1");
  e.generateKeys();
  return {
    publicKey: b64u(e.getPublicKey(null, "uncompressed") as Buffer), // ۶۵ بایت
    privateKey: b64u(e.getPrivateKey()),                             // ۳۲ بایت
  };
}

/** کلید عمومی VAPID به‌صورت Uint8Array برای مرورگر (applicationServerKey) */
export function vapidPublicBytes(publicKey: string): Uint8Array {
  return new Uint8Array(unb64u(publicKey));
}

function jwkFromRaw(publicKey: string, privateKey: string) {
  const p = unb64u(publicKey);
  if (p.length !== 65 || p[0] !== 4) throw new Error("bad-vapid-public");
  return {
    kty: "EC" as const,
    crv: "P-256" as const,
    x: b64u(p.subarray(1, 33)),
    y: b64u(p.subarray(33, 65)),
    d: String(privateKey),
    ext: true,
  };
}

/** امضای JWT با ES256 (خروجی: header.payload.signature به base64url) */
export function vapidJwt(audience: string, subject: string, keys: VapidKeys, ttlSec = 12 * 3600): string {
  const header = { typ: "JWT", alg: "ES256" };
  const payload = {
    aud: audience,
    exp: Math.floor(Date.now() / 1000) + Math.max(60, ttlSec),
    sub: subject,
  };
  const data = `${b64u(Buffer.from(JSON.stringify(header)))}.${b64u(Buffer.from(JSON.stringify(payload)))}`;
  const key = createPrivateKey({ key: jwkFromRaw(keys.publicKey, keys.privateKey) as never, format: "jwk" });
  const sig = createSign("sha256").update(data).sign({ key, dsaEncoding: "ieee-p1363" });
  return `${data}.${b64u(sig)}`;
}

/* ------------------------------------------------------------------ */
/*  رمزنگاری محتوا (RFC 8291)                                          */
/* ------------------------------------------------------------------ */

export type EncryptOpts = { salt?: Buffer; asPrivate?: Buffer };

/**
 * رمزنگاری یک پیام برای اشتراک مرورگر.
 * خروجی = بدنهٔ کامل aes128gcm: salt(16) | rs(4) | idlen(1) | as_public(65) | ciphertext+tag
 */
export function encryptPayload(plaintext: Buffer, uaPublic: Buffer, authSecret: Buffer, opts: EncryptOpts = {}): Buffer {
  if (uaPublic.length !== 65 || uaPublic[0] !== 4) throw new Error("bad-ua-public");
  if (authSecret.length !== 16) throw new Error("bad-auth-secret");

  const salt = opts.salt ?? randomBytes(16);
  const ecdh = createECDH("prime256v1");
  let asPrivate: Buffer;
  if (opts.asPrivate) {
    asPrivate = opts.asPrivate;
    ecdh.setPrivateKey(asPrivate);
  } else {
    ecdh.generateKeys();
    asPrivate = ecdh.getPrivateKey();
  }
  const asPublic = ecdh.getPublicKey(null, "uncompressed") as Buffer;

  // ۱) راز مشترک ECDH
  const secret = ecdh.computeSecret(uaPublic);
  // ۲) ترکیب با auth_secret → IKM
  const keyInfo = Buffer.concat([Buffer.from("WebPush: info\u0000", "latin1"), uaPublic, asPublic]);
  const ikm = Buffer.from(hkdfSync("sha256", secret, authSecret, keyInfo, 32));
  // ۳) مشتق‌سازی CEK و NONCE طبق RFC 8188
  const cek = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\u0000", "latin1"), 16));
  const nonce = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\u0000", "latin1"), 12));

  // ۴) هدر بدنه
  const rsBuf = Buffer.alloc(4);
  rsBuf.writeUInt32BE(RS, 0);
  const head = Buffer.concat([salt, rsBuf, Buffer.from([asPublic.length]), asPublic]);

  // ۵) رمزنگاری رکورد آخر با جداکنندهٔ 0x02
  const cipher = createCipheriv("aes-128-gcm", cek, nonce);
  const body = Buffer.concat([
    cipher.update(Buffer.concat([plaintext, Buffer.from([2])])),
    cipher.final(),
    cipher.getAuthTag(),
  ]);
  return Buffer.concat([head, body]);
}

/* ------------------------------------------------------------------ */
/*  فهرست سرویس‌های پوش مجاز (سد SSRF)                                  */
/* ------------------------------------------------------------------ */

/**
 * آدرس‌های پوش باید https و عمومی باشند؛ در غیر این صورت درخواست ارسال نمی‌شود.
 * این سد جلوی سوءاستفادهٔ SSRF (فرستادن درخواست سرور به شبکهٔ داخلی) را می‌گیرد.
 */
export function isSafeEndpoint(endpoint: string): boolean {
  try {
    const u = new URL(endpoint);
    // برای تست محلی روی همان سرور فقط: PUSH_ALLOW_PRIVATE=1 (به‌صورت پیش‌فرض خاموش است)
    const allowPrivate = (process.env as Record<string, string | undefined>)["PUSH_ALLOW_PRIVATE"];
    if (allowPrivate === "1" && (u.hostname === "127.0.0.1" || u.hostname === "localhost")) return true;
    if (u.protocol !== "https:") return false;
    if (endpoint.length > 1500) return false;
    const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
    if (h.includes(":")) return false;                       // IPv6 خام → رد
    if (!h.includes(".")) return false;                      // باید دامنه باشد (نه سرور داخلی)
    if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return false;
    if (/^\d+(\.\d+){3}$/.test(h)) return false;             // IPv4 خام → رد
    if (/^\d+$/.test(h.split(".").pop() || "")) {            // شکل عددی عجیب مثل 127.1
      const first = Number(h.split(".")[0]);
      if (!Number.isNaN(first) && first < 224 && /^\d/.test(h)) {
        // دامنه‌های معتبر هرگز با عدد شروع نمی‌شوند (به‌جز موارد نادر که سرویس پوش نیستند)
        const isPrivate = /^(10|127|0|192|172|169)\./.test(h);
        if (isPrivate || !h.includes(".com") && !h.includes(".net") && !h.includes(".org") && !/^[a-z]/.test(h)) return false;
      }
    }
    if (/^(10|127|0|192\.168|169\.254|172\.(1[6-9]|2\d|3[01]))\./.test(h)) return false;
    return true;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/*  ارسال                                                              */
/* ------------------------------------------------------------------ */

export type PushSub = { endpoint: string; p256dh: string; auth: string };
export type SendResult = { ok: boolean; status: number; gone: boolean; error?: string };

export type SendOpts = {
  subject?: string;      // مثل mailto:admin@bu.gamifi.ir
  ttl?: number;          // ثانیه
  urgency?: "very-low" | "low" | "normal" | "high";
  timeoutMs?: number;
};

/** ارسال یک پیام پوش به یک اشتراک مرورگر */
export async function sendWebPush(sub: PushSub, payload: unknown, vapid: VapidKeys, opts: SendOpts = {}): Promise<SendResult> {
  const text = typeof payload === "string" ? payload : JSON.stringify(payload);
  const buf = Buffer.from(text, "utf8");
  if (buf.length > 3900) return { ok: false, status: 0, gone: false, error: "payload-too-large" };
  if (!isSafeEndpoint(sub.endpoint)) return { ok: false, status: 0, gone: false, error: "unsafe-endpoint" };

  let body: Buffer;
  try {
    body = encryptPayload(buf, unb64u(sub.p256dh), unb64u(sub.auth));
  } catch (e) {
    return { ok: false, status: 0, gone: false, error: "encrypt:" + String((e as Error)?.message || e) };
  }

  const subject = opts.subject || "mailto:admin@bu.gamifi.ir";
  let audience: string;
  try { audience = new URL(sub.endpoint).origin; } catch { return { ok: false, status: 0, gone: false, error: "bad-endpoint" }; }
  const jwt = vapidJwt(audience, subject, vapid);

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), Math.max(2000, opts.timeoutMs ?? 10000));
  try {
    const res = await fetch(sub.endpoint, {
      method: "POST",
      headers: {
        "Content-Encoding": "aes128gcm",
        "Content-Type": "application/octet-stream",
        "TTL": String(Math.max(0, Math.min(2419200, opts.ttl ?? 86400))),
        "Urgency": opts.urgency || "normal",
        "Authorization": `vapid t=${jwt},k=${vapid.publicKey}`,
      },
      body: new Uint8Array(body),
      signal: ctl.signal,
    });
    const gone = res.status === 404 || res.status === 410;
    return { ok: res.ok, status: res.status, gone };
  } catch (e) {
    return { ok: false, status: 0, gone: false, error: String((e as Error)?.name === "AbortError" ? "timeout" : String((e as Error)?.message || e)) };
  } finally {
    clearTimeout(timer);
  }
}
