import { pgTable, text, integer, bigint, index } from "drizzle-orm/pg-core";

// 🪙 دفتر سکه‌ها (بستهٔ «سکهٔ زنده»)
// یک رکورد برای هر تغییر سکه: delta=تغییر، reason=delta|buy|daily|admin
// جدول با DDLِ idempotent داخل init-db.mjs ساخته می‌شود (هر آپدیت).
export const coinLedger = pgTable(
  "coin_ledger",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    delta: integer("delta").notNull().default(0),
    reason: text("reason").notNull().default(""),
    ref: text("ref").notNull().default(""),
    note: text("note").notNull().default(""),
    createdAt: bigint("created_at", { mode: "number" }).notNull(),
  },
  (t) => [
    index("coin_ledger_user_idx").on(t.userId),
    index("coin_ledger_time_idx").on(t.createdAt),
  ]
);
