import { getSessionUser, json } from "@/lib/auth";
import { markSeen } from "@/lib/push";

/** 👁️ خوانده‌شدن اعلان‌ها (برای زنگولهٔ اعلان) */
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return json({ ok: false, error: "not-authed" }, 401);
  let b: { ids?: string[] | "all" } = {};
  try { b = await req.json(); } catch { b = {}; }
  const n = await markSeen(me.id, b.ids === "all" ? "all" : Array.isArray(b.ids) ? b.ids : []);
  return json({ ok: true, seen: n });
}
