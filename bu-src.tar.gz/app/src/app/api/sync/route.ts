import { eq, or, and, inArray } from "drizzle-orm";
import { db } from "@/db";
import { users, orgMembers, notifications } from "@/db/schema";
import { coinLedger } from "@/db/coinledger";
import { uid, now, pub, createSession, setAuthCookie, json, getSessionUser, getCurrentToken } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

/**
 * قلب تپندهٔ ذخیرهٔ دوگانه:
 * - بازی اصلی در localStorage با کلید gamify2-store-v2 ذخیره می‌کند (دست‌نخورده می‌ماند)
 * - این API هم‌زمان همان پروفایل را در سرور (Postgres) ذخیره/به‌روز می‌کند
 * - اگر کاربر از قبل نشست داشته باشد، همان کاربر به‌روز می‌شود؛ وگرنه با localId تطبیق داده می‌شود
 *
 * 🪙 بستهٔ «سکهٔ زنده» (D): تراز سکه از این‌بعد مرجعِ سرور است.
 * - در ثبتِ نخست، سکهٔ اعلام‌شده (با سقف ۱۰٬۰۰) به‌عنوان تراز اولیه می‌نشیند.
 * - بعد از آن، sync دیگر سکهٔ اعلامی را نمی‌پذیرد (ضدتقلبِ تورم)؛
 *   سکه فقط از مسیر /api/coins (delta/buy/adjust) و /api/daily تغییر می‌کند.
 */

const MAX_BOOTSTRAP_COINS = 10000; // سقف تراز اولیهٔ ثبتِ نخست

export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  const profile = (b.profile ?? b) as Record<string, unknown>;
  const localId = String(profile.id ?? profile.localId ?? "");
  const name = String(profile.name ?? "میهمان").slice(0, 40) || "میهمان";
  const orgId = String(profile.org ?? profile.orgId ?? "");

  const num = (v: unknown, d = 0) => (typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.round(v)) : d);
  const xp = num(profile.xp), coins = num(profile.coins, 50), cups = num(profile.cups);
  const streak = num(profile.streak), wins = num(profile.wins), played = num(profile.played);
  const rating = num(profile.rating, 1000), weekXp = num(profile.weekXp ?? profile.week_xp, xp);
  const level = Math.floor(xp / 250) + 1;

  // ۱) نشست فعلی؟
  const me = await getSessionUser();
  let user = me;

  // ۲) تطبیق با localId یا phone/email
  if (!user && localId) {
    const rows = await db.select().from(users).where(or(eq(users.localId, localId), eq(users.id, localId))).limit(1);
    if (rows[0]) user = rows[0];
  }
  const phone = String(profile.phone ?? "");
  const email = String(profile.email ?? "");
  if (!user && (phone || email)) {
    const conds = [];
    if (phone) conds.push(eq(users.phone, phone));
    if (email) conds.push(eq(users.email, email));
    if (conds.length) {
      const rows = await db.select().from(users).where(or(...conds)).limit(1);
      if (rows[0]) user = rows[0];
    }
  }

  if (!user) {
    const id = uid("u");
    // 🪙 کاربرِ تازه: هیچ sh:… بدون سابقهٔ خریدِ ثبت‌شده ندارد (قفلِ قناتِ فروشگاه)
    const freshInterests = (Array.isArray(profile.interests) ? (profile.interests as string[]) : [])
      .filter((x) => typeof x !== "string" || x.indexOf("sh:") !== 0).slice(0, 20);
    const row = {
      id, localId: localId || id, name,
      avatar: (profile.avatar as object) ?? {},
      bio: String(profile.bio ?? "").slice(0, 300),
      email, phone,
      provider: String(profile.provider ?? "guest"),
      googleSub: String(profile.googleSub ?? ""),
      role: "player",
      orgId,
      xp, coins: Math.min(coins, MAX_BOOTSTRAP_COINS), cups, streak, wins, played, rating, weekXp, level,
      interests: freshInterests,
      friends: Array.isArray(profile.friends) ? (profile.friends as string[]) : [],
      isPrivate: false, banned: false, isDemo: false,
      lastSeen: now(), lastDaily: String(profile.lastDaily ?? ""),
      createdAt: now(), extra: {},
    };
    await db.insert(users).values(row);
    user = (await db.select().from(users).where(eq(users.id, id)).limit(1))[0];
    // خوش‌آمد
    try {
      await db.insert(notifications).values({ id: uid("n"), userId: id, title: "🎉 به گیمیفای خوش آمدی!", body: "حسابت در سرور هم ذخیره شد؛ حالا می‌توانی با بازیکنان واقعی رقابت کنی.", link: "#challenge", createdAt: now(), seen: 0 });
    } catch { /* ignore */ }
    if (orgId) {
      try { await db.insert(orgMembers).values({ orgId, userId: id, status: "approved", joinedAt: now() }).onConflictDoNothing(); } catch { /* ignore */ }
    }
  } else {
    // به‌روزرسانی افزایشی: بزرگ‌ترین مقدار نگه داشته می‌شود تا XP کم نشود
    // 🪙 سکه: استثنائاست — ترازِ سرور حفظ می‌شود (سکه فقط از /api/coins و /api/daily تغییر می‌کند)

    // 🪙 قفلِ قناتِ فروشگاه: قلمِ sh: تازه فقط با رکوردِ خرید (دفتر سکه) پذیرفته
    // می‌شود تا ثبتِ مالکیتِ بی‌پرداخت (از مسیر sync) امکان‌پذیر نباشد.
    const clientInterests: string[] = Array.isArray(profile.interests) ? (profile.interests as string[]) : [];
    const prevInterests: string[] = Array.isArray(user.interests) ? (user.interests as string[]) : [];
    const prevSet = new Set(prevInterests);
    const newSh = clientInterests.filter((x) => typeof x === "string" && x.indexOf("sh:") === 0 && !prevSet.has(x));
    let mergedInterests: string[];
    if (!clientInterests.length) {
      mergedInterests = prevInterests;
    } else if (!newSh.length) {
      mergedInterests = clientInterests.slice(0, 20);
    } else {
      const ids = newSh.map((x) => x.slice(3)).filter(Boolean);
      const paid = await db
        .select()
        .from(coinLedger)
        .where(and(eq(coinLedger.userId, user.id), eq(coinLedger.reason, "buy"), inArray(coinLedger.ref, ids)))
        .limit(50);
      const paidSet = new Set(paid.map((p) => p.ref));
      mergedInterests = clientInterests
        .filter((x) => {
          if (typeof x === "string" && x.indexOf("sh:") === 0 && !prevSet.has(x)) return paidSet.has(x.slice(3));
          return true;
        })
        .slice(0, 20);
    }

    const patch = {
      name: name !== "میهمان" || !user.name ? name : user.name,
      avatar: (profile.avatar as object) ?? user.avatar,
      bio: profile.bio !== undefined ? String(profile.bio).slice(0, 300) : user.bio,
      orgId: orgId || user.orgId,
      xp: Math.max(user.xp ?? 0, xp),
      coins: user.coins ?? 0,
      cups: Math.max(user.cups ?? 0, cups),
      streak: Math.max(user.streak ?? 0, streak),
      wins: Math.max(user.wins ?? 0, wins),
      played: Math.max(user.played ?? 0, played),
      rating: rating || user.rating,
      weekXp: Math.max(user.weekXp ?? 0, weekXp),
      level: Math.max(user.level ?? 1, level),
      interests: mergedInterests,
      lastSeen: now(),
      localId: user.localId || localId,
    };
    await db.update(users).set(patch).where(eq(users.id, user.id));
    user = { ...user, ...patch };
    if (orgId && orgId !== user.orgId) {
      try { await db.insert(orgMembers).values({ orgId, userId: user.id, status: "approved", joinedAt: now() }).onConflictDoNothing(); } catch { /* ignore */ }
    } else if (orgId) {
      try { await db.insert(orgMembers).values({ orgId, userId: user.id, status: "approved", joinedAt: now() }).onConflictDoNothing(); } catch { /* ignore */ }
    }
  }

  // نشست فعلی معتبر است؟ همان را نگه دار (از انباشت نشست‌های تکراری جلوگیری می‌شود)
  const token = me && user.id === me.id ? (await getCurrentToken()) || (await createSession(user.id)).token : (await createSession(user.id)).token;
  const res = json({ ...pub(user), serverToken: token, syncedAt: now() });
  return setAuthCookie(res, token);
}

export async function GET() {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  return json(pub(me));
}
