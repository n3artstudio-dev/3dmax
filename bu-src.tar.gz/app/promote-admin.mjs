import pg from "pg";

/* =============================================================================
 *  مدیریت نقش مدیر (role=admin) روی دیتابیس bugamifi_db
 *
 *  استفاده (از داخل /root/bu-gamifi-deploy/incoming):
 *     set -a; . /root/bu-gamifi-deploy/app.env; set +a
 *     node promote-admin.mjs --list
 *     node promote-admin.mjs --promote "میدیو,09121234567,admin@example.com,u-abc123"
 *     node promote-admin.mjs --demote "کاربر قدیمی"
 *
 *  تطبیق: شناسهٔ کاربر، نام، تلفن یا ایمیل — دقیق (با نادیده‌گرفتن ی/ي، ک/ك و فاصله‌ها)
 * ========================================================================== */

const { Pool } = pg;
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error("[promote-admin] ERROR: DATABASE_URL is not set.");
  process.exit(1);
}

const norm = (v) =>
  String(v ?? "")
    .replace(/[\u200c\u200f\u200e]/g, "")
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

const args = process.argv.slice(2);
const mode = args[0] || "--list";
const queries = (args[1] || "")
  .split(/[,\n]/)
  .map((s) => s.trim())
  .filter(Boolean);

const pool = new Pool({ connectionString: databaseUrl });

async function allUsers() {
  const r = await pool.query(
    `select id, name, coalesce(phone,'') as phone, coalesce(email,'') as email,
            coalesce(role,'player') as role, coalesce(is_demo,false) as demo
       from users order by (coalesce(role,'player') = 'admin') desc, last_seen desc nulls last limit 1000`
  );
  return r.rows;
}

function printRows(rows) {
  for (const u of rows) {
    console.log(
      `${u.role === "admin" ? "👑" : "  "} ${u.name}  |  role=${u.role}${u.demo ? " (demo)" : ""}  |  id=${u.id}  |  phone=${u.phone || "-"}  |  email=${u.email || "-"}`
    );
  }
}

try {
  if (mode === "--list" || mode === "list") {
    const rows = await allUsers();
    console.log(`کاربران (${rows.length}):`);
    printRows(rows);
    const admins = rows.filter((u) => u.role === "admin");
    console.log(`\nتعداد مدیران فعلی: ${admins.length}`);
  } else if (mode === "--promote" || mode === "promote") {
    if (!queries.length) {
      console.error("[promote-admin] شناسه‌ای داده نشد. مثال: --promote \"میدیو,0912xxxxxxx\"");
      process.exit(1);
    }
    const rows = await allUsers();
    const want = new Set(queries.map(norm));
    const targets = rows.filter((u) =>
      [u.id, u.name, u.phone, u.email].some((f) => {
        const n = norm(f);
        return !!n && want.has(n);
      })
    );
    if (!targets.length) {
      console.log("⚠️ هیچ کاربری با این مشخصات پیدا نشد. فهرست کاربران:");
      printRows(rows.slice(0, 40));
      process.exit(2);
    }
    for (const u of targets) {
      if (u.role !== "admin") {
        await pool.query(`update users set role = 'admin' where id = $1`, [u.id]);
        console.log(`👑 مدیر شد: ${u.name} (${u.id})`);
      } else {
        console.log(`= از قبل مدیر بود: ${u.name} (${u.id})`);
      }
    }
    const after = await allUsers();
    console.log(`\nتعداد مدیران الان: ${after.filter((u) => u.role === "admin").length}`);
    const missing = queries.filter(
      (q) => !targets.some((u) => [u.id, u.name, u.phone, u.email].some((f) => norm(f) === norm(q)))
    );
    if (missing.length) console.log(`⚠️ پیدا نشدند: ${missing.join(", ")}`);
  } else if (mode === "--demote" || mode === "demote") {
    if (!queries.length) {
      console.error("[promote-admin] شناسه‌ای داده نشد.");
      process.exit(1);
    }
    const rows = await allUsers();
    const want = new Set(queries.map(norm));
    const targets = rows.filter((u) =>
      [u.id, u.name, u.phone, u.email].some((f) => {
        const n = norm(f);
        return !!n && want.has(n);
      })
    );
    const adminsLeft = rows.filter((u) => u.role === "admin" && !targets.some((t) => t.id === u.id));
    if (!adminsLeft.length) {
      console.error("⛔ این کار آخرین مدیر سیستم را حذف می‌کند و انجام نشد.");
      process.exit(1);
    }
    for (const u of targets) {
      if (u.role === "admin") {
        await pool.query(`update users set role = 'player' where id = $1`, [u.id]);
        console.log(`➖ از مدیران حذف شد: ${u.name} (${u.id})`);
      }
    }
  } else {
    console.log("استفاده:");
    console.log('  node promote-admin.mjs --list');
    console.log('  node promote-admin.mjs --promote "میدیو,0912xxxxxxx,admin@example.com"');
    console.log('  node promote-admin.mjs --demote "نام یا شناسه"');
  }
} catch (err) {
  console.error("[promote-admin] خطا:", err && err.message ? err.message : err);
  process.exit(1);
} finally {
  await pool.end();
}
