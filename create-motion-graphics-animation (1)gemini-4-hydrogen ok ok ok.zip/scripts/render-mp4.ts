/**
 * render-mp4.ts — رندرِ آفلاینِ موشن گرافیک ۱۵ دقیقه‌ای به MP4 (H.264 + AAC) در Node
 *
 * نحوهٔ اجرا:
 *   npx tsx scripts/render-mp4.ts <audio.ogg> <out.mp4> [fps] [ffmpegPath]
 *   (حالت ورکر: WORKER_IDX=0 WORKER_COUNT=2 npx tsx scripts/render-mp4.ts ...)
 */
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import { drawMotionFrame } from '../src/motion/renderer';
import { DURATION_15MIN } from '../src/motion/timeline';

const [
  audioPath = '/tmp/ref_work/audio.ogg',
  outPath = '/tmp/out/jaryan-noor-15min-720p.mp4',
  fpsArg = '30',
  ffArg = '/tmp/ff/node_modules/ffmpeg-static/ffmpeg',
] = process.argv.slice(2);

const FPS = Number(fpsArg);
const W = 1280;
const H = 720;
const MAX_SEC = Number(process.env.MAX_SEC ?? 0);
const TOTAL_SEC = MAX_SEC > 0 ? Math.min(MAX_SEC, DURATION_15MIN) : DURATION_15MIN;
const TOTAL_FRAMES = Math.round(TOTAL_SEC * FPS);

mkdirSync('/tmp/out', { recursive: true });

function registerFonts() {
  for (const f of ['vazir400', 'vazir500', 'vazir600', 'vazir700', 'vazir800', 'vazir900']) {
    const p = `/tmp/fonts/${f}.ttf`;
    if (existsSync(p)) GlobalFonts.registerFromPath(p, 'Vazirmatn');
  }
  if (existsSync('/tmp/fonts/amiri700.ttf')) {
    GlobalFonts.registerFromPath('/tmp/fonts/amiri700.ttf', 'Amiri');
  }
}

function buildEnvelope(): Float32Array {
  const n = TOTAL_FRAMES + 4;
  const env = new Float32Array(n);
  const pcmPath = '/tmp/ref_work/audio16.f32';
  if (!existsSync(pcmPath)) return env.fill(0.28);
  const buf = readFileSync(pcmPath);
  const pcm = new Float32Array(buf.buffer, buf.byteOffset, Math.floor(buf.byteLength / 4));
  const step = 16000 / FPS;
  let peak = 0;
  for (let i = 0; i < n; i++) {
    const s = Math.floor(i * step);
    const e = Math.min(pcm.length, Math.floor((i + 1) * step));
    let sum = 0;
    for (let k = s; k < e; k++) sum += pcm[k] * pcm[k];
    env[i] = e > s ? Math.sqrt(sum / (e - s)) : 0;
    if (env[i] > peak) peak = env[i];
  }
  const out = new Float32Array(n);
  let v = 0;
  for (let i = 0; i < n; i++) {
    const x = Math.min(1, Math.pow(env[i] / (peak * 0.58 || 1), 0.8));
    v = x > v ? v + (x - v) * 0.48 : v + (x - v) * 0.08;
    out[i] = 0.08 + v * 0.86;
  }
  return out;
}

async function runWorker(workerIdx: number, workerCount: number) {
  registerFonts();
  const env = buildEnvelope();
  const perWorker = Math.ceil(TOTAL_FRAMES / workerCount);
  const startFrame = workerIdx * perWorker;
  const endFrame = Math.min(TOTAL_FRAMES, startFrame + perWorker);
  const partOut = `/tmp/out/part_${workerIdx}.mp4`;

  const ff = spawn(
    ffArg,
    [
      '-y',
      '-hide_banner',
      '-loglevel',
      'error',
      '-f',
      'rawvideo',
      '-pix_fmt',
      'rgba',
      '-s',
      `${W}x${H}`,
      '-r',
      String(FPS),
      '-i',
      'pipe:0',
      '-an',
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-crf',
      '24',
      '-maxrate',
      '760k',
      '-bufsize',
      '1520k',
      '-pix_fmt',
      'yuv420p',
      '-profile:v',
      'high',
      '-threads',
      '1',
      '-g',
      String(FPS * 2),
      partOut,
    ],
    { stdio: ['pipe', 'inherit', 'pipe'] },
  );

  let errBuf = '';
  ff.stderr.on('data', (d) => {
    errBuf += d.toString();
  });
  const done = new Promise<number>((res) => ff.on('close', (c) => res(c ?? 1)));

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d') as unknown as CanvasRenderingContext2D;
  const t0 = Date.now();
  const count = endFrame - startFrame;

  for (let i = startFrame; i < endFrame; i++) {
    const t = i / FPS;
    drawMotionFrame(ctx, t, W, H, env[i] ?? 0.25, {
      mode: '15min',
      showSubtitles: true,
      showHud: true,
    });
    const img = (
      ctx as unknown as { getImageData: (...a: number[]) => { data: Uint8ClampedArray } }
    ).getImageData(0, 0, W, H);
    const chunk = Buffer.from(img.data.buffer, img.data.byteOffset, img.data.byteLength);
    if (!ff.stdin.write(chunk)) {
      await new Promise<void>((r) => ff.stdin.once('drain', r));
    }
    const localDone = i - startFrame + 1;
    if (localDone % (FPS * 30) === 0 || localDone === count) {
      const el = (Date.now() - t0) / 1000;
      const fpsNow = localDone / Math.max(0.01, el);
      console.log(
        `[W${workerIdx}] ${localDone}/${count} (${((localDone / count) * 100).toFixed(1)}%) @ ${fpsNow.toFixed(1)} fps`,
      );
    }
  }
  ff.stdin.end();
  const code = await done;
  if (code !== 0) {
    throw new Error(`Worker ${workerIdx} ffmpeg exited ${code}: ${errBuf}`);
  }
}

async function runMaster() {
  const workers = 2;
  const t0 = Date.now();
  console.log(`Starting parallel render: ${TOTAL_SEC}s @ ${FPS}fps (${TOTAL_FRAMES} frames) on ${workers} workers...`);

  await Promise.all(
    Array.from({ length: workers }, (_, idx) => {
      return new Promise<void>((resolve, reject) => {
        const child = spawn(
          process.execPath,
          ['--import', 'tsx', 'scripts/render-mp4.ts', audioPath, outPath, String(FPS), ffArg],
          {
            stdio: 'inherit',
            env: {
              ...process.env,
              WORKER_IDX: String(idx),
              WORKER_COUNT: String(workers),
            },
          },
        );
        child.on('close', (code) => {
          if (code === 0) resolve();
          else reject(new Error(`Worker ${idx} exited with ${code}`));
        });
      });
    }),
  );

  // ادغام ویدیوها و افزودن صدای اصلی با fade-out نرم در پایان ۱۵ دقیقه
  const listPath = '/tmp/out/parts.txt';
  const lines = Array.from({ length: workers }, (_, i) => `file '/tmp/out/part_${i}.mp4'`).join('\n');
  writeFileSync(listPath, lines + '\n');

  const fadeStart = Math.max(0, TOTAL_SEC - 2.8);
  const muxArgs = [
    '-y',
    '-hide_banner',
    '-loglevel',
    'error',
    '-f',
    'concat',
    '-safe',
    '0',
    '-i',
    listPath,
    '-t',
    String(TOTAL_SEC),
    '-i',
    audioPath,
    '-map',
    '0:v',
    '-map',
    '1:a',
    '-c:v',
    'copy',
    '-af',
    `afade=t=out:st=${fadeStart.toFixed(2)}:d=2.8`,
    '-c:a',
    'aac',
    '-b:a',
    '96k',
    '-ar',
    '48000',
    '-movflags',
    '+faststart',
    '-shortest',
    '-metadata',
    'title=جریان نور؛ صراط مستقیم و تسلیم — موشن گرافیک ۱۵ دقیقه‌ای',
    outPath,
  ];

  await new Promise<void>((resolve, reject) => {
    const ff = spawn(ffArg, muxArgs, { stdio: ['ignore', 'inherit', 'inherit'] });
    ff.on('close', (c) => (c === 0 ? resolve() : reject(new Error(`mux failed ${c}`))));
  });

  // پاکسازی فایل‌های موقت
  for (let i = 0; i < workers; i++) {
    try {
      unlinkSync(`/tmp/out/part_${i}.mp4`);
    } catch {
      /* noop */
    }
  }
  try {
    unlinkSync(listPath);
  } catch {
    /* noop */
  }

  console.log(`ALL DONE in ${((Date.now() - t0) / 1000).toFixed(1)}s -> ${outPath}`);
}

const wIdx = process.env.WORKER_IDX;
const wCnt = process.env.WORKER_COUNT;

if (wIdx !== undefined && wCnt !== undefined) {
  runWorker(Number(wIdx), Number(wCnt)).catch((e) => {
    console.error(e);
    process.exit(1);
  });
} else {
  runMaster().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
