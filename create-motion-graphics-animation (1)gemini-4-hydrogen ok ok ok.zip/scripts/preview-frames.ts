import { writeFileSync, mkdirSync } from 'node:fs';
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import { drawMotionFrame } from '../src/motion/renderer';
import { ALL_CHAPTERS } from '../src/motion/timeline';

for (const f of ['vazir400', 'vazir500', 'vazir600', 'vazir700', 'vazir800', 'vazir900']) {
  GlobalFonts.registerFromPath(`/tmp/fonts/${f}.ttf`, 'Vazirmatn');
}
GlobalFonts.registerFromPath('/tmp/fonts/amiri700.ttf', 'Amiri');

mkdirSync('/tmp/out/previews', { recursive: true });

const W = 1280;
const H = 720;
const canvas = createCanvas(W, H);
const ctx = canvas.getContext('2d') as unknown as CanvasRenderingContext2D;

const samples = [
  { name: '00_intro', t: 1.8 },
  { name: '01_boat_paths', t: 25 },
  { name: '02_surrender_ocean', t: 92 },
  { name: '03_mind_soul', t: 175 },
  { name: '04_abundance_orbit', t: 235 },
  { name: '05_horse_compass', t: 288 },
  { name: '06_satan_footsteps', t: 360 },
  { name: '07_five_gates', t: 416 },
  { name: '08_beauty_mirror', t: 478 },
  { name: '09_release_resp', t: 545 },
  { name: '10_four_steps_mosq', t: 615 },
  { name: '11_exact_law', t: 678 },
  { name: '12_lamp_powerplant', t: 742 },
  { name: '13_daily_signs', t: 800 },
  { name: '14_return_nudges', t: 856 },
  { name: '15_ayat_lamps', t: 886 },
  { name: '16_outro_15min', t: 897 },
];

const t0 = Date.now();
for (const s of samples) {
  drawMotionFrame(ctx, s.t, W, H, 0.42, {
    mode: '15min',
    showSubtitles: true,
    showHud: true,
  });
  const buf = canvas.toBuffer('image/png');
  writeFileSync(`/tmp/out/previews/${s.name}.png`, buf);
}
const dt = (Date.now() - t0) / 1000;
console.log(`Rendered ${samples.length} PNG previews in ${dt.toFixed(2)}s`);

// Benchmark raw 120-frame draw + getImageData speed
const b0 = Date.now();
for (let i = 0; i < 120; i++) {
  const ch = ALL_CHAPTERS[i % 15];
  const t = ch.start + (ch.end - ch.start) * 0.6;
  drawMotionFrame(ctx, t, W, H, 0.35, {
    mode: '15min',
    showSubtitles: true,
    showHud: true,
  });
  (ctx as unknown as { getImageData: (...a: number[]) => unknown }).getImageData(0, 0, W, H);
}
const bdt = (Date.now() - b0) / 1000;
console.log(`Benchmark: 120 frames in ${bdt.toFixed(2)}s => ${(120 / bdt).toFixed(1)} fps (single core)`);
