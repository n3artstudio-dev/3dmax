/* ------------------------------------------------------------------
   published.ts — لینک‌های عمومیِ MP4 از پیش رندرشده (۱۵ دقیقه • 720p HD)
------------------------------------------------------------------ */

export interface PublishedLink {
  host: string;
  url: string;
  note: string;
  sizeMB: string;
}

export const PUBLISHED_15MIN_MP4: PublishedLink[] = [
  {
    host: 'gofile.io',
    url: 'https://gofile.io/d/6tWiJ0gf',
    note: 'صفحهٔ دانلود با ماندگاری بیشتر • 66 MB • H.264 720p + AAC',
    sizeMB: '66.0 MB',
  },
  {
    host: 'tmpfiles.org',
    url: 'https://tmpfiles.org/woAS7AjWlfV1/jaryan-noor-15min-720p.mp4',
    note: 'لینکِ دانلودِ سریعِ tmpfiles.org • 66 MB • ۱۵:۰۰ دقیق',
    sizeMB: '66.0 MB',
  },
];
