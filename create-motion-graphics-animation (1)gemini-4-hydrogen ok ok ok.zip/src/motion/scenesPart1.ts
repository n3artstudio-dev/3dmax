/* ------------------------------------------------------------------
   scenesPart1.ts — صحنه‌های المان‌محور فصل ۱ تا ۵
   منطقهٔ امن بصری روی ۱۲۸۰×۷۲۰: y از ۱۰۰ تا ۵۸۰ (دور از HUD و زیرنویس)
------------------------------------------------------------------ */
import {
  clamp01,
  drawAudioAuraRing,
  drawFlowPulse,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawVerseCard,
  easeInOutCubic,
  easeOutCubic,
  lerp,
  seeded,
  withAlpha,
} from './drawPrimitives';
import {
  drawBoat,
  drawCompass,
  drawGlassCard,
  drawHeart,
  drawPopText,
  drawStar8,
  drawWaterWaves,
  drawWipeText,
} from './fx';

/** t = زمانِ محلی، d = طولِ فصل، g = زمانِ کل، e = انرژیِ صدا */
export type SceneFn = (
  ctx: CanvasRenderingContext2D,
  t: number,
  d: number,
  g: number,
  e: number,
  a: string,
  b: string,
) => void;

/* ══════════ ۱ — دو مسیر و جریانِ نور (قایق در برابر جریان) ══════════ */
export const sceneTwoPathsBoat: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;

  // موج‌های اقیانوسِ افق در بخش پایینِ صحنه
  drawWaterWaves(ctx, 435, 1280, g * 1.1, b, a, 3, 12);

  // نورِ خورشیدِ اقیانوس در سمت چپ (مقصد جریان)
  const sunGlow = ctx.createRadialGradient(170, 320, 12, 170, 320, 260);
  sunGlow.addColorStop(0, withAlpha(a, 0.42 + e * 0.16));
  sunGlow.addColorStop(0.5, withAlpha(b, 0.14));
  sunGlow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sunGlow;
  ctx.beginPath();
  ctx.arc(170, 320, 260, 0, Math.PI * 2);
  ctx.fill();

  drawStar8(ctx, 170, 320, 34 + e * 10, a, g * 0.45, true);
  drawPopText(ctx, 'اقیانوسِ رحمت', 170, 382, '700 18px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.6), (t - 2.5) / 1.2);

  // مسیر ۱: صراط مستقیم (رودخانهٔ درخشان طلایی از راست به چپ)
  const straightP = easeOutCubic(clamp01((t - 1.2) / 3));
  ctx.save();
  const riverGrad = ctx.createLinearGradient(1120, 320, 200, 320);
  riverGrad.addColorStop(0, withAlpha(a, 0.08));
  riverGrad.addColorStop(0.45, withAlpha(a, 0.42));
  riverGrad.addColorStop(1, withAlpha(b, 0.65));
  ctx.strokeStyle = riverGrad;
  ctx.lineWidth = 44;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(1120, 320);
  ctx.lineTo(lerp(1120, 220, straightP), 320);
  ctx.stroke();

  // خطوط جریان نور در مسیر مستقیم
  for (let i = 0; i < 6; i++) {
    const prog = ((g * 0.38 + i / 6) % 1) * straightP;
    const x = lerp(1110, 230, prog);
    const y = 320 + (i % 2 === 0 ? -10 : 10) + Math.sin(g * 3 + i) * 3;
    ctx.strokeStyle = withAlpha('#fef08a', 0.85 * Math.sin(prog * Math.PI));
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(x + 28, y);
    ctx.lineTo(x - 24, y);
    ctx.lineTo(x - 14, y - 6);
    ctx.moveTo(x - 24, y);
    ctx.lineTo(x - 14, y + 6);
    ctx.stroke();
  }
  ctx.restore();

  // مسیر ۲: راه غیرمستقیم (زیگزاگ قرمزِ پرانحراف در بالا و پایین)
  const zigzagP = easeOutCubic(clamp01((t - 4) / 3.5));
  if (zigzagP > 0.01) {
    ctx.save();
    ctx.globalAlpha = 0.72 * zigzagP;
    ctx.strokeStyle = '#fb7185';
    ctx.lineWidth = 3;
    ctx.setLineDash([10, 8]);
    ctx.beginPath();
    const pts: [number, number][] = [
      [1080, 320],
      [960, 225],
      [830, 415],
      [690, 210],
      [560, 435],
      [440, 250],
    ];
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) {
      const seg = clamp01(zigzagP * (pts.length - 1) - (i - 1));
      if (seg <= 0) break;
      ctx.lineTo(lerp(pts[i - 1][0], pts[i][0], seg), lerp(pts[i - 1][1], pts[i][1], seg));
    }
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  // قایق: نیمهٔ اول با پاروهای پراضطراب به چپ و راست می‌رود، نیمهٔ دوم به خط نور برمی‌گردد
  const alignPhase = easeInOutCubic(clamp01((t - d * 0.56) / 6));
  const wobbleY = Math.sin(g * 2.8) * 62 * (1 - alignPhase);
  const boatX = lerp(930, 560, clamp01(t / d)) + Math.sin(g * 1.4) * 14;
  const boatY = 320 + wobbleY + Math.sin(g * 3.1) * 5;
  const tilt = Math.cos(g * 2.8) * 0.16 * (1 - alignPhase) + Math.sin(g * 2.1) * 0.03;
  drawBoat(ctx, boatX, boatY, 0.96, tilt, alignPhase > 0.5 ? a : '#fb7185', g * 5.2, alignPhase > 0.75, 1 - alignPhase * 0.65);

  // تیتر و کارت‌های توضیحی
  drawWipeText(ctx, 'دو مسیر در زندگی', cx, 134, '800 42px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.6), (t - 0.8) / 1.8);

  drawKineticPill(ctx, 920, 200, 'راهِ مستقیم • هم‌جهت با نور', (t - 3.2) / 1.2, a, '✦', 0.96, 18);
  drawKineticPill(ctx, 470, 200, 'راهِ غیرمستقیم • تکیه بر توانِ خود', (t - 6.5) / 1.2, '#fb7185', '✕', 0.92, 17);

  drawVerseCard(
    ctx,
    cx,
    518,
    'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ',
    'سوره نور • آیه ۳۵',
    a,
    (t - 12) / 2.2,
    720,
  );
};

/* ══════════ ۲ — پاروها را بگذار کنار؛ تسلیمِ جریان شو ══════════ */
export const sceneSurrenderOcean: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;

  // موج‌های آرامِ اقیانوس
  drawWaterWaves(ctx, 378, 1280, g * 1.35, a, b, 4, 15);

  // هالهٔ آرامش در پشتِ قایق
  drawAudioAuraRing(ctx, cx, 368, 155, g, e, a);

  // مرحلهٔ رها کردن پاروها (در ۱۰ ثانیه اول پاروها محو می‌شوند و قایق آرام می‌لغزد)
  const letGo = easeInOutCubic(clamp01((t - 4) / 7));
  const boatX = cx + Math.sin(g * 0.7) * 55;
  const boatY = 382 + Math.sin(g * 2.1) * 10;
  const boatTilt = Math.cos(g * 2.1) * 0.045;

  drawBoat(ctx, boatX, boatY, 1.22, boatTilt, b, g * 3.8 * (1 - letGo), letGo > 0.45, 1 - letGo);

  // پاروهای رهاشده که به ذرات طلایی تبدیل می‌شوند
  if (letGo > 0.15 && letGo < 0.95) {
    const sparkAlpha = Math.sin(letGo * Math.PI);
    for (let i = 0; i < 18; i++) {
      const px = boatX + (seeded(i * 9) - 0.5) * 240;
      const py = boatY + 12 - letGo * (45 + seeded(i * 4) * 90);
      ctx.fillStyle = withAlpha(b, sparkAlpha * 0.85);
      ctx.beginPath();
      ctx.arc(px, py, 2.5 + seeded(i) * 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // خطوط جریان نورِ همسو از راست به چپ
  for (let i = 0; i < 9; i++) {
    const laneY = 330 + (i % 5) * 34;
    const p = (g * 0.42 + seeded(i * 11)) % 1;
    const x = lerp(1240, 40, p);
    const al = Math.sin(p * Math.PI) * (0.25 + letGo * 0.45);
    const lg = ctx.createLinearGradient(x + 90, laneY, x - 30, laneY);
    lg.addColorStop(0, 'rgba(56,189,248,0)');
    lg.addColorStop(0.5, withAlpha(i % 2 === 0 ? a : b, al));
    lg.addColorStop(1, 'rgba(251,191,36,0)');
    ctx.strokeStyle = lg;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(x + 90, laneY);
    ctx.lineTo(x - 30, laneY);
    ctx.stroke();
  }

  // تیتر
  drawWipeText(ctx, 'پاروها را بگذار کنار؛ تسلیم شو', cx, 134, '800 40px "Vazirmatn", sans-serif', '#e0f2fe', withAlpha(a, 0.65), (t - 0.7) / 1.8);

  // مقایسهٔ دو کارت: کلیشه «باید بجنگی» (خط‌خورده) در برابر «تسلیمِ جریانِ خدا»
  const cardP = easeOutCubic(clamp01((t - 10) / 2.2));
  if (cardP > 0.01) {
    // کارتِ راست: تسلیم
    drawGlassCard(ctx, 736, 188, 396, 108, b, cardP);
    drawGlowingText(ctx, 'پیامِ خداوند: تسلیمِ جریانِ نور', 934, 224, '800 22px "Vazirmatn", sans-serif', '#fde68a', withAlpha(b, 0.5), 14);
    drawGlowingText(ctx, 'زندگی میدانِ جنگ نیست؛ همسویی با جریان است', 934, 264, '500 16px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);

    // کارتِ چپ: کلیشهٔ نادرست با ضربدرِ ملایم
    drawGlassCard(ctx, 148, 188, 396, 108, '#fb7185', cardP * 0.85);
    drawGlowingText(ctx, 'کلیشهٔ رایج: باید با مشکلات بجنگی!', 346, 224, '700 20px "Vazirmatn", sans-serif', '#fda4af', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'پاروزدنِ فرساینده بر خلافِ جهتِ اقیانوس', 346, 264, '500 15px "Vazirmatn", sans-serif', '#94a3b8', 'rgba(0,0,0,0)', 0);
    // خطِ عبور قرمز
    const strikeP = easeOutCubic(clamp01((t - 18) / 1.5));
    if (strikeP > 0) {
      ctx.save();
      ctx.strokeStyle = 'rgba(251, 113, 133, 0.82)';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.moveTo(516, 224);
      ctx.lineTo(lerp(516, 176, strikeP), 224);
      ctx.stroke();
      ctx.restore();
    }
  }

  // ساحل و مقصد در پایین
  drawKineticPill(ctx, 940, 522, 'آرامش در قایق', (t - 8) / 1.3, a, '◈', 0.95, 18);
  drawKineticPill(ctx, 640, 522, 'جریانِ زندهٔ خداوند', (t - 14) / 1.3, b, '✦', 1.0, 18);
  drawKineticPill(ctx, 340, 522, 'رسیدن به ساحلِ امن', (t - 22) / 1.3, '#34d399', '◉', 0.95, 18);

  // موجِ پایانیِ آیه اگر زمان از نیمه گذشت
  if (t > d * 0.55) {
    drawVerseCard(ctx, cx, 522, 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', 'سوره فاتحه • آیه ۶', a, (t - d * 0.55) / 2, 680);
  }
};

/* ══════════ ۳ — هم‌جهت‌سازیِ ذهن و روح + مومنتوم مثبت ══════════ */
export const sceneMindSoulAlign: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 338;

  drawWipeText(ctx, 'انسانِ دو بُعدی: هم‌جهت‌سازیِ ذهن با روح', cx, 132, '800 38px "Vazirmatn", sans-serif', '#d1fae5', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // حلقهٔ هم‌ترازی مرکزی
  const align = easeInOutCubic(clamp01((t - 7) / (d * 0.42)));
  drawOrbitRing(ctx, cx, cy, 172, g * 0.25, a, 0.32, true);
  drawOrbitRing(ctx, cx, cy, 128, -g * 0.35, b, 0.26, true);
  drawAudioAuraRing(ctx, cx, cy, 90, g, e, a);

  // بردارِ روح (ثابت، مستقیم به بالا — جهتِ نور خداوند)
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = a;
  ctx.shadowColor = a;
  ctx.shadowBlur = 20;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 74);
  ctx.lineTo(0, -108);
  ctx.stroke();
  ctx.fillStyle = a;
  ctx.beginPath();
  ctx.moveTo(0, -124);
  ctx.lineTo(-14, -96);
  ctx.lineTo(14, -96);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // بردارِ ذهن (ابتدا با زاویه ۱۲۵ درجه منحرف و قرمز، سپس به‌نرمی هم‌جهت با روح و طلایی می‌شود!)
  const mindAngle = lerp(2.15, 0, align) + Math.sin(g * 4) * 0.08 * (1 - align);
  const mindColor = align > 0.65 ? b : '#fb7185';
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(mindAngle);
  ctx.strokeStyle = mindColor;
  ctx.shadowColor = mindColor;
  ctx.shadowBlur = 18;
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 56);
  ctx.lineTo(0, -92);
  ctx.stroke();
  ctx.fillStyle = mindColor;
  ctx.beginPath();
  ctx.moveTo(0, -106);
  ctx.lineTo(-12, -82);
  ctx.lineTo(12, -82);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // زاویه هم‌جهتی در مرکز
  const deg = Math.round(lerp(123, 0, align));
  drawGlowingText(
    ctx,
    align > 0.92 ? 'هم‌جهتِ کامل ✓' : `اختلافِ زاویه: ${deg}°`,
    cx,
    cy + 106,
    '800 20px "Vazirmatn", sans-serif',
    align > 0.92 ? '#fde68a' : '#cbd5e1',
    withAlpha(a, 0.5),
    12,
  );

  // کارت راست: روح و قلب (جایگاه خدا)
  drawGlassCard(ctx, 882, 224, 316, 200, a, easeOutCubic(clamp01((t - 2) / 1.8)));
  drawHeart(ctx, 1040, 276, 30, a, e);
  drawGlowingText(ctx, 'روح و قلب', 1040, 326, '800 24px "Vazirmatn", sans-serif', '#6ee7b7', withAlpha(a, 0.4), 10);
  drawGlowingText(ctx, 'جایگاهِ نور و آرامشِ خداوند', 1040, 362, '500 16px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'همیشه در صراطِ مستقیم', 1040, 392, '600 15px "Vazirmatn", sans-serif', '#a7f3d0', 'rgba(0,0,0,0)', 0);

  // کارت چپ: ذهن (نیازمند تربیت)
  drawGlassCard(ctx, 82, 224, 316, 200, mindColor, easeOutCubic(clamp01((t - 3) / 1.8)));
  drawNodeBadge(ctx, 240, 274, 24, align > 0.7 ? '✓' : '!', mindColor, (t - 3.5) / 1);
  drawGlowingText(ctx, 'ذهنِ انسان', 240, 326, '800 24px "Vazirmatn", sans-serif', align > 0.7 ? '#fde68a' : '#fda4af', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'کلِ قرآن = کتابِ تربیتِ ذهن', 240, 362, '600 16px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, align > 0.7 ? 'تسلیم و هم‌سو با روح' : 'مومنتومِ منفی ← قطع کن!', 240, 392, '600 15px "Vazirmatn", sans-serif', mindColor, 'rgba(0,0,0,0)', 0);

  // چهار ستون تربیت ذهن در پایین
  const pills = ['اعراض از نازیبایی', 'قطعِ مومنتومِ منفی', 'شکرگزاری و فراوانی', 'صَدَّقَ بِالْحُسْنَىٰ'];
  pills.forEach((lbl, i) => {
    const px = 1040 - i * 266;
    drawKineticPill(ctx, px, 526, lbl, (t - 10 - i * 3) / 1.4, i % 2 === 0 ? a : b, undefined, 0.9, 16);
  });
};

/* ══════════ ۴ — فراوانی؛ از نعمتِ درون تا جهانِ پیرامون ══════════ */
export const sceneAbundanceOrbit: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  const cy = 374;

  drawWipeText(ctx, 'دایرهٔ بی‌کرانِ فراوانی و شکرگزاری', cx, 122, '800 38px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // سه مدارِ هم‌مرکزِ نعمت با فاصله‌گذاری دقیق و بدون تداخل
  const rings = [
    { rx: 102, ry: 66, speed: 0.22, color: '#fbbf24', items: ['چشم', 'گوش', 'قلب', 'زبان'], delay: 2 },
    { rx: 205, ry: 122, speed: -0.14, color: '#34d399', items: ['خورشید', 'جنگل', 'اقیانوس', 'کوه‌ها', 'ابر و باد', 'دشت'], delay: 9 },
    { rx: 312, ry: 174, speed: 0.09, color: '#38bdf8', items: ['جاده', 'ساختمان‌ها', 'باغ‌ها', 'بازار و مغازه', 'نور و برق', 'آفرینشِ شهر'], delay: 18 },
  ];

  // هسته شکرگزاری
  drawAudioAuraRing(ctx, cx, cy, 44, g, e, a);
  drawHeart(ctx, cx, cy + 4, 30, a, e);
  drawGlowingText(ctx, 'شُکر', cx, cy + 2, '800 19px "Vazirmatn", sans-serif', '#fef9c3', withAlpha(a, 0.7), 12);

  rings.forEach((ring, ri) => {
    const rp = easeOutCubic(clamp01((t - ring.delay) / 2.6));
    if (rp <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = rp;
    // رسم مدار بیضوی ظریف
    ctx.strokeStyle = withAlpha(ring.color, 0.26);
    ctx.lineWidth = 1.3;
    ctx.setLineDash([6, 8]);
    ctx.beginPath();
    ctx.ellipse(cx, cy, ring.rx, ring.ry, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    ring.items.forEach((label, idx) => {
      const angle = (idx / ring.items.length) * Math.PI * 2 + g * ring.speed + ri * 0.55;
      const x = cx + Math.cos(angle) * ring.rx;
      const y = cy + Math.sin(angle) * ring.ry;
      drawFlowPulse(ctx, cx, cy, x, y, g + idx * 0.3, ring.color, e * 0.5);
      drawKineticPill(ctx, x, y, label, (t - ring.delay - idx * 0.6) / 1.1, ring.color, undefined, 0.82, 14);
    });
    ctx.restore();
  });

  // راهنمای سه حلقه در گوشه‌های امنِ چپ و راست
  drawGlassCard(ctx, 36, 200, 214, 126, '#fbbf24', easeOutCubic(clamp01((t - 4) / 1.8)));
  drawGlowingText(ctx, '۱. درونِ بدن', 143, 234, '800 18px "Vazirmatn", sans-serif', '#fde68a', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'چشم، گوش، قلب و نفس', 143, 268, '500 13.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'شکرگزاریِ هرروزه', 143, 298, '600 13.5px "Vazirmatn", sans-serif', '#fbbf24', 'rgba(0,0,0,0)', 0);

  drawGlassCard(ctx, 1030, 200, 214, 126, '#34d399', easeOutCubic(clamp01((t - 14) / 1.8)));
  drawGlowingText(ctx, '۲ و ۳. جهانِ پیرامون', 1137, 234, '800 17.5px "Vazirmatn", sans-serif', '#6ee7b7', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'طبیعتِ الهی + ساختهٔ انسان', 1137, 268, '500 13px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'تمرینِ ذهنِ فراوانی‌بین', 1137, 298, '600 13.5px "Vazirmatn", sans-serif', b, 'rgba(0,0,0,0)', 0);
};

/* ══════════ ۵ — مهارِ اسبِ چموش و قطب‌نمای درون ══════════ */
export const sceneHorseCompass: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;

  drawWipeText(ctx, 'مهارِ ذهن و قطب‌نمای درونِ قلب', cx, 130, '800 38px "Vazirmatn", sans-serif', '#ccfbf1', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  const calm = easeInOutCubic(clamp01((t - 6) / (d * 0.45)));

  // سمتِ راست: قطب‌نمای بزرگِ احساسِ درون
  const compX = 875;
  const compY = 355;
  const swing = Math.sin(g * 3.2) * 1.15 * (1 - calm) + Math.sin(g * 1.6) * 0.04;
  drawAudioAuraRing(ctx, compX, compY, 134, g, e, calm > 0.55 ? a : '#fb7185');
  drawCompass(ctx, compX, compY, 122, swing, b, calm);
  drawGlowingText(
    ctx,
    'صراطِ مستقیم',
    compX,
    compY - 142,
    '800 18px "Vazirmatn", sans-serif',
    '#6ee7b7',
    withAlpha(a, 0.6),
    12,
  );
  drawKineticPill(
    ctx,
    compX,
    compY + 158,
    calm > 0.55 ? 'احساسِ خوب = صدایِ خدا' : 'احساسِ بد = خروج از صراط!',
    (t - 2) / 1.2,
    calm > 0.55 ? '#34d399' : '#fb7185',
    calm > 0.55 ? '✦' : '!',
    0.95,
    17,
  );

  // سمتِ چپ: کارتِ مهارِ اسبِ چموش (ذهن) با افسارِ طلایی
  const cardP = easeOutCubic(clamp01((t - 1.5) / 1.8));
  drawGlassCard(ctx, 98, 210, 490, 290, calm > 0.5 ? b : '#fb7185', cardP);

  // سیلوئتِ هندسیِ سر و گردنِ اسب + افسارِ نورانی
  ctx.save();
  ctx.translate(342, 342);
  const rear = (1 - calm) * Math.sin(g * 6) * 0.14;
  ctx.rotate(rear);
  ctx.strokeStyle = calm > 0.5 ? b : '#fda4af';
  ctx.fillStyle = withAlpha(calm > 0.5 ? b : '#fb7185', 0.16);
  ctx.shadowColor = calm > 0.5 ? b : '#fb7185';
  ctx.shadowBlur = 18;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-64, 54);
  ctx.quadraticCurveTo(-58, -12, -18, -56);
  ctx.lineTo(-4, -84); // گوش
  ctx.lineTo(12, -58);
  ctx.quadraticCurveTo(46, -42, 70, -10); // پوزه
  ctx.quadraticCurveTo(60, 8, 36, 4);
  ctx.quadraticCurveTo(18, 22, 22, 54);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // افسار طلاییِ مهار
  ctx.strokeStyle = '#fde68a';
  ctx.lineWidth = 2.6;
  ctx.setLineDash([6, 4]);
  ctx.beginPath();
  ctx.moveTo(52, -4);
  ctx.quadraticCurveTo(8, 26, -78, 32);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  drawGlowingText(
    ctx,
    'اسبِ چموشِ ذهن',
    342,
    244,
    '800 22px "Vazirmatn", sans-serif',
    '#fde68a',
    'rgba(0,0,0,0)',
    0,
  );
  drawGlowingText(
    ctx,
    calm > 0.6 ? 'افسار مهار شد ← آرامشِ عمیقِ قلب' : 'سرکشیِ ذهن ← نیازمندِ مهار و تربیت',
    342,
    464,
    '700 17px "Vazirmatn", sans-serif',
    calm > 0.6 ? '#6ee7b7' : '#fda4af',
    'rgba(0,0,0,0)',
    0,
  );

  // اتصال پالس بین مهار ذهن و قطب‌نمای قلب
  drawFlowPulse(ctx, 590, 355, 745, 355, g * 1.4, a, e);
};
