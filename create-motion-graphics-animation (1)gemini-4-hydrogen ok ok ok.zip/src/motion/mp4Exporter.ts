import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import { drawMotionFrame } from './renderer';
import { AUDIO_URL, getDurationForMode, type EditionMode } from './timeline';

export type AudioSource = 'voice' | 'none';

export interface ExportProgress {
  phase: 'preparing' | 'audio_build' | 'encoding_audio' | 'rendering_video' | 'finalizing';
  percent: number;
  currentFrame: number;
  totalFrames: number;
  elapsedSec: number;
  etaSec: number;
  detail: string;
}

export interface ExportResult {
  blob: Blob;
  filename: string;
  sizeBytes: number;
  codecLabel: string;
  mimeType: string;
  width: number;
  height: number;
  fps: number;
  durationSec: number;
}

export interface ExportOptions {
  mode: EditionMode;
  audioSource: AudioSource;
  resolution: '720p' | '1080p';
  fps: number;
  showSubtitles: boolean;
  showHud: boolean;
  narrationUrl?: string;
  signal?: AbortSignal;
  onProgress?: (p: ExportProgress) => void;
  onPreviewCanvas?: (canvas: HTMLCanvasElement) => void;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function isWebCodecsSupported(): boolean {
  return (
    typeof VideoEncoder !== 'undefined' &&
    typeof AudioEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined' &&
    typeof AudioData !== 'undefined'
  );
}

export async function ensureFontsReady(): Promise<void> {
  if (!('fonts' in document)) return;
  const specs = [
    '700 40px "Amiri"',
    '400 40px "Amiri"',
    '400 24px "Vazirmatn"',
    '600 24px "Vazirmatn"',
    '700 24px "Vazirmatn"',
    '800 24px "Vazirmatn"',
    '900 24px "Vazirmatn"',
  ];
  try {
    await Promise.all(specs.map((s) => document.fonts.load(s, 'جریان نور صراط مستقیم')));
    await document.fonts.ready;
  } catch {
    /* noop */
  }
}

async function pickVideoConfig(width: number, height: number, fps: number) {
  const candidates: Array<{ webCodec: string; muxCodec: 'avc' | 'vp9'; label: string }> = [
    { webCodec: 'avc1.640028', muxCodec: 'avc', label: 'H.264 High' },
    { webCodec: 'avc1.640032', muxCodec: 'avc', label: 'H.264 High L5.0' },
    { webCodec: 'avc1.4d002a', muxCodec: 'avc', label: 'H.264 Main' },
    { webCodec: 'avc1.42E01F', muxCodec: 'avc', label: 'H.264 Baseline' },
    { webCodec: 'vp09.00.10.08', muxCodec: 'vp9', label: 'VP9' },
  ];
  for (const c of candidates) {
    try {
      const cfg: VideoEncoderConfig = {
        codec: c.webCodec,
        width,
        height,
        framerate: fps,
        bitrate: width >= 1920 ? 5_200_000 : 1_800_000,
        latencyMode: 'quality',
        avc: { format: 'avc' },
      } as VideoEncoderConfig;
      const res = await VideoEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* next */
    }
  }
  return null;
}

async function pickAudioConfig() {
  const candidates: Array<{
    webCodec: string;
    muxCodec: 'aac' | 'opus';
    sampleRate: number;
    numberOfChannels: number;
    bitrate: number;
    label: string;
  }> = [
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 48000, numberOfChannels: 2, bitrate: 128_000, label: 'AAC-Stereo ۴۸kHz' },
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 44100, numberOfChannels: 2, bitrate: 128_000, label: 'AAC-Stereo ۴۴.۱kHz' },
    { webCodec: 'opus', muxCodec: 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: 96_000, label: 'Opus' },
  ];
  for (const c of candidates) {
    try {
      const cfg: AudioEncoderConfig = {
        codec: c.webCodec,
        sampleRate: c.sampleRate,
        numberOfChannels: c.numberOfChannels,
        bitrate: c.bitrate,
      };
      const res = await AudioEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* next */
    }
  }
  return null;
}

function buildEnergyEnvelope(pcm: Float32Array, sampleRate: number, durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  const step = Math.floor(sampleRate / 10);
  for (let b = 0; b < buckets; b++) {
    const start = b * step;
    const end = Math.min(pcm.length, start + step);
    if (end <= start) break;
    let sum = 0;
    for (let i = start; i < end; i++) sum += pcm[i] * pcm[i];
    out[b] = Math.min(1, Math.sqrt(sum / (end - start)) * 3.2);
  }
  return out;
}

function syntheticEnvelope(durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  for (let b = 0; b < buckets; b++) {
    const t = b / 10;
    out[b] = 0.2 + 0.11 * Math.sin(t * 1.8) + 0.07 * Math.sin(t * 4.4);
  }
  return out;
}

async function decodeNarration(url: string, durationSec: number, sampleRate: number): Promise<Float32Array> {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error('دریافت فایل صوتی روایت ناموفق بود (HTTP ' + resp.status + ').');
  const bytes = await resp.arrayBuffer();
  const tmp = new AudioContext();
  let decoded: AudioBuffer;
  try {
    decoded = await tmp.decodeAudioData(bytes.slice(0));
  } finally {
    await tmp.close();
  }
  const len = Math.ceil(durationSec * sampleRate);
  let out: Float32Array;
  if (decoded.sampleRate === sampleRate && decoded.numberOfChannels === 1 && decoded.length >= len) {
    out = decoded.getChannelData(0).slice(0, len);
  } else {
    const off = new OfflineAudioContext(1, len, sampleRate);
    const src = off.createBufferSource();
    src.buffer = decoded;
    src.connect(off.destination);
    src.start(0);
    const rendered = await off.startRendering();
    out = rendered.getChannelData(0).slice(0, len);
  }
  // فیدآوت نرم ۲.۵ ثانیه‌ای در پایان
  const fadeSamples = Math.min(out.length, Math.floor(2.5 * sampleRate));
  for (let i = 0; i < fadeSamples; i++) {
    out[out.length - fadeSamples + i] *= 1 - i / fadeSamples;
  }
  return out;
}

export async function exportMotionToMp4(opts: ExportOptions): Promise<ExportResult> {
  if (!isWebCodecsSupported()) {
    throw new Error('این مرورگر از WebCodecs پشتیبانی نمی‌کند. لطفاً از Chrome یا Edge نسخهٔ جدید استفاده کنید.');
  }

  const fps = Math.max(12, Math.min(60, Math.round(opts.fps)));
  const width = opts.resolution === '1080p' ? 1920 : 1280;
  const height = opts.resolution === '1080p' ? 1080 : 720;
  const totalDur = getDurationForMode(opts.mode);
  const totalFrames = Math.round(totalDur * fps);
  const t0 = performance.now();

  const report = (p: Omit<ExportProgress, 'elapsedSec' | 'etaSec'>, eta = 0) =>
    opts.onProgress?.({ ...p, elapsedSec: (performance.now() - t0) / 1000, etaSec: eta });

  report({ phase: 'preparing', percent: 1, currentFrame: 0, totalFrames, detail: 'آماده‌سازی فونت‌ها و کدک‌ها…' });
  await ensureFontsReady();

  const video = await pickVideoConfig(width, height, fps);
  if (!video) throw new Error('کدک ویدیویی سازگار (H.264/VP9) پیدا نشد.');
  const audio = await pickAudioConfig();
  if (!audio) throw new Error('کدک صوتی سازگار (AAC/Opus) پیدا نشد.');

  report({ phase: 'audio_build', percent: 4, currentFrame: 0, totalFrames, detail: 'دریافت و پردازش باند صوتی…' });
  let pcm: Float32Array;
  if (opts.audioSource === 'voice') {
    pcm = await decodeNarration(opts.narrationUrl || AUDIO_URL, totalDur, audio.sampleRate);
  } else {
    pcm = new Float32Array(Math.ceil(totalDur * audio.sampleRate));
  }
  const envelope =
    opts.audioSource === 'none' ? syntheticEnvelope(totalDur) : buildEnergyEnvelope(pcm, audio.sampleRate, totalDur);

  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: { codec: video.muxCodec, width, height, frameRate: fps },
    audio: { codec: audio.muxCodec, numberOfChannels: audio.numberOfChannels, sampleRate: audio.sampleRate },
    fastStart: 'in-memory',
    firstTimestampBehavior: 'offset',
  });

  let encError: Error | null = null;
  const onErr = (e: DOMException | Error) => {
    encError = e instanceof Error ? e : new Error(String(e));
  };

  const videoEncoder = new VideoEncoder({ output: (chunk, meta) => muxer.addVideoChunk(chunk, meta), error: onErr });
  videoEncoder.configure(video.config);
  const audioEncoder = new AudioEncoder({ output: (chunk, meta) => muxer.addAudioChunk(chunk, meta), error: onErr });
  audioEncoder.configure(audio.config);

  const abortIfAsked = () => {
    if (opts.signal?.aborted) {
      try {
        videoEncoder.close();
        audioEncoder.close();
      } catch {
        /* noop */
      }
      throw new DOMException('ساخت ویدیو لغو شد.', 'AbortError');
    }
    if (encError) throw encError;
  };

  report({
    phase: 'encoding_audio',
    percent: 14,
    currentFrame: 0,
    totalFrames,
    detail: `رمزگذاری صدا با ${audio.label}…`,
  });
  const chunkFrames = 1024;
  const totalSamples = pcm.length;
  for (let offset = 0; offset < totalSamples; offset += chunkFrames) {
    abortIfAsked();
    const count = Math.min(chunkFrames, totalSamples - offset);
    const planar = new Float32Array(count * audio.numberOfChannels);
    for (let ch = 0; ch < audio.numberOfChannels; ch++) {
      planar.set(pcm.subarray(offset, offset + count), ch * count);
    }
    const data = new AudioData({
      format: 'f32-planar',
      sampleRate: audio.sampleRate,
      numberOfFrames: count,
      numberOfChannels: audio.numberOfChannels,
      timestamp: Math.round((offset / audio.sampleRate) * 1_000_000),
      data: planar,
    });
    audioEncoder.encode(data);
    data.close();
    while (audioEncoder.encodeQueueSize > 20) await sleep(2);
    if (offset % (chunkFrames * 400) === 0) {
      report({
        phase: 'encoding_audio',
        percent: 14 + (offset / totalSamples) * 10,
        currentFrame: 0,
        totalFrames,
        detail: `رمزگذاری صدا… ${Math.round((offset / totalSamples) * 100)}٪`,
      });
    }
  }
  while (audioEncoder.encodeQueueSize > 0) await sleep(4);
  pcm = new Float32Array(0);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('ایجاد بوم Canvas2D ممکن نشد.');

  let lastReport = performance.now();
  for (let i = 0; i < totalFrames; i++) {
    abortIfAsked();
    const timeSec = i / fps;
    const energy = envelope[Math.min(envelope.length - 1, Math.floor(timeSec * 10))] ?? 0.22;
    drawMotionFrame(ctx, timeSec, width, height, energy, {
      mode: opts.mode,
      showSubtitles: opts.showSubtitles,
      showHud: opts.showHud,
    });

    const frame = new VideoFrame(canvas, {
      timestamp: Math.round((i * 1_000_000) / fps),
      duration: Math.round(1_000_000 / fps),
    });
    videoEncoder.encode(frame, { keyFrame: i % (fps * 2) === 0 });
    frame.close();

    while (videoEncoder.encodeQueueSize > 8) await sleep(3);
    if (i % 6 === 0) await sleep(0);

    const now = performance.now();
    if (now - lastReport > 180) {
      lastReport = now;
      const elapsed = (now - t0) / 1000;
      const pct = 24 + (i / totalFrames) * 72;
      const speed = i / Math.max(0.001, elapsed);
      const eta = speed > 0 ? (totalFrames - i) / speed : 0;
      opts.onPreviewCanvas?.(canvas);
      report(
        {
          phase: 'rendering_video',
          percent: pct,
          currentFrame: i,
          totalFrames,
          detail: `رندر فریم ${i} از ${totalFrames} • ${speed.toFixed(1)} فریم/ثانیه`,
        },
        eta,
      );
    }
  }

  report({ phase: 'finalizing', percent: 97, currentFrame: totalFrames, totalFrames, detail: 'نهایی‌سازی فایل MP4…' });
  while (videoEncoder.encodeQueueSize > 0 || audioEncoder.encodeQueueSize > 0) await sleep(6);
  try {
    await videoEncoder.flush();
    await audioEncoder.flush();
  } catch {
    /* noop */
  }
  videoEncoder.close();
  audioEncoder.close();
  muxer.finalize();

  const buf = target.buffer;
  const blob = new Blob([buf], { type: video.muxCodec === 'avc' ? 'video/mp4' : 'video/webm' });
  const name =
    opts.mode === '15min'
      ? `jaryan-noor-15min-${opts.resolution}.mp4`
      : `jaryan-noor-full-28min-${opts.resolution}.mp4`;

  report({ phase: 'finalizing', percent: 100, currentFrame: totalFrames, totalFrames, detail: 'آمادهٔ دانلود و آپلود.' });

  return {
    blob,
    filename: name,
    sizeBytes: blob.size,
    codecLabel: `${video.label} + ${audio.label}`,
    mimeType: blob.type,
    width,
    height,
    fps,
    durationSec: totalDur,
  };
}
