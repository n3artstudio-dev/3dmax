/* ------------------------------------------------------------------
   scenesPart4.ts — صحنه‌های المان‌محور فصل ۱۶ تا ۲۲ (نسخهٔ کاملِ ۲۸:۳۵)
------------------------------------------------------------------ */
import {
  clamp01,
  drawAudioAuraRing,
  drawFlowPulse,
  drawGlowingText,
  drawKineticPill,
  drawOrbitRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import {
  drawFigure,
  drawGlassCard,
  drawPopText,
  drawRadioWaves,
  drawStar8,
  drawWaterWaves,
  drawWaveform,
  drawWipeText,
} from './fx';
import type { SceneFn } from './scenesPart1';

/* ══════════ ۱۶ — نورِ آیات و مسئولیتِ انتخابِ مسیر ══════════ */
export const sceneLightVsDarkness: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  const cy = 335;
  drawWipeText(ctx, 'خدا عذاب نمی‌دهد؛ انتخابِ نور یا تاریکی با ماست', cx, 124, '800 35px "Vazirmatn", sans-serif', '#fef08a', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // منشور مرکزی قرآن
  drawAudioAuraRing(ctx, cx, cy, 85, g, e, a);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.moveTo(0, -86);
  ctx.lineTo(84, 62);
  ctx.lineTo(-84, 62);
  ctx.closePath();
  ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
  ctx.fill();
  ctx.strokeStyle = a;
  ctx.shadowColor = a;
  ctx.shadowBlur = 22;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();
  drawGlowingText(ctx, 'نورِ آیات', cx, cy + 12, '800 22px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.6), 12);

  // پرتوی راست: هدایت و گشایش
  for (let i = 0; i < 5; i++) {
    drawFlowPulse(ctx, cx + 62, cy - 12 + i * 10, 1140, 220 + i * 52, g * 1.1 + i * 0.2, i % 2 === 0 ? a : b, e);
  }
  drawGlassCard(ctx, 886, 250, 300, 160, a, easeOutCubic(clamp01((t - 4) / 2)));
  drawGlowingText(ctx, 'انتخابِ هدایت', 1036, 296, '800 22px "Vazirmatn", sans-serif', '#fde68a', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'آیاتِ قرآن جلوی راهت را', 1036, 336, '500 16px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'در تاریکی روشن می‌کند', 1036, 368, '700 16px "Vazirmatn", sans-serif', '#6ee7b7', 'rgba(0,0,0,0)', 0);

  // سمت چپ: مسیرِ تاریکی و انتخابِ شخصی
  drawGlassCard(ctx, 94, 250, 300, 160, '#fb7185', easeOutCubic(clamp01((t - 8) / 2)));
  drawGlowingText(ctx, 'روی‌گردانی از نور', 244, 296, '800 22px "Vazirmatn", sans-serif', '#fda4af', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'ارتباطِ خدا قطع نمی‌شود؛', 244, 336, '500 16px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'خودمان واردِ مسیرِ خطا می‌شویم', 244, 368, '700 15.5px "Vazirmatn", sans-serif', '#fb7185', 'rgba(0,0,0,0)', 0);

  drawVerseCard(ctx, cx, 532, 'يُضِلُّ بِهِ كَثِيرًا وَيَهْدِي بِهِ كَثِيرًا', 'سوره بقره • آیه ۲۶', a, (t - 12) / 2, 740);
};

/* ══════════ ۱۷ — قطعِ مومنتومِ منفی در همین فریم ══════════ */
export const sceneCutNegativeMomentum: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'مومنتومِ منفی را همین حالا قطع کن!', cx, 124, '800 38px "Vazirmatn", sans-serif', '#d1fae5', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  const cut = easeInOutCubic(clamp01((t - d * 0.35) / 3.5));

  // نوارِ فیلمِ زمان (۶ فریم) — ۳ فریم راست قرمزِ گذشته، ۳ فریم چپ سبزِ آینده پس از برشِ طلایی!
  const y = 315;
  for (let i = 0; i < 6; i++) {
    const fx = 1055 - i * 166;
    const isPast = i < 3;
    const col = isPast ? b : a;
    const sep = isPast ? 0 : -cut * 28;
    ctx.save();
    ctx.globalAlpha = isPast ? 1 - cut * 0.45 : 0.45 + cut * 0.55;
    drawRoundedRect(ctx, fx - 68 + sep, y - 56, 136, 112, 14);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.88)';
    ctx.fill();
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    ctx.stroke();
    drawGlowingText(ctx, isPast ? 'بدبیاریِ دیروز' : 'فرکانسِ مثبت', fx + sep, y - 8, '700 14.5px "Vazirmatn", sans-serif', isPast ? '#fda4af' : '#6ee7b7', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, isPast ? 'توقف!' : 'گشایش ✓', fx + sep, y + 22, '800 15px "Vazirmatn", sans-serif', col, 'rgba(0,0,0,0)', 0);
    ctx.restore();
  }

  // تیغِ نورانیِ برش (اعراض) در مرکزِ نوار فیلم
  if (cut > 0.02) {
    ctx.save();
    ctx.strokeStyle = '#fde047';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 24;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(640, lerp(190, 210, cut));
    ctx.lineTo(640, lerp(210, 425, cut));
    ctx.stroke();
    ctx.restore();
    drawKineticPill(ctx, 640, 204, 'برشِ مومنتومِ منفی (اعراض در همین آن)', cut, '#fbbf24', '◈', 0.96, 17);
  }

  // نتایج ۱ تا ۲ ساعت بعد
  drawKineticPill(ctx, 940, 488, 'جای پارکِ آماده', (t - 26) / 1.4, a, '✦', 0.92, 16);
  drawKineticPill(ctx, 640, 488, 'تلفن و خبرِ خوش', (t - 32) / 1.4, '#38bdf8', '✦', 0.92, 16);
  drawKineticPill(ctx, 340, 488, 'کارهای اداریِ آسان', (t - 38) / 1.4, '#fbbf24', '✦', 0.92, 16);
  drawStar8(ctx, 180, 315, 18 + e * 6, a, g * 0.9, true);
};

/* ══════════ ۱۸ — توبه؛ بازگشتِ واقعی بدونِ احساسِ گناه ══════════ */
export const sceneTawbahReset: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'توبه؛ پاک‌سازیِ کامل بدونِ احساسِ گناه', cx, 124, '800 37px "Vazirmatn", sans-serif', '#e0f2fe', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  const wipe = easeInOutCubic(clamp01((t - d * 0.42) / 6));

  // راست: ۳ سال ابرهای تاریکِ بدبینی (که با موج طلایی پاک می‌شوند)
  drawGlassCard(ctx, 720, 206, 440, 224, '#fb7185', 1 - wipe * 0.52);
  drawGlowingText(ctx, '۳ سال منفی‌نگری و احساسِ گناه', 940, 260, '800 21px "Vazirmatn", sans-serif', '#fda4af', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'بدترین فرکانس: ماندن در خطای گذشته', 940, 306, '600 16px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, wipe > 0.65 ? 'باطل و پاک شد ✓' : 'حرکت به سوی افسردگی', 940, 366, '800 19px "Vazirmatn", sans-serif', wipe > 0.65 ? '#34d399' : '#fb7185', 'rgba(0,0,0,0)', 0);

  // چپ: ۷ روز (۱ هفته) ستونِ خورشیدیِ ورودیِ مثبت
  drawGlassCard(ctx, 120, 206, 460, 224, b, 1);
  drawGlowingText(ctx, 'تنها ۱ هفته ورودیِ مثبت', 350, 248, '800 22px "Vazirmatn", sans-serif', '#fde68a', withAlpha(b, 0.4), 10);
  for (let day = 0; day < 7; day++) {
    const dp = easeOutBack(clamp01((t - 10 - day * 2.5) / 1.4));
    const bx = 520 - day * 56;
    const bh = 78 * dp;
    drawRoundedRect(ctx, bx - 16, 372 - bh, 32, bh, 8);
    ctx.fillStyle = withAlpha(day === 6 ? '#34d399' : b, 0.82);
    ctx.fill();
    drawGlowingText(ctx, toFaDigits(day + 1), bx, 396, '700 14px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(0,0,0,0)', 0);
  }

  // فلش پالسِ تغییر از راست به چپ
  drawAudioAuraRing(ctx, cx, 318, 42, g, e, a);
  drawFlowPulse(ctx, 718, 318, 584, 318, g * 1.5, b, e);

  drawVerseCard(
    ctx,
    cx,
    522,
    'رَبِّ إِنِّي ظَلَمْتُ نَفْسِي فَاغْفِرْ لِي فَغَفَرَ لَهُ',
    'توبهٔ فوریِ حضرتِ موسی — بدونِ ماندن در احساسِ گناه',
    a,
    (t - 8) / 2,
    840,
  );
};

/* ══════════ ۱۹ — دکلِ ارسالِ فرکانس و بِمَا قَدَّمَتْ أَيْدِيهِمْ ══════════ */
export const sceneFrequencyTransmitter: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'انسان؛ دکلِ ارسالِ فرکانس به جهانِ هستی', cx, 124, '800 37px "Vazirmatn", sans-serif', '#f3e8ff', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  // دکل ارسال در مرکز
  const tx = cx;
  const ty = 258;
  drawRadioWaves(ctx, tx, ty, g * 1.15, a, 210, 1, 6);
  drawRadioWaves(ctx, tx, ty, g * 0.85, b, 210, -1, 4);

  // برج هندسی دکل
  ctx.save();
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(tx, ty);
  ctx.lineTo(tx - 48, 440);
  ctx.moveTo(tx, ty);
  ctx.lineTo(tx + 48, 440);
  ctx.moveTo(tx - 24, 350);
  ctx.lineTo(tx + 24, 350);
  ctx.moveTo(tx - 38, 400);
  ctx.lineTo(tx + 38, 400);
  ctx.stroke();
  drawStar8(ctx, tx, ty, 18 + e * 8, '#fde047', g * 0.9, true);
  ctx.restore();

  // موجِ ارسال‌شده (راست) و موجِ بازگشتی از جهان (چپ)
  drawWaveform(ctx, 740, 1180, 326, 28 + e * 16, 4, g * 5.2, a, 0);
  drawWaveform(ctx, 100, 540, 326, 28 + e * 16, 4, -g * 5.2, b, 0);

  drawKineticPill(ctx, 960, 240, 'ارسالِ لحظه‌ایِ فکر و ارتعاش', (t - 3) / 1.3, a, '◉', 0.94, 17);
  drawKineticPill(ctx, 320, 240, 'بازگشتِ دقیق و قانونمندِ جهان', (t - 7) / 1.3, b, '↩', 0.94, 17);
  drawPopText(ctx, 'زندگی دوتا چهارتاست • یا توحید یا شرک، یا حق یا باطل', cx, 466, '700 18px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.45), (t - 14) / 1.5);

  drawVerseCard(ctx, cx, 536, 'بِمَا قَدَّمَتْ أَيْدِيهِمْ', 'آنچه پیشاپیش با فرکانسِ خود فرستاده‌اید', a, (t - 10) / 2, 720);
};

/* ══════════ ۲۰ — رازِ حضرتِ سلیمان؛ شکرگزاری و مُلکِ عظیم ══════════ */
export const sceneSulaymanKingdom: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  const cy = 344;
  drawWipeText(ctx, 'رازِ حضرتِ سلیمان: شکرگزاری و تسلیمِ ذهن', cx, 124, '800 37px "Vazirmatn", sans-serif', '#fef08a', withAlpha(a, 0.7), (t - 0.6) / 1.8);

  // هالهٔ مراقبه و شکرگزاری در مرکز
  drawOrbitRing(ctx, cx, cy, 180, g * 0.22, a, 0.4, true);
  drawOrbitRing(ctx, cx, cy, 125, -g * 0.32, b, 0.36, true);
  drawAudioAuraRing(ctx, cx, cy, 74, g, e, a);
  drawFigure(ctx, cx, cy + 16, 1.05, '#fde68a', 22);

  // ۴ پاداشِ بزرگِ تسلیم و شکرگزاریِ سلیمان در مدار
  const gifts = [
    { title: 'تسخیرِ بادها', sub: 'جریانِ سریعِ کارها', x: 1010, y: 245, c: '#38bdf8' },
    { title: 'زبانِ پرندگان', sub: 'درکِ نشانه‌های خلقت', x: 270, y: 245, c: '#34d399' },
    { title: 'قصرها و سازه‌ها', sub: 'قدرتِ جنیان در کوه', x: 1010, y: 405, c: '#fbbf24' },
    { title: 'جواهراتِ دریا', sub: 'ثروتِ بی‌زجر و فراوانی', x: 270, y: 405, c: '#c084fc' },
  ];

  gifts.forEach((gf, i) => {
    const gp = easeOutBack(clamp01((t - 4 - i * 4.5) / 1.6));
    if (gp <= 0.01) return;
    drawFlowPulse(ctx, cx, cy, gf.x, gf.y, g * 1.15 + i * 0.25, gf.c, e);
    drawGlassCard(ctx, gf.x - 125, gf.y - 44, 250, 88, gf.c, gp);
    drawGlowingText(ctx, gf.title, gf.x, gf.y - 10, '800 19px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, gf.sub, gf.x, gf.y + 22, '500 14px "Vazirmatn", sans-serif', gf.c, 'rgba(0,0,0,0)', 0);
  });

  drawVerseCard(
    ctx,
    cx,
    534,
    'هَٰذَا مِن فَضْلِ رَبِّي لِيَبْلُوَنِي أَأَشْكُرُ أَمْ أَكْفُرُ',
    'سوره نمل • آیه ۴۰ — کلیدِ فراوانی: شکرگزاریِ دائم',
    a,
    (t - 12) / 2,
    840,
  );
};

/* ══════════ ۲۱ — تغییرِ باور؛ تنظیمِ رادیو روی موجِ قرآن ══════════ */
export const sceneRadioWaveQuran: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'باورت را عوض کن؛ رادیو را روی موجِ قرآن بگذار', cx, 124, '800 35px "Vazirmatn", sans-serif', '#cffafe', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  const tune = easeInOutCubic(clamp01((t - 6) / (d * 0.55)));

  // پنل رادیوی کیهانی در مرکز
  drawGlassCard(ctx, 180, 198, 920, 255, tune > 0.6 ? a : '#fb7185', 1);

  // موجِ درون نمایشگر: از نویزِ قرمزِ ترس و غم ← به موجِ صاف و درخشانِ طلاییِ قرآن
  drawWaveform(
    ctx,
    220,
    1060,
    296,
    24 + e * 18,
    lerp(9, 3.5, tune),
    g * 6,
    tune > 0.6 ? a : '#fb7185',
    lerp(28, 0, tune),
  );

  // نوارِ درجه‌بندیِ فرکانس
  const trackX1 = 1010;
  const trackX2 = 270;
  const trackY = 394;
  ctx.strokeStyle = 'rgba(148,163,184,0.35)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(trackX1, trackY);
  ctx.lineTo(trackX2, trackY);
  ctx.stroke();

  const dialX = lerp(trackX1 - 40, trackX2 + 40, tune);
  ctx.fillStyle = tune > 0.6 ? b : '#fb7185';
  ctx.shadowColor = tune > 0.6 ? b : '#fb7185';
  ctx.shadowBlur = 18;
  drawRoundedRect(ctx, dialX - 8, trackY - 22, 16, 44, 6);
  ctx.fill();
  ctx.shadowBlur = 0;

  drawGlowingText(ctx, 'موجِ ترس، غم و سختی (نویز)', 920, 428, '700 15px "Vazirmatn", sans-serif', '#fda4af', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'کانالِ قرآن، نعمت و بُعدِ غیبی', 360, 428, '800 16px "Vazirmatn", sans-serif', '#fde68a', withAlpha(b, 0.4), 8);

  drawVerseCard(ctx, cx, 530, 'لَا خَوْفٌ عَلَيْهِمْ وَلَا هُمْ يَحْزَنُونَ', 'در بُعدِ غیبیِ خداوند نه ترسی هست و نه غمی', a, (t - 10) / 2, 780);
};

/* ══════════ ۲۲ — فراوانیِ پنهان؛ راه رفتن بر روی آب (پایانِ کامل) ══════════ */
export const sceneWalkOnWaterFinale: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'شما بر روی اقیانوسِ فراوانی راه می‌روید!', cx, 124, '800 38px "Vazirmatn", sans-serif', '#d1fae5', withAlpha(a, 0.7), (t - 0.6) / 1.8);

  // سطحِ شیشه‌ای زمین در y = 342
  ctx.save();
  const surf = ctx.createLinearGradient(0, 336, 1280, 336);
  surf.addColorStop(0, 'rgba(56,189,248,0)');
  surf.addColorStop(0.5, withAlpha(a, 0.85));
  surf.addColorStop(1, 'rgba(56,189,248,0)');
  ctx.strokeStyle = surf;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(60, 342);
  ctx.lineTo(1220, 342);
  ctx.stroke();
  ctx.restore();

  // اقیانوسِ درخشانِ فراوانیِ پنهان درست در زیرِ پاها
  drawWaterWaves(ctx, 358, 1280, g * 1.4, '#38bdf8', a, 4, 14);

  // گوی‌های نعمت که از دلِ آب بالا می‌آیند
  const blessings = ['آرامش', 'ثروت و نعمت', 'دوستِ خوب', 'شادی', 'شکرگزاری'];
  blessings.forEach((bl, i) => {
    const bx = 1040 - i * 200;
    const by = 435 + Math.sin(g * 1.8 + i * 1.1) * 14;
    drawKineticPill(ctx, bx, by, bl, (t - 5 - i * 3) / 1.4, i % 2 === 0 ? a : b, '✦', 0.92, 16);
  });

  // سیلوئتِ انسانِ آرام ایستاده بر سطح نورانی در مرکز
  drawAudioAuraRing(ctx, cx, 272, 68, g, e, b);
  drawFigure(ctx, cx, 294, 1.12, '#fde68a', 22);

  // قطرات نور صعودی از اقیانوس زیرین
  for (let i = 0; i < 22; i++) {
    const px = 140 + seeded(i * 19) * 1000;
    const py = 540 - ((g * (22 + seeded(i * 7) * 28) + i * 40) % 240);
    ctx.fillStyle = withAlpha(i % 2 === 0 ? '#38bdf8' : b, 0.55);
    ctx.beginPath();
    ctx.arc(px, py, 2.2 + seeded(i) * 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  drawVerseCard(
    ctx,
    cx,
    532,
    'وَأَن لَّوِ اسْتَقَامُوا عَلَى الطَّرِيقَةِ لَأَسْقَيْنَاهُم مَّاءً غَدَقًا',
    'سوره جن • آیه ۱۶ — زندگی در بُعدِ غیبیِ فراوانی و آرامش',
    b,
    (t - 10) / 2.2,
    860,
  );
};
