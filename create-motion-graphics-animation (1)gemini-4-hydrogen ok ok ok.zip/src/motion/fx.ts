/* ------------------------------------------------------------------
   fx.ts — افکت‌ها و المان‌های برداریِ اختصاصی موشن گرافیک
   همهٔ متن‌ها کامل رسم می‌شوند تا اتصال حروف فارسی کاملاً حفظ شود.
------------------------------------------------------------------ */
import {
  clamp01,
  drawRoundedRect,
  easeOutBack,
  easeOutCubic,
  lerp,
  seeded,
  withAlpha,
} from './drawPrimitives';

/** آشکارسازی متن با پردهٔ نوری از راست به چپ (سازگار با RTL و اتصال حروف) */
export function drawWipeText(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  glowBlur = 20,
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const w = ctx.measureText(text).width + 44;
  const size = Number(/(\d+)px/.exec(font)?.[1] ?? 30);
  const h = size * 2.1;
  const right = cx + w / 2;
  const revealW = w * easeOutCubic(p);
  ctx.beginPath();
  ctx.rect(right - revealW, cy - h / 2, revealW, h);
  ctx.clip();
  if (glowBlur > 0) {
    ctx.shadowColor = glow;
    ctx.shadowBlur = glowBlur;
  }
  ctx.fillStyle = fill;
  ctx.fillText(text, cx, cy);
  ctx.restore();
  if (p < 1) {
    const ex = right - revealW;
    ctx.save();
    const g = ctx.createLinearGradient(ex - 16, 0, ex + 16, 0);
    g.addColorStop(0, 'rgba(255,255,255,0)');
    g.addColorStop(0.5, withAlpha('#fde68a', 0.85));
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(ex - 16, cy - h / 2, 32, h);
    ctx.restore();
  }
}

/** متن با پاپ‌شدن نرم */
export function drawPopText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  blur = 16,
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  const s = easeOutBack(p);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(p * 1.6);
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  if (blur > 0) {
    ctx.shadowColor = glow;
    ctx.shadowBlur = blur;
  }
  ctx.fillStyle = fill;
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

/** کارت شیشه‌ای */
export function drawGlassCard(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  accent: string,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.shadowColor = withAlpha(accent, 0.3);
  ctx.shadowBlur = 22;
  drawRoundedRect(ctx, x, y, w, h, 18);
  ctx.fillStyle = 'rgba(7, 11, 26, 0.85)';
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha(accent, 0.56);
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

/** سیلوئت انسان */
export function drawFigure(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  color: string,
  glow = 0,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.fillStyle = color;
  if (glow > 0) {
    ctx.shadowColor = color;
    ctx.shadowBlur = glow;
  }
  ctx.beginPath();
  ctx.arc(0, -46, 13, 0, Math.PI * 2);
  ctx.fill();
  drawRoundedRect(ctx, -15, -30, 30, 58, 12);
  ctx.fill();
  ctx.restore();
}

/** ستاره هشت‌پر */
export function drawStar8(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  rot: number,
  fill = true,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.beginPath();
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI) / 8;
    const rr = i % 2 === 0 ? r : r * 0.54;
    const px = Math.cos(a) * rr;
    const py = Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 16;
    ctx.fill();
  } else {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.6;
    ctx.stroke();
  }
  ctx.restore();
}

/** امواج رادیویی */
export function drawRadioWaves(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  t: number,
  color: string,
  maxR: number,
  dir: 1 | -1 = 1,
  count = 5,
) {
  for (let i = 0; i < count; i++) {
    const ph = (t * 0.55 + i / count) % 1;
    const r = (dir === 1 ? ph : 1 - ph) * maxR;
    ctx.save();
    ctx.globalAlpha *= (1 - ph) * 0.78;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, Math.max(1, r), 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

/** گل رویه‌ای */
export function drawFlower(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  rot: number,
  p: number,
) {
  const s = easeOutBack(clamp01(p));
  if (s <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.fillStyle = withAlpha(color, 0.9);
  ctx.shadowColor = withAlpha(color, 0.6);
  ctx.shadowBlur = 12;
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI / 3);
    ctx.beginPath();
    ctx.ellipse(r * 0.6, 0, r * 0.6, r * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** امواج سیالِ رودخانه و اقیانوس */
export function drawWaterWaves(
  ctx: CanvasRenderingContext2D,
  baseY: number,
  w: number,
  t: number,
  colorA: string,
  colorB: string,
  layers = 4,
  amp = 14,
) {
  for (let l = 0; l < layers; l++) {
    const y0 = baseY + l * 24;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, 720);
    for (let x = 0; x <= w; x += 24) {
      const y =
        y0 +
        Math.sin(x * (0.008 + l * 0.002) - t * (1.8 + l * 0.45) + l * 1.4) * (amp - l * 1.6) +
        Math.cos(x * 0.017 + t * 1.2) * 4;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(w, 720);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, y0 - 20, 0, y0 + 130);
    g.addColorStop(0, withAlpha(l % 2 === 0 ? colorA : colorB, 0.24 - l * 0.035));
    g.addColorStop(1, 'rgba(3, 8, 22, 0.02)');
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = withAlpha(l % 2 === 0 ? colorA : colorB, 0.46 - l * 0.07);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();
  }
}

/** قایق برداری نورانی (با حالت پاروزدن یا دراز کشیدنِ آرام) */
export function drawBoat(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  tilt: number,
  accent: string,
  oarPhase: number,
  reclining: boolean,
  oarFade = 1,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tilt);
  ctx.scale(scale, scale);

  // هاله زیر قایق
  const glow = ctx.createRadialGradient(0, 12, 8, 0, 12, 120);
  glow.addColorStop(0, withAlpha(accent, 0.32));
  glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.ellipse(0, 14, 120, 32, 0, 0, Math.PI * 2);
  ctx.fill();

  // بدنه قایق
  ctx.beginPath();
  ctx.moveTo(-88, -6);
  ctx.quadraticCurveTo(-64, 30, 0, 30);
  ctx.quadraticCurveTo(66, 30, 92, -8);
  ctx.quadraticCurveTo(0, 6, -88, -6);
  ctx.closePath();
  const hullGrad = ctx.createLinearGradient(0, -10, 0, 32);
  hullGrad.addColorStop(0, '#1e293b');
  hullGrad.addColorStop(1, '#090f22');
  ctx.fillStyle = hullGrad;
  ctx.fill();
  ctx.strokeStyle = withAlpha(accent, 0.9);
  ctx.lineWidth = 2.4;
  ctx.stroke();

  // لبه طلایی قایق
  ctx.beginPath();
  ctx.moveTo(-78, -2);
  ctx.quadraticCurveTo(0, 10, 82, -4);
  ctx.strokeStyle = withAlpha('#fde68a', 0.72);
  ctx.lineWidth = 1.6;
  ctx.stroke();

  // سرنشین
  if (reclining) {
    // فرد در حالت درازکشِ آرام و تسلیم
    ctx.fillStyle = '#fde68a';
    ctx.shadowColor = withAlpha(accent, 0.7);
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(34, -14, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fde68a';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(22, -8);
    ctx.quadraticCurveTo(-4, -4, -36, -6);
    ctx.stroke();
    ctx.shadowBlur = 0;
  } else {
    // فرد نشسته در حال تلاش و پاروزدن
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(4, -44, 11, 0, Math.PI * 2);
    ctx.fill();
    drawRoundedRect(ctx, -8, -30, 24, 30, 9);
    ctx.fill();
  }

  // پاروها
  if (oarFade > 0.02) {
    ctx.save();
    ctx.globalAlpha *= oarFade;
    const sweep = Math.sin(oarPhase) * 0.52;
    [-1, 1].forEach((side) => {
      ctx.save();
      ctx.translate(side * 22, -4);
      ctx.rotate(side * (0.45 + sweep * side));
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(side * 48, 36);
      ctx.stroke();
      ctx.fillStyle = withAlpha(accent, 0.85);
      ctx.beginPath();
      ctx.ellipse(side * 52, 40, 13, 5, side * 0.65, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
    ctx.restore();
  }

  ctx.restore();
}

/** قطب‌نمای نورانی درون */
export function drawCompass(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  needleAngle: number,
  accent: string,
  goodMix: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  const ringGrad = ctx.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
  ringGrad.addColorStop(0, 'rgba(12, 20, 42, 0.92)');
  ringGrad.addColorStop(1, 'rgba(6, 10, 24, 0.98)');
  ctx.fillStyle = ringGrad;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();

  const rimColor = goodMix > 0.5 ? '#34d399' : '#f87171';
  ctx.strokeStyle = withAlpha(rimColor, 0.85);
  ctx.shadowColor = withAlpha(rimColor, 0.55);
  ctx.shadowBlur = 22;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // درجه‌بندی
  for (let i = 0; i < 36; i++) {
    const a = (i / 36) * Math.PI * 2;
    const major = i % 3 === 0;
    ctx.strokeStyle = major ? withAlpha(accent, 0.85) : 'rgba(148,163,184,0.32)';
    ctx.lineWidth = major ? 2 : 1;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * (r - (major ? 16 : 9)), Math.sin(a) * (r - (major ? 16 : 9)));
    ctx.lineTo(Math.cos(a) * (r - 3), Math.sin(a) * (r - 3));
    ctx.stroke();
  }

  // ناحیه صراط مستقیم در شمال (بالا)
  ctx.strokeStyle = 'rgba(52, 211, 153, 0.75)';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(0, 0, r - 22, -Math.PI / 2 - 0.25, -Math.PI / 2 + 0.25);
  ctx.stroke();

  // عقربه
  ctx.save();
  ctx.rotate(needleAngle);
  ctx.fillStyle = goodMix > 0.5 ? '#34d399' : '#fb7185';
  ctx.shadowColor = goodMix > 0.5 ? '#34d399' : '#fb7185';
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.72);
  ctx.lineTo(10, 0);
  ctx.lineTo(-10, 0);
  ctx.closePath();
  ctx.fill();

  ctx.shadowBlur = 0;
  ctx.fillStyle = 'rgba(148, 163, 184, 0.6)';
  ctx.beginPath();
  ctx.moveTo(0, r * 0.58);
  ctx.lineTo(8, 0);
  ctx.lineTo(-8, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** لامپ نورانی (تمثیل اتصال به نیروگاه و چراغِ آیات) */
export function drawLightBulb(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  lit: number,
  color = '#fbbf24',
) {
  const k = clamp01(lit);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  if (k > 0.02) {
    const glow = ctx.createRadialGradient(0, -14, 8, 0, -14, 150 * k + 30);
    glow.addColorStop(0, withAlpha(color, 0.65 * k));
    glow.addColorStop(0.45, withAlpha(color, 0.22 * k));
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, -14, 150 * k + 30, 0, Math.PI * 2);
    ctx.fill();
  }

  // حباب شیشه‌ای
  ctx.beginPath();
  ctx.arc(0, -16, 42, Math.PI * 0.78, Math.PI * 2.22);
  ctx.quadraticCurveTo(22, 24, 18, 36);
  ctx.lineTo(-18, 36);
  ctx.quadraticCurveTo(-22, 24, -32, 10);
  ctx.closePath();
  ctx.fillStyle = k > 0.1 ? withAlpha(color, 0.18 + k * 0.52) : 'rgba(15, 23, 42, 0.8)';
  ctx.fill();
  ctx.strokeStyle = k > 0.1 ? withAlpha('#fef08a', 0.55 + k * 0.45) : 'rgba(148, 163, 184, 0.45)';
  ctx.lineWidth = 2.4;
  ctx.stroke();

  // رشته داخل لامپ
  ctx.strokeStyle = k > 0.1 ? '#fef9c3' : '#475569';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(-10, 34);
  ctx.lineTo(-10, -4);
  ctx.lineTo(-4, -14);
  ctx.lineTo(0, -4);
  ctx.lineTo(4, -14);
  ctx.lineTo(10, -4);
  ctx.lineTo(10, 34);
  ctx.stroke();

  // سرپیچ
  drawRoundedRect(ctx, -18, 36, 36, 22, 6);
  ctx.fillStyle = '#334155';
  ctx.fill();
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 1.4;
  ctx.stroke();
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(-16, 42 + i * 6);
    ctx.lineTo(16, 42 + i * 6);
    ctx.stroke();
  }

  // پرتوهای نور
  if (k > 0.25) {
    ctx.strokeStyle = withAlpha('#fde68a', k * 0.78);
    ctx.lineWidth = 2.4;
    ctx.lineCap = 'round';
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI * 1.18 + (i / 9) * Math.PI * 1.36;
      const r1 = 56;
      const r2 = 56 + 24 * k;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r1, -16 + Math.sin(a) * r1);
      ctx.lineTo(Math.cos(a) * r2, -16 + Math.sin(a) * r2);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/** قلب نورانی */
export function drawHeart(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  size: number,
  color: string,
  pulse = 0,
) {
  const s = size * (1 + pulse * 0.08);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.moveTo(0, s * 0.35);
  ctx.bezierCurveTo(-s * 0.9, -s * 0.2, -s * 0.75, -s * 0.95, 0, -s * 0.38);
  ctx.bezierCurveTo(s * 0.75, -s * 0.95, s * 0.9, -s * 0.2, 0, s * 0.35);
  ctx.closePath();
  ctx.fillStyle = withAlpha(color, 0.26);
  ctx.fill();
  ctx.shadowColor = color;
  ctx.shadowBlur = 22;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.6;
  ctx.stroke();
  ctx.restore();
}

/** موج سینوسی فرکانس */
export function drawWaveform(
  ctx: CanvasRenderingContext2D,
  x1: number,
  x2: number,
  cy: number,
  amp: number,
  freq: number,
  phase: number,
  color: string,
  noise = 0,
) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  const steps = 90;
  for (let i = 0; i <= steps; i++) {
    const k = i / steps;
    const x = lerp(x1, x2, k);
    const env = Math.sin(k * Math.PI);
    const j = noise > 0 ? (seeded(i * 13 + Math.floor(phase * 10)) - 0.5) * 2 * noise : 0;
    const y = cy + (Math.sin(k * Math.PI * 2 * freq - phase) * amp + j) * env;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.restore();
}

/** برگ نورانی در حال سقوط آرام */
export function drawLeaf(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  rot: number,
  color: string,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.fillStyle = withAlpha(color, 0.85);
  ctx.shadowColor = withAlpha(color, 0.5);
  ctx.shadowBlur = 12;
  ctx.beginPath();
  ctx.moveTo(0, -size);
  ctx.quadraticCurveTo(size * 0.72, -size * 0.2, 0, size);
  ctx.quadraticCurveTo(-size * 0.72, -size * 0.2, 0, -size);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#fef9c3';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, -size * 0.75);
  ctx.lineTo(0, size * 0.9);
  ctx.stroke();
  ctx.restore();
}
