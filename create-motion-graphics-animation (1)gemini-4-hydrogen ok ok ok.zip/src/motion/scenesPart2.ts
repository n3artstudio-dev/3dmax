/* ------------------------------------------------------------------
   scenesPart2.ts — صحنه‌های المان‌محور فصل ۶ تا ۱۰
------------------------------------------------------------------ */
import {
  clamp01,
  drawAudioAuraRing,
  drawFlowPulse,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawProgressRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import {
  drawFlower,
  drawGlassCard,
  drawHeart,
  drawPopText,
  drawRadioWaves,
  drawStar8,
  drawWipeText,
} from './fx';
import type { SceneFn } from './scenesPart1';

/* ══════════ ۶ — خطواتِ شیطان؛ همنشینیِ پنهان و سپرِ اعراض ══════════ */
export const sceneSatanFootsteps: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'در گام‌های شیطان قدم نگذارید', cx, 128, '800 38px "Vazirmatn", sans-serif', '#fecdd3', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // ۵ پلهٔ سقوط به مدار پایین‌تر
  const steps = [
    { label: 'خشم و پرخاشگری', x: 1030, y: 245 },
    { label: 'عجله و بی‌تابی', x: 855, y: 292 },
    { label: 'مقایسه و برتری‌جویی', x: 675, y: 342 },
    { label: 'غیبت و کلامِ تلخ', x: 495, y: 392 },
    { label: 'نگاه و گوشِ آلوده', x: 315, y: 440 },
  ];

  // نیمهٔ دوم: سپرِ اعراض فعال می‌شود و مسیر را به مدار بالا می‌برد
  const shieldP = easeInOutCubic(clamp01((t - d * 0.56) / 6));

  // خطِ سقوطِ مدار
  ctx.save();
  ctx.strokeStyle = withAlpha(a, 0.45 * (1 - shieldP * 0.55));
  ctx.lineWidth = 3;
  ctx.setLineDash([8, 8]);
  ctx.beginPath();
  steps.forEach((s, i) => {
    if (i === 0) ctx.moveTo(s.x, s.y);
    else ctx.lineTo(s.x, s.y);
  });
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  steps.forEach((s, i) => {
    const sp = easeOutBack(clamp01((t - 2 - i * 4.5) / 1.4));
    if (sp <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = sp * (1 - shieldP * 0.48);
    // ردپای هشدار
    ctx.fillStyle = withAlpha(a, 0.22);
    ctx.strokeStyle = withAlpha(a, 0.85);
    ctx.lineWidth = 1.6;
    drawRoundedRect(ctx, s.x - 102, s.y - 24, 204, 48, 24);
    ctx.fill();
    ctx.stroke();
    drawGlowingText(ctx, s.label, s.x, s.y + 1, '700 17px "Vazirmatn", sans-serif', '#ffe4e6', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });

  // برچسبِ «سقوط به مدارِ پایین‌تر»
  drawPopText(ctx, 'سقوط به مدارِ پایین‌تر ↓', 240, 498, '700 17px "Vazirmatn", sans-serif', '#fb7185', withAlpha(a, 0.5), (t - 24) / 1.5);

  // ریلِ طلاییِ بازگشت و سپرِ اعراض در بالا
  if (shieldP > 0.02) {
    ctx.save();
    ctx.globalAlpha = shieldP;
    const railX2 = lerp(1080, 210, shieldP);
    const rg = ctx.createLinearGradient(1080, 198, 210, 198);
    rg.addColorStop(0, withAlpha('#34d399', 0.25));
    rg.addColorStop(1, withAlpha(b, 0.92));
    ctx.strokeStyle = rg;
    ctx.shadowColor = '#34d399';
    ctx.shadowBlur = 18;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(1080, 198);
    ctx.lineTo(railX2, 198);
    ctx.stroke();
    ctx.restore();

    drawKineticPill(ctx, 415, 200, 'سپرِ اعراض: بازگشت به صراطِ مستقیم', shieldP, '#34d399', '◆', 1.0, 18);
    drawAudioAuraRing(ctx, 210, 198, 30, g, e, '#34d399');
    drawStar8(ctx, 210, 198, 18, b, g * 0.7, true);
  }

  drawVerseCard(
    ctx,
    cx,
    532,
    'وَلَا تَتَّبِعُوا خُطُوَاتِ الشَّيْطَانِ',
    'سوره بقره • آیه ۱۶۸',
    shieldP > 0.4 ? '#34d399' : a,
    (t - 10) / 2.2,
    720,
  );
};

/* ══════════ ۷ — پنج دروازهٔ ورودیِ ذهن و شخصیتِ شکرگزار ══════════ */
export const sceneFiveGatesMind: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 420;
  const cy = 352;

  drawWipeText(ctx, 'پنج دروازهٔ ورودیِ ذهن', 640, 126, '800 38px "Vazirmatn", sans-serif', '#ede9fe', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  const gates = [
    { label: '۱. چشم و نگاه', sub: 'زیبایی‌بینی', y: 202, c: '#38bdf8' },
    { label: '۲. گوش و شنیدار', sub: 'کلامِ آرامش‌بخش', y: 274, c: '#a78bfa' },
    { label: '۳. زبان و گفتار', sub: 'شکر و مهربانی', y: 346, c: '#34d399' },
    { label: '۴. افکارِ گذشته', sub: 'رها از حسرت', y: 418, c: '#fbbf24' },
    { label: '۵. آرزوهای آینده', sub: 'رها از نگرانی', y: 490, c: '#f472b6' },
  ];

  // هستهٔ قلب و شخصیتِ شکرگزار در سمتِ چپ
  drawOrbitRing(ctx, cx, cy, 152, g * 0.28, a, 0.36, true);
  drawOrbitRing(ctx, cx, cy, 108, -g * 0.42, b, 0.3, true);
  drawAudioAuraRing(ctx, cx, cy, 74, g, e, b);
  drawHeart(ctx, cx, cy + 4, 48, '#34d399', e);
  drawGlowingText(ctx, 'شخصیتِ', cx, cy - 8, '800 18px "Vazirmatn", sans-serif', '#fef9c3', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'شکرگزار', cx, cy + 16, '800 19px "Vazirmatn", sans-serif', '#6ee7b7', 'rgba(0,0,0,0)', 0);

  // ۵ دروازه در سمتِ راست که جریان نور را از فیلتر عبور داده و به قلب می‌فرستند
  gates.forEach((gt, i) => {
    const gp = easeOutCubic(clamp01((t - 2 - i * 3.6) / 1.6));
    if (gp <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = gp;
    drawGlassCard(ctx, 845, gt.y - 28, 326, 56, gt.c, 1);
    drawGlowingText(ctx, gt.label, 1148, gt.y - 5, '800 18px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0, 'right');
    drawGlowingText(ctx, gt.sub, 868, gt.y - 3, '600 14px "Vazirmatn", sans-serif', gt.c, 'rgba(0,0,0,0)', 0, 'left');
    // اتصال جریان به فیلتر میانی و قلب
    drawFlowPulse(ctx, 842, gt.y, cx + 115, cy + (i - 2) * 18, g * 1.15 + i * 0.25, gt.c, e);
    ctx.restore();
  });

  // حلقهٔ فیلتر ورودی بین دروازه‌ها و قلب
  const filterP = easeOutCubic(clamp01((t - 10) / 2));
  if (filterP > 0.02) {
    ctx.save();
    ctx.globalAlpha = filterP;
    ctx.strokeStyle = withAlpha('#fbbf24', 0.72);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(680, 195);
    ctx.lineTo(680, 505);
    ctx.stroke();
    drawKineticPill(ctx, 680, 535, 'فیلترِ آرامش و زیبایی', filterP, '#fbbf24', '✦', 0.9, 16);
    ctx.restore();
  }

  // برچسبِ پایینِ قلب
  drawKineticPill(ctx, cx, 535, 'انطباقِ کاملِ ذهن بر روح', (t - 22) / 1.5, '#34d399', '✦', 0.95, 17);
};

/* ══════════ ۸ — لطافتِ نگاه و حرکت از صفر تا یک ══════════ */
export const sceneBeautyMirror: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'لطافتِ نگاه؛ حرکت از صفر به «یک»', cx, 126, '800 38px "Vazirmatn", sans-serif', '#fce7f3', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // نیمهٔ پایین: گل‌های شکوفای لطافت
  const flowers = [
    { x: 150, y: 500, r: 28, c: '#f472b6', d: 2 },
    { x: 265, y: 525, r: 22, c: '#fbbf24', d: 4.5 },
    { x: 390, y: 510, r: 26, c: '#38bdf8', d: 7 },
    { x: 890, y: 512, r: 26, c: '#34d399', d: 9.5 },
    { x: 1015, y: 526, r: 22, c: '#c084fc', d: 12 },
    { x: 1130, y: 500, r: 28, c: '#f472b6', d: 14.5 },
  ];
  flowers.forEach((f, i) => {
    drawFlower(ctx, f.x, f.y, f.r, f.c, g * 0.25 + i, (t - f.d) / 2.2);
  });

  // آینهٔ چشمِ شفاف در مرکز
  const eyeX = cx;
  const eyeY = 296;
  const eyeP = easeOutCubic(clamp01((t - 2) / 2.4));
  ctx.save();
  ctx.globalAlpha = eyeP;
  // قوسِ چشم
  ctx.beginPath();
  ctx.moveTo(eyeX - 188, eyeY);
  ctx.quadraticCurveTo(eyeX, eyeY - 122, eyeX + 188, eyeY);
  ctx.quadraticCurveTo(eyeX, eyeY + 122, eyeX - 188, eyeY);
  ctx.closePath();
  const eyeBg = ctx.createRadialGradient(eyeX, eyeY, 12, eyeX, eyeY, 170);
  eyeBg.addColorStop(0, withAlpha('#38bdf8', 0.34 + e * 0.16));
  eyeBg.addColorStop(0.55, 'rgba(15, 23, 42, 0.85)');
  eyeBg.addColorStop(1, 'rgba(5, 9, 24, 0.96)');
  ctx.fillStyle = eyeBg;
  ctx.fill();
  ctx.strokeStyle = withAlpha(a, 0.88);
  ctx.shadowColor = withAlpha(a, 0.6);
  ctx.shadowBlur = 22;
  ctx.lineWidth = 2.8;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // مردمک آینه‌ای بازتاب‌دهنده ستاره
  drawOrbitRing(ctx, eyeX, eyeY, 64, g * 0.35, b, 0.6, true);
  drawStar8(ctx, eyeX, eyeY, 24 + e * 8, b, -g * 0.4, true);
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath();
  ctx.arc(eyeX - 18, eyeY - 18, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  drawPopText(ctx, 'چشمِ آینه‌ای • دیدنِ زیبایی در کوچک‌ترین مخلوقات', cx, 404, '700 18px "Vazirmatn", sans-serif', '#fde68a', withAlpha(b, 0.45), (t - 7) / 1.5);

  // نوارِ حرکت از صفر (۰) تا یک (۱) با برچسبِ تقوا = مهارِ ذهن
  const prog = easeInOutCubic(clamp01((t - 10) / (d * 0.65)));
  const barX1 = 940;
  const barX2 = 340;
  const barY = 468;

  ctx.save();
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(barX1, barY);
  ctx.lineTo(barX2, barY);
  ctx.stroke();

  const curX = lerp(barX1, barX2, prog);
  const pg = ctx.createLinearGradient(barX1, barY, barX2, barY);
  pg.addColorStop(0, a);
  pg.addColorStop(1, b);
  ctx.strokeStyle = pg;
  ctx.shadowColor = b;
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.moveTo(barX1, barY);
  ctx.lineTo(curX, barY);
  ctx.stroke();
  ctx.restore();

  drawNodeBadge(ctx, barX1 + 32, barY, 22, '۰', '#94a3b8', (t - 9) / 1);
  drawNodeBadge(ctx, barX2 - 32, barY, 24, '۱', b, (t - 9) / 1);
  drawStar8(ctx, curX, barY, 14 + e * 5, '#fef08a', g * 1.2, true);

  drawKineticPill(ctx, cx, 534, 'تقوا = مهارِ افسارِ ذهن و رهایی از چسبندگی', (t - 20) / 1.5, b, '✦', 0.96, 18);
};

/* ══════════ ۹ — رهایی از چسبندگی و مسئولیتِ ۱۰۰٪ خلقِ زندگی ══════════ */
export const sceneReleaseResponsibility: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'تلاش از تو، زمان و چگونگی با خدا', cx, 126, '800 38px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // سمتِ راست: فانوس‌های رهاشده («کِی؟» و «چگونه؟») که آرام به آسمان می‌روند
  const lanterns = [
    { label: 'کِی انجام شود؟', x: 965, baseY: 365, phase: 0, c: a },
    { label: 'چگونه برسد؟', x: 785, baseY: 395, phase: 1.7, c: '#38bdf8' },
  ];
  lanterns.forEach((lt, idx) => {
    const rise = easeOutCubic(clamp01((t - 2 - idx * 2.5) / 8));
    const ly = lt.baseY - rise * 125 + Math.sin(g * 1.6 + lt.phase) * 9;
    const lx = lt.x + Math.cos(g * 1.1 + lt.phase) * 10;
    ctx.save();
    ctx.globalAlpha = clamp01((t - 1.5 - idx * 2) / 1.5);
    const gl = ctx.createRadialGradient(lx, ly, 6, lx, ly, 62);
    gl.addColorStop(0, withAlpha(lt.c, 0.45));
    gl.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gl;
    ctx.beginPath();
    ctx.arc(lx, ly, 62, 0, Math.PI * 2);
    ctx.fill();

    drawRoundedRect(ctx, lx - 56, ly - 32, 112, 64, 22);
    ctx.fillStyle = 'rgba(12, 18, 36, 0.88)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(lt.c, 0.85);
    ctx.lineWidth = 2;
    ctx.stroke();
    drawGlowingText(ctx, lt.label, lx, ly - 4, '800 15px "Vazirmatn", sans-serif', '#fef9c3', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'سپردم به خدا', lx, ly + 17, '600 12px "Vazirmatn", sans-serif', lt.c, 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });

  // چرخ‌دندهٔ تلاشِ آرام در پایینِ سمت راست
  const gearX = 875;
  const gearY = 445;
  ctx.save();
  ctx.translate(gearX, gearY);
  ctx.rotate(g * 0.55);
  ctx.strokeStyle = b;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, 38, 0, Math.PI * 2);
  ctx.stroke();
  for (let i = 0; i < 8; i++) {
    const ang = (i / 8) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(Math.cos(ang) * 38, Math.sin(ang) * 38);
    ctx.lineTo(Math.cos(ang) * 50, Math.sin(ang) * 50);
    ctx.stroke();
  }
  ctx.restore();
  drawGlowingText(ctx, 'تلاشِ سهمِ خود', gearX, gearY + 76, '700 17px "Vazirmatn", sans-serif', '#a7f3d0', 'rgba(0,0,0,0)', 0);

  // سمتِ چپ: کارتِ بزرگِ «مسئولیتِ ۱۰۰٪ خلقِ زندگی»
  const respP = easeOutCubic(clamp01((t - 14) / 2.2));
  if (respP > 0.01) {
    drawGlassCard(ctx, 112, 202, 480, 312, b, respP);
    const pct = clamp01((t - 16) / 6);
    drawProgressRing(ctx, 352, 312, 68, pct, b, 8);
    drawAudioAuraRing(ctx, 352, 312, 46, g, e, a);
    drawGlowingText(ctx, `${toFaDigits(Math.round(pct * 100))}٪`, 352, 310, '900 34px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.5), 14);
    drawGlowingText(ctx, 'مسئولیتِ خلقِ زندگی با خودِ من است', 352, 412, '800 20px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'نه تقصیرِ خانواده، نه جامعه و نه دیگران!', 352, 450, '600 16px "Vazirmatn", sans-serif', '#fda4af', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'پذیرش ← آغازِ تغییر و گشایش', 352, 484, '700 15px "Vazirmatn", sans-serif', '#6ee7b7', 'rgba(0,0,0,0)', 0);
  }
};

/* ══════════ ۱۰ — چهار گامِ آفرینش و مثالِ پشه در قرآن ══════════ */
export const sceneFourStepsMosquito: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'چهار گامِ چرخهٔ خلق در سیستمِ هستی', cx, 126, '800 37px "Vazirmatn", sans-serif', '#e0f2fe', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  const steps = [
    { num: '۱', title: 'تسلیم و پذیرش', sub: 'رها کردن مقاومت', c: '#fbbf24' },
    { num: '۲', title: 'ورودیِ زیبای ذهن', sub: 'شکر و فراوانی', c: '#34d399' },
    { num: '۳', title: 'ارسالِ فرکانس', sub: 'ارتعاش به هستی', c: '#38bdf8' },
    { num: '۴', title: 'پردازشِ جهان', sub: 'بازتابِ هم‌فرکانس', c: '#c084fc' },
  ];

  const yRow = 236;
  steps.forEach((st, i) => {
    const sx = 1045 - i * 270;
    const sp = easeOutBack(clamp01((t - 2 - i * 3.2) / 1.4));
    if (sp <= 0.01) return;
    if (i < steps.length - 1) {
      drawFlowPulse(ctx, sx - 108, yRow, sx - 162, yRow, g * 1.4 + i * 0.4, st.c, e);
    }
    drawGlassCard(ctx, sx - 108, yRow - 56, 216, 112, st.c, sp);
    drawNodeBadge(ctx, sx, yRow - 56, 21, st.num, st.c, sp);
    drawGlowingText(ctx, st.title, sx, yRow - 4, '800 18px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, st.sub, sx, yRow + 26, '500 14px "Vazirmatn", sans-serif', st.c, 'rgba(0,0,0,0)', 0);
  });

  // بخش پایین: امواج فرکانس + المانِ ظریفِ مثالِ پشه و زبانِ ملموسِ قرآن
  const mosqP = easeOutCubic(clamp01((t - 18) / 2.2));
  if (mosqP > 0.01) {
    drawGlassCard(ctx, 170, 326, 940, 146, b, mosqP);
    drawRadioWaves(ctx, 315, 399, g, a, 62, 1, 4);

    // طرحِ هندسیِ ظریفِ بال‌های پشه با درخشش طلایی
    ctx.save();
    ctx.translate(315, 399);
    ctx.globalAlpha = mosqP;
    const flap = Math.sin(g * 14) * 0.22;
    ctx.strokeStyle = '#fde68a';
    ctx.fillStyle = withAlpha('#38bdf8', 0.22);
    ctx.lineWidth = 2;
    [-1, 1].forEach((side) => {
      ctx.save();
      ctx.rotate(side * (0.48 + flap));
      ctx.beginPath();
      ctx.ellipse(side * 26, -12, 28, 10, side * -0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    });
    ctx.strokeStyle = '#fde68a';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, -14);
    ctx.lineTo(0, 22);
    ctx.stroke();
    ctx.restore();

    drawGlowingText(ctx, 'مثالِ پشه در قرآن و زبانِ ملموسِ نشانه‌ها', 755, 362, '800 21px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.4), 10);
    drawGlowingText(ctx, 'از کوچک‌ترین نشانه تا نخل و زیتون و انار — جهان با زبانِ ملموسِ تو سخن می‌گوید', 755, 400, '500 15.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'إِنَّ اللَّهَ لَا يَسْتَحْيِي أَن يَضْرِبَ مَثَلًا مَّا بَعُوضَةً', 755, 440, '700 24px "Amiri", serif', '#c084fc', withAlpha(b, 0.4), 10);
  }

  drawKineticPill(ctx, cx, 530, 'هر فرکانسی که می‌فرستی، دقیقاً هم‌جنسِ خودش بازمی‌گردد', (t - 11) / 1.8, a, '✦', 0.98, 18);
};
