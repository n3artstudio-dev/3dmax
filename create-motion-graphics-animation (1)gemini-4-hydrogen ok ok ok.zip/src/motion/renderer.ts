/* ------------------------------------------------------------------
   renderer.ts — موتورِ اصلیِ رندرِ فریم‌های موشن گرافیک «جریانِ نور»
------------------------------------------------------------------ */
import {
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  drawSacredMandala,
  drawSpectrumBars,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  lerpColor,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import {
  sceneAbundanceOrbit,
  sceneHorseCompass,
  sceneMindSoulAlign,
  sceneSurrenderOcean,
  sceneTwoPathsBoat,
  type SceneFn,
} from './scenesPart1';
import {
  sceneBeautyMirror,
  sceneFiveGatesMind,
  sceneFourStepsMosquito,
  sceneReleaseResponsibility,
  sceneSatanFootsteps,
} from './scenesPart2';
import {
  sceneAyatLampsFinale,
  sceneDailySignsGuidance,
  sceneExactLawCosmos,
  sceneLampPowerplant,
  sceneReturnNudges,
} from './scenesPart3';
import {
  sceneCutNegativeMomentum,
  sceneFrequencyTransmitter,
  sceneLightVsDarkness,
  sceneRadioWaveQuran,
  sceneSulaymanKingdom,
  sceneTawbahReset,
  sceneWalkOnWaterFinale,
} from './scenesPart4';
import {
  getCaptionAt,
  getChapterAt,
  getChaptersForMode,
  getDurationForMode,
  type EditionMode,
  type MotionChapter,
  type SceneKey,
} from './timeline';

const VW = 1280;
const VH = 720;

const SCENES: Record<SceneKey, SceneFn> = {
  two_paths_boat: sceneTwoPathsBoat,
  surrender_ocean: sceneSurrenderOcean,
  mind_soul_align: sceneMindSoulAlign,
  abundance_orbit: sceneAbundanceOrbit,
  horse_compass: sceneHorseCompass,
  satan_footsteps: sceneSatanFootsteps,
  five_gates_mind: sceneFiveGatesMind,
  beauty_mirror: sceneBeautyMirror,
  release_responsibility: sceneReleaseResponsibility,
  four_steps_mosquito: sceneFourStepsMosquito,
  exact_law_cosmos: sceneExactLawCosmos,
  lamp_powerplant: sceneLampPowerplant,
  daily_signs_guidance: sceneDailySignsGuidance,
  return_nudges: sceneReturnNudges,
  ayat_lamps_finale: sceneAyatLampsFinale,
  light_vs_darkness: sceneLightVsDarkness,
  cut_negative_momentum: sceneCutNegativeMomentum,
  tawbah_reset: sceneTawbahReset,
  frequency_transmitter: sceneFrequencyTransmitter,
  sulayman_kingdom: sceneSulaymanKingdom,
  radio_wave_quran: sceneRadioWaveQuran,
  walk_on_water_finale: sceneWalkOnWaterFinale,
};

export interface RenderOptions {
  mode: EditionMode;
  showSubtitles: boolean;
  showHud: boolean;
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, max: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width <= max) cur = test;
    else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

export function drawMotionFrame(
  ctx: CanvasRenderingContext2D,
  t: number,
  pw: number,
  ph: number,
  energy: number,
  opts: RenderOptions,
) {
  const chapters = getChaptersForMode(opts.mode);
  const totalDur = getDurationForMode(opts.mode);
  const ch = getChapterAt(t, opts.mode);
  const idx = chapters.findIndex((c) => c.id === ch.id);
  const next = chapters[Math.min(chapters.length - 1, idx + 1)];
  const toEnd = ch.end - t;
  const blend = toEnd < 2 && next.id !== ch.id ? easeInOutCubic(1 - toEnd / 2) : 0;
  const accent = blend > 0.5 ? next.accent : ch.accent;
  const accent2 = blend > 0.5 ? next.accentSecondary : ch.accentSecondary;

  ctx.save();
  ctx.scale(pw / VW, ph / VH);
  if ('direction' in ctx) ctx.direction = 'rtl';

  // پس‌زمینهٔ گرادیانیِ پویا
  const bg = ctx.createLinearGradient(0, 0, 0, VH);
  bg.addColorStop(0, lerpColor(ch.bgTop, next.bgTop, blend));
  bg.addColorStop(1, lerpColor(ch.bgBottom, next.bgBottom, blend));
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, VW, VH);

  const rad = ctx.createRadialGradient(640, 340, 40, 640, 340, 780);
  rad.addColorStop(0, withAlpha(accent, 0.12 + energy * 0.1));
  rad.addColorStop(1, 'rgba(3, 6, 18, 0.68)');
  ctx.fillStyle = rad;
  ctx.fillRect(0, 0, VW, VH);

  // ماندالای هندسی و ذرات کیهانی
  drawSacredMandala(ctx, 640, 352, 320, t * 0.032, accent, 0.062);
  drawSacredMandala(ctx, 640, 352, 210, -t * 0.048, accent2, 0.052);
  drawCosmicParticles(ctx, VW, VH, t, accent, energy);

  // صحنهٔ اختصاصی فصل
  const local = Math.max(0, t - ch.start);
  const fadeIn = clamp01(local / 0.8);
  const fadeOut = toEnd < 0.7 && next.id !== ch.id ? clamp01(toEnd / 0.7) : 1;
  ctx.save();
  ctx.globalAlpha = Math.min(fadeIn, fadeOut);
  SCENES[ch.sceneKey](ctx, local, ch.end - ch.start, t, energy, ch.accent, ch.accentSecondary);
  ctx.restore();

  // فلشِ انتقال فصل
  if (local < 0.55 && idx > 0) {
    ctx.save();
    ctx.globalAlpha = (1 - local / 0.55) * 0.3;
    ctx.fillStyle = ch.accent;
    ctx.fillRect(0, 0, VW, VH);
    ctx.restore();
  }

  // وینیت سینمایی
  const vig = ctx.createRadialGradient(640, 360, 260, 640, 360, 820);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(2, 4, 12, 0.72)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, VW, VH);

  // کارتِ آغازین (۴ ثانیه اول)
  if (t < 4.2) {
    const al = t < 3.1 ? 1 : 1 - clamp01((t - 3.1) / 1.1);
    const pop = easeOutBack(clamp01(t / 0.85));
    ctx.save();
    ctx.globalAlpha = al;
    ctx.fillStyle = 'rgba(4, 7, 18, 0.96)';
    ctx.fillRect(0, 0, VW, VH);
    ctx.translate(640, 336);
    ctx.scale(pop, pop);
    drawSacredMandala(ctx, 0, 0, 224, t * 0.45, '#fbbf24', 0.22);
    drawSacredMandala(ctx, 0, 0, 148, -t * 0.35, '#38bdf8', 0.16);
    drawGlowingText(ctx, 'جریانِ نور', 0, -56, '900 84px "Vazirmatn", sans-serif', '#fde68a', 'rgba(251,191,36,0.72)', 34);
    drawGlowingText(ctx, 'صراطِ مستقیم، تسلیم و هم‌جهت‌شدن با خداوند', 0, 26, '700 26px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(56,189,248,0.45)', 14);
    drawGlowingText(
      ctx,
      opts.mode === '15min'
        ? 'موشن گرافیکِ المان‌محور • ۱۵ فصل • ۱۵:۰۰'
        : 'موشن گرافیکِ المان‌محور • ۲۲ فصلِ کامل • ۲۸:۳۵',
      0,
      74,
      '500 18px "Vazirmatn", sans-serif',
      '#94a3b8',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  // تیتراژِ پایانی
  const outroLen = opts.mode === '15min' ? 7.5 : 10;
  if (t > totalDur - outroLen) {
    const cp = easeOutCubic(clamp01((t - (totalDur - outroLen)) / 2.2));
    ctx.save();
    ctx.globalAlpha = cp * 0.98;
    ctx.fillStyle = 'rgba(4, 8, 18, 0.97)';
    ctx.fillRect(0, 0, VW, VH);
    drawSacredMandala(ctx, 640, 304, 232, t * 0.14, '#fbbf24', 0.24);
    drawSacredMandala(ctx, 640, 304, 154, -t * 0.22, '#34d399', 0.2);
    drawGlowingText(
      ctx,
      'تسلیم ← هم‌جهتی با نور ← هدایت',
      640,
      248,
      '900 46px "Vazirmatn", sans-serif',
      '#fde68a',
      'rgba(251,191,36,0.65)',
      26,
    );
    drawGlowingText(
      ctx,
      'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ ۝ يَهْدِي اللَّهُ لِنُورِهِ مَن يَشَاءُ',
      640,
      328,
      '700 34px "Amiri", serif',
      '#bbf7d0',
      'rgba(52,211,153,0.52)',
      18,
    );
    drawGlowingText(
      ctx,
      'پنج گامِ زنده: تسلیم • ورودیِ زیبای ذهن • ارسالِ فرکانس • سیستمِ قانونمندِ جهان • هدایت',
      640,
      400,
      '600 19px "Vazirmatn", sans-serif',
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  // HUD بالایی و نوارِ پیشرفتِ فصل‌ها
  if (opts.showHud) {
    const top = ctx.createLinearGradient(0, 0, 0, 84);
    top.addColorStop(0, 'rgba(4, 7, 18, 0.84)');
    top.addColorStop(1, 'rgba(4, 7, 18, 0)');
    ctx.fillStyle = top;
    ctx.fillRect(0, 0, VW, 84);

    // کپسول عنوانِ فصل در بالا-راست
    ctx.save();
    ctx.font = '700 16px "Vazirmatn", sans-serif';
    const label = `فصل ${toFaDigits(ch.id)}  •  ${ch.title}`;
    const bw = Math.min(660, ctx.measureText(label).width + 52);
    drawRoundedRect(ctx, VW - bw - 32, 20, bw, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.82)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(ch.accent, 0.65);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.fillStyle = ch.accent;
    ctx.beginPath();
    ctx.arc(VW - 50, 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f1f5f9';
    ctx.fillText(label, VW - 66, 41);
    ctx.restore();

    // کپسول زمان در بالا-چپ
    ctx.save();
    drawRoundedRect(ctx, 32, 20, 178, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.82)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.34)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = '700 15px "Vazirmatn", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(t)} / ${formatTimeFa(totalDur)}`, 121, 41);
    ctx.restore();

    // طیف صوتیِ ظریف
    drawSpectrumBars(ctx, 325, 60, 24, 180, t, energy, ch.accent, 0.52);

    // نوارِ پیشرفتِ RTL در لبهٔ بالایی
    const pct = clamp01(t / totalDur);
    ctx.fillStyle = 'rgba(255,255,255,0.09)';
    ctx.fillRect(0, 0, VW, 5);
    const bar = ctx.createLinearGradient(VW, 0, 0, 0);
    bar.addColorStop(0, ch.accent);
    bar.addColorStop(1, ch.accentSecondary);
    ctx.fillStyle = bar;
    ctx.fillRect(VW * (1 - pct), 0, VW * pct, 5);
    chapters.forEach((c) => {
      ctx.fillStyle = 'rgba(2, 6, 16, 0.85)';
      ctx.fillRect(VW * (1 - c.start / totalDur) - 1, 0, 2, 5);
    });

    ctx.font = '600 13px "Vazirmatn", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(203, 213, 225, 0.78)';
    ctx.fillText(`فصل ${toFaDigits(ch.id)} از ${toFaDigits(chapters.length)}`, 32, 76);
  }

  // زیرنویسِ همگامِ فارسی در پایینِ تصویر
  if (opts.showSubtitles && t >= 4 && t <= totalDur - outroLen + 1) {
    const cue = getCaptionAt(t, opts.mode);
    if (cue) {
      const cp = clamp01((t - cue.start) / 0.42);
      ctx.save();
      ctx.globalAlpha = easeOutCubic(cp);
      ctx.translate(0, (1 - easeOutCubic(cp)) * 16);
      ctx.font = '600 22px "Vazirmatn", sans-serif';
      const lines = wrapLines(ctx, cue.text, 940);
      const boxH = lines.length === 2 ? 80 : 52;
      const boxY = VH - boxH - 22;
      const boxW = Math.min(1060, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 76);
      const boxX = (VW - boxW) / 2;
      drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 18);
      ctx.fillStyle = 'rgba(5, 9, 22, 0.88)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(ch.accent, 0.52);
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = ch.accent;
      ctx.fillRect(boxX + boxW - 4, boxY + 12, 4, boxH - 24);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.65)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = cue.highlight ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      else {
        ctx.fillText(lines[0], 640, boxY + 24);
        ctx.fillText(lines[1], 640, boxY + 56);
      }
      ctx.restore();
    }
  }
  ctx.restore();
}

export function drawChapterThumb(
  ctx: CanvasRenderingContext2D,
  ch: MotionChapter,
  mode: EditionMode,
  w: number,
  h: number,
) {
  ctx.clearRect(0, 0, w, h);
  const sampleT = Math.max(4.5, ch.start + (ch.end - ch.start) * 0.58);
  drawMotionFrame(ctx, sampleT, w, h, 0.28, {
    mode,
    showSubtitles: false,
    showHud: false,
  });
}
