/* ------------------------------------------------------------------
   scenesPart3.ts — صحنه‌های المان‌محور فصل ۱۱ تا ۱۵ (اوج و جمع‌بندی ۱۵ دقیقه)
------------------------------------------------------------------ */
import {
  clamp01,
  drawAudioAuraRing,
  drawFlowPulse,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  withAlpha,
} from './drawPrimitives';
import {
  drawFigure,
  drawGlassCard,
  drawLeaf,
  drawLightBulb,
  drawPopText,
  drawStar8,
  drawWaveform,
  drawWipeText,
} from './fx';
import type { SceneFn } from './scenesPart1';

/* ══════════ ۱۱ — قانونمندیِ دقیق و تسخیرِ جهانِ آفرینش ══════════ */
export const sceneExactLawCosmos: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  const cy = 338;
  drawWipeText(ctx, 'قانونمندیِ دقیق و تسخیرِ جهان', cx, 124, '800 38px "Vazirmatn", sans-serif', '#d1fae5', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // اسطرلاب دقیق کیهانی حول انسان موحد
  drawOrbitRing(ctx, cx, cy, 195, g * 0.2, a, 0.35, true);
  drawOrbitRing(ctx, cx, cy, 145, -g * 0.34, b, 0.42, true);
  drawOrbitRing(ctx, cx, cy, 94, g * 0.52, '#fbbf24', 0.48, true);
  drawAudioAuraRing(ctx, cx, cy, 66, g, e, a);

  // انسان موحد در مرکز
  drawFigure(ctx, cx, cy + 16, 1.05, '#fde68a', 20);

  // ۴ گره کیهانیِ مسخرِ انسان که پرتوها را به سمت مرکز می‌فرستند
  const cosmosNodes = [
    { label: 'ابر و باد', ang: -Math.PI * 0.22, c: '#38bdf8' },
    { label: 'خورشید و فلک', ang: -Math.PI * 0.78, c: '#fbbf24' },
    { label: 'ثروت و نعمت', ang: Math.PI * 0.78, c: '#34d399' },
    { label: 'تخلف‌ناپذیر', ang: Math.PI * 0.22, c: '#c084fc' },
  ];
  cosmosNodes.forEach((n, i) => {
    const nx = cx + Math.cos(n.ang) * 330;
    const ny = cy + Math.sin(n.ang) * 142;
    drawFlowPulse(ctx, nx, ny, cx, cy, g * 1.1 + i * 0.25, n.c, e);
    drawKineticPill(ctx, nx, ny, n.label, (t - 3 - i * 3) / 1.4, n.c, '✦', 0.94, 17);
  });

  // کارت سنجشِ دقت در سمت چپ و راست
  const meterP = easeOutCubic(clamp01((t - 8) / 2));
  if (meterP > 0.01) {
    drawGlassCard(ctx, 52, 290, 212, 100, a, meterP);
    drawGlowingText(ctx, '۰.۰۰۰', 158, 326, '900 32px "Vazirmatn", sans-serif', '#6ee7b7', withAlpha(a, 0.5), 14);
    drawGlowingText(ctx, 'یک میلی‌متر خطا ندارد!', 158, 366, '700 14px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);

    drawGlassCard(ctx, 1016, 290, 212, 100, '#fbbf24', meterP);
    drawGlowingText(ctx, 'توحید', 1122, 326, '900 28px "Vazirmatn", sans-serif', '#fde68a', withAlpha('#fbbf24', 0.5), 14);
    drawGlowingText(ctx, 'جهان خدمتگزارِ توست', 1122, 366, '700 14px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  }

  drawVerseCard(
    ctx,
    cx,
    532,
    'وَسَخَّرَ لَكُم مَّا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ',
    'سوره جاثیه • آیه ۱۳',
    a,
    (t - 16) / 2.2,
    780,
  );
};

/* ══════════ ۱۲ — توحیدِ زنده؛ تمثیلِ لامپ، نیروگاه و کلیدِ هدایت ══════════ */
export const sceneLampPowerplant: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'اتصالِ زنده به منبع؛ تمثیلِ نیروگاه و لامپ', cx, 126, '800 37px "Vazirmatn", sans-serif', '#fef08a', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  // زمانِ زدنِ کلید هدایت و روشن شدن لامپ
  const switchOn = easeInOutCubic(clamp01((t - d * 0.36) / 3.2));
  const lampLit = clamp01(switchOn * (0.85 + e * 0.28));

  // راست: نیروگاهِ بی‌کرانِ الهی
  const plantX = 1040;
  const plantY = 336;
  drawAudioAuraRing(ctx, plantX, plantY, 82, g, e, b);
  drawGlassCard(ctx, plantX - 102, plantY - 94, 204, 188, b, 1);
  drawStar8(ctx, plantX, plantY - 22, 36 + e * 10, a, g * 0.6, true);
  drawGlowingText(ctx, 'نیروگاهِ الهی', plantX, plantY + 42, '800 21px "Vazirmatn", sans-serif', '#fde68a', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, 'منبعِ بی‌نهایتِ نور', plantX, plantY + 72, '500 14px "Vazirmatn", sans-serif', '#bae6fd', 'rgba(0,0,0,0)', 0);

  // خطِ سیم و جریانِ برق از نیروگاه به کلید (وسط) و به لامپ (چپ)
  const swX = 640;
  const swY = 336;
  const bulbX = 250;
  const bulbY = 336;

  // سیم راست (همیشه برق دارد)
  drawWaveform(ctx, plantX - 102, swX + 68, swY, 12 + e * 10, 4, g * 7, b, 0);
  drawFlowPulse(ctx, plantX - 102, swY, swX + 68, swY, g * 1.6, a, e);

  // کلید هدایت در وسط
  drawGlassCard(ctx, swX - 72, swY - 58, 144, 116, switchOn > 0.5 ? '#34d399' : '#94a3b8', 1);
  // اهرم کلید
  ctx.save();
  ctx.translate(swX, swY - 12);
  drawRoundedRect(ctx, -38, -16, 76, 32, 16);
  ctx.fillStyle = switchOn > 0.5 ? 'rgba(52, 211, 153, 0.35)' : 'rgba(51, 65, 85, 0.7)';
  ctx.fill();
  ctx.strokeStyle = switchOn > 0.5 ? '#34d399' : '#94a3b8';
  ctx.lineWidth = 2;
  ctx.stroke();
  const knobX = lerp(20, -20, switchOn);
  ctx.fillStyle = switchOn > 0.5 ? '#fef08a' : '#cbd5e1';
  ctx.beginPath();
  ctx.arc(knobX, 0, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(ctx, 'کلیدِ هدایت', swX, swY + 26, '800 17px "Vazirmatn", sans-serif', switchOn > 0.5 ? '#6ee7b7' : '#cbd5e1', 'rgba(0,0,0,0)', 0);
  drawGlowingText(ctx, switchOn > 0.5 ? 'وصل شد • گام ۵' : 'آمادهٔ اتصال', swX, swY + 46, '600 12px "Vazirmatn", sans-serif', a, 'rgba(0,0,0,0)', 0);

  // سیم چپ (پس از وصل کلید، موج طلایی جاری می‌شود)
  if (switchOn > 0.05) {
    ctx.save();
    ctx.globalAlpha = switchOn;
    drawWaveform(ctx, swX - 72, bulbX + 64, swY, 13 + e * 12, 4, g * 8.5, a, 0);
    drawFlowPulse(ctx, swX - 72, swY, bulbX + 64, swY, g * 1.9, a, e);
    ctx.restore();
  } else {
    ctx.strokeStyle = 'rgba(148,163,184,0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(swX - 72, swY);
    ctx.lineTo(bulbX + 64, swY);
    ctx.stroke();
  }

  // چپ: لامپِ نورانی (وجودِ انسانِ متصل به خدا)
  drawLightBulb(ctx, bulbX, bulbY, 1.38, lampLit, a);
  drawGlowingText(
    ctx,
    lampLit > 0.4 ? 'روشن با نورِ خدا' : 'لامپِ منتظرِ اتصال',
    bulbX,
    bulbY + 116,
    '800 19px "Vazirmatn", sans-serif',
    lampLit > 0.4 ? '#fde68a' : '#94a3b8',
    withAlpha(a, 0.5),
    12,
  );

  drawVerseCard(
    ctx,
    cx,
    532,
    'إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ',
    'ما با خداوند یکی هستیم • گامِ پنجم: هدایت',
    a,
    (t - 8) / 2,
    760,
  );
};

/* ══════════ ۱۳ — دو جاده و نشانه‌های ریزِ هدایت در زندگی روزمره ══════════ */
export const sceneDailySignsGuidance: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'نشانه‌های زندهٔ هدایت در لحظه‌به‌لحظهٔ زندگی', cx, 124, '800 36px "Vazirmatn", sans-serif', '#dcfce7', withAlpha(a, 0.6), (t - 0.6) / 1.8);

  // نوار دو جاده در بالای کارت‌ها
  drawKineticPill(ctx, 860, 192, 'مسیرِ حق • صراطِ مستقیم • گشایش', (t - 2) / 1.3, a, '✦', 0.96, 17);
  drawKineticPill(ctx, 405, 192, 'مسیرِ باطل • غیرمستقیم • سختی', (t - 4) / 1.3, '#fb7185', '✕', 0.92, 16);

  // سه کارتِ انیمیشنی از مثال‌های واقعیِ سخنران
  const cardW = 340;
  const cardH = 248;
  const cardY = 244;

  // کارت ۱ (راست): برگِ درختی که جلوی پایت می‌افتد
  const p1 = easeOutBack(clamp01((t - 7) / 1.6));
  if (p1 > 0.01) {
    const x1 = 875;
    drawGlassCard(ctx, x1, cardY, cardW, cardH, a, p1);
    const lx = x1 + 170 + Math.sin(g * 2.2) * 44;
    const ly = cardY + 52 + ((g * 36) % 92);
    drawLeaf(ctx, lx, ly, 24, Math.sin(g * 2.2) * 0.7, a);
    drawGlowingText(ctx, 'افتادنِ یک برگ', x1 + 170, cardY + 180, '800 21px "Vazirmatn", sans-serif', '#bbf7d0', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'هیچ حرکتی در جهان بی‌حکمت نیست', x1 + 170, cardY + 216, '500 14.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  }

  // کارت ۲ (وسط): جای پارکِ پر که دقیقاً برایت باز می‌شود!
  const p2 = easeOutBack(clamp01((t - 15) / 1.6));
  if (p2 > 0.01) {
    const x2 = 470;
    drawGlassCard(ctx, x2, cardY, cardW, cardH, b, p2);
    // ترسیم پارکینگ + خودروی طلایی در حال ورود به جای بازشده
    const bayX = x2 + 95;
    const bayY = cardY + 46;
    ctx.save();
    ctx.strokeStyle = withAlpha(b, 0.75);
    ctx.lineWidth = 2.4;
    ctx.strokeRect(bayX, bayY, 150, 86);
    drawGlowingText(ctx, 'P', bayX + 75, bayY + 43, '800 28px "Vazirmatn", sans-serif', withAlpha(b, 0.35), 'rgba(0,0,0,0)', 0);
    const carSlide = easeInOutCubic((Math.sin(g * 0.9) + 1) * 0.5);
    const carX = lerp(bayX + 120, bayX + 26, carSlide);
    drawRoundedRect(ctx, carX, bayY + 22, 96, 42, 12);
    ctx.fillStyle = withAlpha(a, 0.85);
    ctx.shadowColor = a;
    ctx.shadowBlur = 14 + e * 10;
    ctx.fill();
    ctx.shadowBlur = 0;
    // چراغ خودرو
    ctx.fillStyle = '#fef9c3';
    ctx.fillRect(carX + 4, bayY + 28, 6, 10);
    ctx.fillRect(carX + 4, bayY + 48, 6, 10);
    ctx.restore();

    drawGlowingText(ctx, 'بازشدنِ جای پارک', x2 + 170, cardY + 180, '800 21px "Vazirmatn", sans-serif', '#fde68a', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'درست همان لحظه راهت باز می‌شود!', x2 + 170, cardY + 216, '500 14.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  }

  // کارت ۳ (چپ): لحظهٔ روشن‌شدنِ لامپِ حرفِ حق
  const p3 = easeOutBack(clamp01((t - 23) / 1.6));
  if (p3 > 0.01) {
    const x3 = 65;
    drawGlassCard(ctx, x3, cardY, cardW, cardH, '#38bdf8', p3);
    drawLightBulb(ctx, x3 + 170, cardY + 86, 0.78, 0.72 + Math.sin(g * 3) * 0.22, '#38bdf8');
    drawGlowingText(ctx, 'شنیدنِ کلامِ حق', x3 + 170, cardY + 180, '800 21px "Vazirmatn", sans-serif', '#bae6fd', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, 'تأیید و تدبیرِ لحظه‌به‌لحظهٔ خدا', x3 + 170, cardY + 216, '500 14.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
  }

  drawPopText(ctx, 'وقتی در صراطِ مستقیمی، تمامِ جهان برایت نشانه می‌فرستد', cx, 536, '700 20px "Vazirmatn", sans-serif', '#fde68a', withAlpha(b, 0.45), (t - 12) / 1.6);
};

/* ══════════ ۱۴ — فَارْجِعْ؛ تلنگرهای پلکانیِ بازگشت به صراط ══════════ */
export const sceneReturnNudges: SceneFn = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'فَارْجِعْ؛ با اولین نشانه برگرد به صراط!', cx, 124, '800 38px "Vazirmatn", sans-serif', '#fed7aa', withAlpha(a, 0.65), (t - 0.6) / 1.8);

  // ۴ سطح پلکانیِ هشدار الهی با فاصلهٔ کاملاً پاک از کارتِ آیه
  const levels = [
    { n: '۱', title: 'اشارهٔ کوچک', sub: 'بسته‌شدنِ خفیفِ دل‌ها', c: '#fde047', h: 56 },
    { n: '۲', title: 'پس‌گردنیِ ملایم', sub: 'مانعِ ساده در کار روزمره', c: '#fb923c', h: 90 },
    { n: '۳', title: 'ضربهٔ محکم', sub: 'هشدارِ جدی‌تر برای بیداری', c: '#f97316', h: 124 },
    { n: '۴', title: 'صخره و چکش', sub: 'توقفِ کامل برای بازگشت', c: '#ef4444', h: 158 },
  ];

  const baseY = 392;
  levels.forEach((lv, i) => {
    const x = 1015 - i * 248;
    const lp = easeOutBack(clamp01((t - 2 - i * 4.5) / 1.5));
    if (lp <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = lp;
    const barH = lv.h * lp;
    const grad = ctx.createLinearGradient(x, baseY, x, baseY - barH);
    grad.addColorStop(0, withAlpha(lv.c, 0.16));
    grad.addColorStop(1, withAlpha(lv.c, 0.72));
    drawRoundedRect(ctx, x - 84, baseY - barH, 168, barH, 16);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.strokeStyle = lv.c;
    ctx.lineWidth = 2;
    ctx.stroke();

    drawNodeBadge(ctx, x, baseY - barH, 19, lv.n, lv.c, lp);
    drawGlowingText(ctx, lv.title, x, baseY + 24, '800 18px "Vazirmatn", sans-serif', '#f8fafc', 'rgba(0,0,0,0)', 0);
    drawGlowingText(ctx, lv.sub, x, baseY + 48, '500 13.5px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });

  // قوسِ طلایی-زمردیِ دوربرگردانِ هوشمند از اشارهٔ ۱ به صراط مستقیم!
  const uTurn = easeInOutCubic(clamp01((t - d * 0.5) / 4.5));
  if (uTurn > 0.02) {
    ctx.save();
    ctx.globalAlpha = uTurn;
    ctx.strokeStyle = b;
    ctx.shadowColor = b;
    ctx.shadowBlur = 20;
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(1015, 314);
    ctx.bezierCurveTo(1015, 174, 700, 174, lerp(1015, 340, uTurn), 186);
    ctx.stroke();

    if (uTurn > 0.85) {
      ctx.fillStyle = b;
      ctx.beginPath();
      ctx.moveTo(324, 186);
      ctx.lineTo(352, 174);
      ctx.lineTo(352, 198);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    drawAudioAuraRing(ctx, 1015, 340, 38, g, e, b);
    drawKineticPill(ctx, 640, 184, 'هوشمندانه با اولین اشاره برگرد: فَارْجِعْ!', uTurn, b, '↩', 1.0, 18);
  }

  drawVerseCard(ctx, cx, 536, 'لَعَلَّهُمْ يَرْجِعُونَ', 'سوره روم • آیه ۴۱ — بازگشت به صراطِ مستقیم', b, (t - 18) / 2, 700);
};

/* ══════════ ۱۵ — نورِ آیات؛ چراغِ راه در تاریکی (پایانِ بخش ۱۵ دقیقه) ══════════ */
export const sceneAyatLampsFinale: SceneFn = (ctx, t, _d, g, e, a, b) => {
  const cx = 640;
  drawWipeText(ctx, 'آیاتِ قرآن؛ چراغ‌های روشنِ مسیرِ نور', cx, 126, '800 38px "Vazirmatn", sans-serif', '#fef08a', withAlpha(a, 0.7), (t - 0.5) / 1.6);

  // ردیف ۵ چراغِ نورانیِ هدایت در جادهٔ مؤمنین (روشن می‌شوند یکی‌یکی از راست به چپ)
  const lamps = 5;
  for (let i = 0; i < lamps; i++) {
    const lx = 1040 - i * 200;
    const ly = 290;
    const lit = easeOutCubic(clamp01((t - 1.5 - i * 2.1) / 2.2));
    // ستون نور زیر هر چراغ
    if (lit > 0.05) {
      const cone = ctx.createLinearGradient(lx, ly + 20, lx, 470);
      cone.addColorStop(0, withAlpha(a, 0.32 * lit));
      cone.addColorStop(1, 'rgba(251, 191, 36, 0)');
      ctx.fillStyle = cone;
      ctx.beginPath();
      ctx.moveTo(lx - 22, ly + 24);
      ctx.lineTo(lx + 22, ly + 24);
      ctx.lineTo(lx + 78, 472);
      ctx.lineTo(lx - 78, 472);
      ctx.closePath();
      ctx.fill();
    }
    drawLightBulb(ctx, lx, ly, 0.92, lit * (0.85 + e * 0.25), i % 2 === 0 ? a : b);
  }

  // مقایسهٔ دو نوار پایین: نورِ مؤمنین در برابر خاموشیِ هشدار در راه غیرمستقیم
  drawKineticPill(ctx, 880, 444, 'برای مؤمنین: آیات چون نورِ روشنِ راه', (t - 6) / 1.4, a, '✦', 0.96, 17);
  drawKineticPill(ctx, 370, 444, 'در مسیرِ غیرمستقیم: خاموشیِ چراغ برای بیداری', (t - 11) / 1.4, '#94a3b8', '◐', 0.92, 16);

  // ستارهٔ امید در مرکز پایین + آیه
  drawStar8(ctx, cx, 444, 16 + e * 6, b, g * 0.8, true);
  drawVerseCard(
    ctx,
    cx,
    532,
    'يَهْدِي اللَّهُ لِنُورِهِ مَن يَشَاءُ',
    'سوره نور • آیه ۳۵ — هم‌جهت با جریانِ نور بمان',
    a,
    (t - 8) / 2,
    760,
  );
};
