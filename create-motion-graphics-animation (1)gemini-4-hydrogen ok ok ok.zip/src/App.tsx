import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  Clapperboard,
  Clock,
  Copy,
  Download,
  Eye,
  Film,
  Layers,
  Maximize,
  Minimize,
  Pause,
  Play,
  Radio,
  RotateCcw,
  Sparkles,
  Subtitles,
  Volume2,
  VolumeX,
  Wand2,
} from 'lucide-react';
import { cn } from '@/utils/cn';
import ExportPanel from '@/components/ExportPanel';
import { formatTimeFa, toFaDigits } from '@/motion/drawPrimitives';
import {
  ensureFontsReady,
  exportMotionToMp4,
  isWebCodecsSupported,
  type AudioSource,
  type ExportResult,
} from '@/motion/mp4Exporter';
import { drawChapterThumb, drawMotionFrame } from '@/motion/renderer';
import {
  AUDIO_URL,
  CAPTIONS,
  getCaptionAt,
  getChapterAt,
  getChaptersForMode,
  getDurationForMode,
  type EditionMode,
} from '@/motion/timeline';
import type { HostedLink } from '@/motion/uploader';
import { uploadToGofile, uploadToTmpfiles } from '@/motion/uploader';
import { PUBLISHED_15MIN_MP4 } from '@/published';

type Tab = 'export' | 'chapters' | 'captions';

const CANVAS_W = 1280;
const CANVAS_H = 720;

function Chip({
  tone,
  icon,
  text,
}: {
  tone: 'ok' | 'warn' | 'info' | 'gold' | 'muted';
  icon: React.ReactNode;
  text: string;
}) {
  const cls: Record<typeof tone, string> = {
    ok: 'border-emerald-400/35 bg-emerald-400/10 text-emerald-200',
    warn: 'border-amber-400/35 bg-amber-400/10 text-amber-200',
    info: 'border-sky-400/35 bg-sky-400/10 text-sky-200',
    gold: 'border-amber-300/40 bg-amber-300/12 text-amber-100',
    muted: 'border-slate-700/70 bg-slate-900/60 text-slate-300',
  };
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full border px-3 py-1', cls[tone])}>
      {icon}
      <span>{text}</span>
    </span>
  );
}

export default function App() {
  const [mode, setMode] = useState<EditionMode>('15min');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.88);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [showHud, setShowHud] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [tab, setTab] = useState<Tab>('chapters');
  const [audioSource, setAudioSource] = useState<AudioSource>('voice');
  const [narrationOverride, setNarrationOverride] = useState<string | undefined>(undefined);
  const [audioReady, setAudioReady] = useState<'loading' | 'ready' | 'error'>('loading');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [webcodecsOk] = useState(() => isWebCodecsSupported());

  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  const [fps, setFps] = useState(24);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<{
    phase: string;
    percent: number;
    currentFrame: number;
    totalFrames: number;
    elapsedSec: number;
    etaSec: number;
    detail: string;
  } | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportResult, setExportResult] = useState<{ data: ExportResult; url: string } | null>(null);
  const [links, setLinks] = useState<HostedLink[]>([]);
  const [uploading, setUploading] = useState<{ host: string; percent: number } | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const narrationUrl = narrationOverride ?? AUDIO_URL;
  const chapters = useMemo(() => getChaptersForMode(mode), [mode]);
  const totalDur = useMemo(() => getDurationForMode(mode), [mode]);
  const visibleCaptions = useMemo(() => CAPTIONS.filter((c) => c.start < totalDur), [totalDur]);

  const stageWrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioAttachedRef = useRef(false);
  const waveBufRef = useRef<Uint8Array<ArrayBuffer> | null>(null);
  const thumbRefs = useRef<Record<number, HTMLCanvasElement | null>>({});

  const clockRef = useRef(0);
  const playingRef = useRef(false);
  const lastTsRef = useRef(0);
  const uiTsRef = useRef(0);
  const rafRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  const renderOptsRef = useRef({ mode, showSubtitles, showHud, totalDur, audioSource });
  renderOptsRef.current = { mode, showSubtitles, showHud, totalDur, audioSource };

  const chapter = getChapterAt(currentTime, mode);
  const activeCaption = getCaptionAt(currentTime, mode);

  /* ---- بارگذاری فایل صوتی اصلی ---- */
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    setAudioReady('loading');
    a.src = narrationUrl;
    a.load();
    const onOk = () => setAudioReady('ready');
    const onErr = () => setAudioReady('error');
    a.addEventListener('loadedmetadata', onOk);
    a.addEventListener('error', onErr);
    return () => {
      a.removeEventListener('loadedmetadata', onOk);
      a.removeEventListener('error', onErr);
    };
  }, [narrationUrl]);

  /* ---- حلقهٔ اصلی رندر 60fps ---- */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;
    let alive = true;

    const sampleEnergy = (t: number) => {
      const an = analyserRef.current;
      if (an && playingRef.current) {
        if (!waveBufRef.current || waveBufRef.current.length !== an.fftSize) {
          waveBufRef.current = new Uint8Array(new ArrayBuffer(an.fftSize));
        }
        an.getByteTimeDomainData(waveBufRef.current);
        let sum = 0;
        for (let i = 0; i < waveBufRef.current.length; i++) {
          const v = (waveBufRef.current[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / waveBufRef.current.length);
        return Math.max(0.06, Math.min(1, rms * 4.4));
      }
      return 0.22 + 0.09 * Math.sin(t * 2.1) + 0.05 * Math.sin(t * 5.2);
    };

    const loop = (ts: number) => {
      if (!alive) return;
      const prev = lastTsRef.current || ts;
      const dt = Math.min(0.06, (ts - prev) / 1000);
      lastTsRef.current = ts;

      const o = renderOptsRef.current;
      const a = audioRef.current;
      if (playingRef.current) {
        if (a && o.audioSource === 'voice' && !a.paused && Number.isFinite(a.currentTime)) {
          clockRef.current = Math.min(o.totalDur, a.currentTime);
        } else {
          clockRef.current = Math.min(o.totalDur, clockRef.current + dt);
        }
        if (clockRef.current >= o.totalDur) {
          playingRef.current = false;
          setIsPlaying(false);
          a?.pause();
        }
      }

      const energy = sampleEnergy(clockRef.current);
      drawMotionFrame(ctx, clockRef.current, canvas.width, canvas.height, energy, {
        mode: o.mode,
        showSubtitles: o.showSubtitles,
        showHud: o.showHud,
      });

      if (ts - uiTsRef.current > 85) {
        uiTsRef.current = ts;
        setCurrentTime(clockRef.current);
      }
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      alive = false;
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  /* ---- رسم پیش‌نمایشِ تامبنیلِ فصل‌ها ---- */
  useEffect(() => {
    let alive = true;
    void ensureFontsReady().then(() => {
      if (!alive) return;
      chapters.forEach((ch) => {
        const c = thumbRefs.current[ch.id];
        if (!c) return;
        const ctx = c.getContext('2d');
        if (ctx) drawChapterThumb(ctx, ch, mode, c.width, c.height);
      });
    });
    return () => {
      alive = false;
    };
  }, [chapters, mode, tab]);

  const attachAudioAnalyser = useCallback(() => {
    const a = audioRef.current;
    if (!a || audioAttachedRef.current) return;
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current ??= new Ctx();
      const ctx = audioCtxRef.current;
      void ctx.resume();
      const src = ctx.createMediaElementSource(a);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      an.smoothingTimeConstant = 0.76;
      src.connect(an);
      an.connect(ctx.destination);
      analyserRef.current = an;
      audioAttachedRef.current = true;
    } catch {
      audioAttachedRef.current = false;
    }
  }, []);

  const play = useCallback(() => {
    if (clockRef.current >= totalDur - 0.1) clockRef.current = 0;
    playingRef.current = true;
    setIsPlaying(true);
    const a = audioRef.current;
    if (a && audioSource === 'voice') {
      attachAudioAnalyser();
      try {
        a.currentTime = clockRef.current;
      } catch {
        /* noop */
      }
      a.volume = muted ? 0 : volume;
      void a.play().catch(() => undefined);
    }
  }, [totalDur, audioSource, attachAudioAnalyser, muted, volume]);

  const pause = useCallback(() => {
    playingRef.current = false;
    setIsPlaying(false);
    audioRef.current?.pause();
  }, []);

  const togglePlay = useCallback(() => {
    if (playingRef.current) pause();
    else play();
  }, [play, pause]);

  const seek = useCallback(
    (t: number) => {
      const clamped = Math.max(0, Math.min(totalDur, t));
      clockRef.current = clamped;
      setCurrentTime(clamped);
      lastTsRef.current = 0;
      const a = audioRef.current;
      if (a && audioSource === 'voice') {
        try {
          a.currentTime = clamped;
        } catch {
          /* noop */
        }
      }
    },
    [totalDur, audioSource],
  );

  const restart = useCallback(() => {
    seek(0);
    window.setTimeout(() => play(), 35);
  }, [seek, play]);

  useEffect(() => {
    const a = audioRef.current;
    if (a) {
      a.volume = muted ? 0 : volume;
      a.muted = muted;
    }
  }, [volume, muted]);

  useEffect(() => {
    pause();
    clockRef.current = 0;
    setCurrentTime(0);
  }, [mode, pause]);

  useEffect(() => {
    const onFs = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = stageWrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight') {
        seek(clockRef.current - 5);
      } else if (e.code === 'ArrowLeft') {
        seek(clockRef.current + 5);
      } else if (e.key === 's' || e.key === 'S') {
        setShowSubtitles((v) => !v);
      } else if (e.key === 'h' || e.key === 'H') {
        setShowHud((v) => !v);
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, seek, toggleFullscreen]);

  useEffect(() => {
    return () => {
      if (exportResult?.url) URL.revokeObjectURL(exportResult.url);
    };
  }, [exportResult]);

  const startExport = useCallback(async () => {
    if (isExporting) return;
    pause();
    setExportError(null);
    setExportResult((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return null;
    });
    setLinks([]);
    setUploadError(null);
    setIsExporting(true);
    setTab('export');
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const res = await exportMotionToMp4({
        mode,
        audioSource,
        resolution,
        fps,
        showSubtitles,
        showHud,
        narrationUrl,
        signal: ctrl.signal,
        onProgress: (p) => setExportProgress({ ...p }),
        onPreviewCanvas: (c) => {
          const pc = previewRef.current;
          if (!pc) return;
          const ctx = pc.getContext('2d');
          if (!ctx) return;
          ctx.clearRect(0, 0, pc.width, pc.height);
          ctx.drawImage(c, 0, 0, pc.width, pc.height);
        },
      });
      const url = URL.createObjectURL(res.blob);
      setExportResult({ data: res, url });
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        setExportError((err as Error)?.message ?? 'خطای ناشناخته در ساخت ویدیو.');
      } else {
        setExportError('فرایندِ ساخت ویدیو لغو شد.');
      }
    } finally {
      setIsExporting(false);
      setExportProgress(null);
      abortRef.current = null;
    }
  }, [isExporting, pause, mode, audioSource, resolution, fps, showSubtitles, showHud, narrationUrl]);

  const cancelExport = useCallback(() => abortRef.current?.abort(), []);

  const uploadTo = useCallback(
    async (host: 'tmpfiles.org' | 'gofile.io') => {
      if (!exportResult) return;
      setUploadError(null);
      setUploading({ host, percent: 0 });
      try {
        const fn = (p: number) => setUploading({ host, percent: p });
        const link =
          host === 'tmpfiles.org'
            ? await uploadToTmpfiles(exportResult.data.blob, exportResult.data.filename, fn)
            : await uploadToGofile(exportResult.data.blob, exportResult.data.filename, fn);
        setLinks((prev) => [...prev.filter((l) => l.host !== host), link]);
      } catch (err) {
        setUploadError((err as Error)?.message ?? 'آپلود ناموفق بود.');
      } finally {
        setUploading(null);
      }
    },
    [exportResult],
  );

  const pickAudioFile = useCallback((file: File) => {
    setNarrationOverride(URL.createObjectURL(file));
  }, []);

  const copyPublished = useCallback(async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      window.setTimeout(() => setCopiedUrl(null), 1800);
    } catch {
      /* noop */
    }
  }, []);

  const playFraction = currentTime / totalDur;
  const chapterFraction = (currentTime - chapter.start) / Math.max(0.001, chapter.end - chapter.start);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-studio text-slate-100">
      {/* لایه‌های محیطی پس‌زمینه */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="bg-grid-fine absolute inset-0 opacity-70" />
        <div className="animate-drift-slow absolute -left-40 top-10 h-[520px] w-[520px] rounded-full border border-amber-400/10" />
        <div
          className="animate-drift-slow absolute -right-32 bottom-0 h-[620px] w-[620px] rounded-full border border-sky-400/10"
          style={{ animationDuration: '88s', animationDirection: 'reverse' }}
        />
        <div className="absolute left-[12%] top-[18%] h-40 w-40 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="absolute right-[8%] top-[46%] h-52 w-52 rounded-full bg-sky-500/10 blur-3xl" />
        <div className="absolute bottom-[6%] left-[42%] h-44 w-44 rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      <audio ref={audioRef} crossOrigin="anonymous" preload="auto" className="hidden" />

      {/* هدر */}
      <header className="relative z-10 border-b border-slate-800/60 bg-[#05070f]/75 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-4 px-4 py-5 lg:px-8">
          <div className="flex items-center gap-4">
            <div className="relative grid h-14 w-14 place-items-center rounded-2xl border border-amber-400/30 bg-gradient-to-b from-amber-400/15 to-transparent">
              <Clapperboard className="h-7 w-7 text-amber-300" />
              <span className="animate-pulse-soft absolute inset-0 rounded-2xl border border-amber-300/25" />
            </div>
            <div>
              <h1 className="font-display text-[26px] leading-tight font-bold text-amber-200 drop-shadow-[0_0_18px_rgba(251,191,36,0.35)] sm:text-[32px]">
                جریانِ نور؛ صراطِ مستقیم و تسلیم
              </h1>
              <p className="text-[12.5px] font-medium text-slate-400 sm:text-[13.5px]">
                استودیوی موشن گرافیکِ المان‌محور • ۱۵ دقیقه‌ای و روایتِ کامل • خروجیِ MP4 و لینکِ دانلودِ عمومی
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11.5px] font-bold">
            <Chip
              tone={webcodecsOk ? 'ok' : 'warn'}
              icon={<Wand2 className="h-3.5 w-3.5" />}
              text={webcodecsOk ? 'WebCodecs فعال' : 'خروجی آمادهٔ MP4'}
            />
            <Chip
              tone="info"
              icon={<Layers className="h-3.5 w-3.5" />}
              text={`${toFaDigits(chapters.length)} صحنهٔ المان‌محور`}
            />
            <Chip tone="gold" icon={<Clock className="h-3.5 w-3.5" />} text={formatTimeFa(totalDur)} />
            <Chip
              tone={audioReady === 'ready' ? 'ok' : 'muted'}
              icon={<Radio className="h-3.5 w-3.5" />}
              text={
                audioReady === 'ready'
                  ? 'صدای اصلی آماده'
                  : audioReady === 'error'
                    ? 'پخش بصری (آپلود صوت)'
                    : 'بارگذاری صدا…'
              }
            />
          </div>
        </div>
      </header>

      {/* بدنه اصلی */}
      <main className="relative z-10 mx-auto grid max-w-[1600px] gap-5 px-4 py-6 lg:grid-cols-[minmax(0,1fr)_390px] lg:px-8">
        {/* ستون اصلی صحنه */}
        <section className="flex flex-col gap-4">
          {/* کارت لینک‌های مستقیم دانلود MP4 از پیش رندرشده */}
          <div className="animate-rise rounded-2xl border border-emerald-500/45 bg-gradient-to-l from-emerald-500/15 via-emerald-500/5 to-transparent p-4 shadow-[0_0_45px_-20px_rgba(16,185,129,0.75)]">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-[14px] font-black text-emerald-200">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                فایل MP4 پانزده دقیقه‌ای آمادهٔ دانلود است (720p HD • H.264 + AAC • صدای اصلی • 66 MB)
              </div>
              <span className="rounded-full border border-emerald-400/40 bg-emerald-950/70 px-2.5 py-0.5 text-[11px] font-bold text-emerald-300">
                ۱۵:۰۰ دقیق • ۱۵ فصل
              </span>
            </div>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {PUBLISHED_15MIN_MP4.map((lk) => (
                <div
                  key={lk.url}
                  className="group flex items-center justify-between gap-3 rounded-xl border border-slate-700/70 bg-slate-950/70 px-3.5 py-3 transition hover:border-emerald-400/60 hover:bg-emerald-500/10"
                >
                  <a
                    href={lk.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="min-w-0 flex-1"
                  >
                    <span className="flex items-center gap-1.5 text-[13px] font-extrabold text-slate-100">
                      <Download className="h-3.5 w-3.5 text-emerald-400" />
                      دانلود از {lk.host}
                    </span>
                    <span className="mt-0.5 block truncate text-[11px] text-emerald-300/90 dir-ltr">
                      {lk.url}
                    </span>
                    <span className="mt-0.5 block text-[10.5px] text-slate-400">{lk.note}</span>
                  </a>
                  <div className="flex shrink-0 flex-col items-end gap-1.5">
                    <button
                      type="button"
                      onClick={() => void copyPublished(lk.url)}
                      className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1 text-[11px] font-bold text-slate-300 hover:border-amber-400/50 hover:text-amber-200"
                    >
                      <Copy className="h-3 w-3" />
                      {copiedUrl === lk.url ? 'کپی شد' : 'کپی'}
                    </button>
                    <a
                      href={lk.url}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="flex items-center gap-1 text-[11px] font-bold text-emerald-300 group-hover:text-emerald-200"
                    >
                      باز کردن
                      <ChevronLeft className="h-3.5 w-3.5 transition group-hover:-translate-x-0.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* انتخاب نسخه ۱۵ دقیقه‌ای یا روایت کامل ۲۸:۳۵ */}
          <div className="grid gap-3 sm:grid-cols-2">
            {(
              [
                {
                  id: '15min',
                  n: 'نسخهٔ ۱۵ دقیقه‌ای • ۱۵ فصل',
                  s: '۰۰:۰۰ تا ۱۵:۰۰ • همگام با فایل MP4 آمادهٔ دانلود',
                  c: '#fbbf24',
                },
                {
                  id: 'full',
                  n: 'نسخهٔ کاملِ روایت • ۲۲ فصل',
                  s: 'تمامِ ۲۸:۳۵ صوت (تا حضرت سلیمان و راه رفتن روی آب)',
                  c: '#38bdf8',
                },
              ] as const
            ).map((ed) => {
              const active = mode === ed.id;
              return (
                <button
                  key={ed.id}
                  type="button"
                  onClick={() => setMode(ed.id)}
                  className={cn(
                    'group relative overflow-hidden rounded-2xl border p-3.5 text-right transition-all duration-300',
                    active
                      ? 'border-amber-400/60 bg-gradient-to-l from-amber-400/15 to-transparent shadow-[0_0_38px_-16px_rgba(251,191,36,0.85)]'
                      : 'border-slate-800 bg-[#080c1a]/70 hover:-translate-y-0.5 hover:border-slate-600',
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-[#0a0d18]"
                      style={{ background: ed.c, boxShadow: active ? `0 0 22px -4px ${ed.c}` : 'none' }}
                    >
                      <Film className="h-5 w-5" />
                    </span>
                    <div className="min-w-0">
                      <div className={cn('text-[14px] font-black', active ? 'text-amber-100' : 'text-slate-200')}>
                        {ed.n}
                      </div>
                      <div className="truncate text-[11.5px] text-slate-400">{ed.s}</div>
                    </div>
                    {active ? <CheckCircle2 className="mr-auto h-5 w-5 shrink-0 text-amber-300" /> : null}
                  </div>
                </button>
              );
            })}
          </div>

          {/* نوار فصل جاری */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800/70 bg-[#080c1a]/75 px-4 py-3 backdrop-blur">
            <div className="flex items-center gap-3">
              <span
                className="grid h-9 w-9 place-items-center rounded-xl text-[13px] font-black text-[#0a0d18]"
                style={{ background: chapter.accent, boxShadow: `0 0 26px -6px ${chapter.accent}` }}
              >
                {toFaDigits(chapter.id)}
              </span>
              <div>
                <div className="text-[14.5px] font-extrabold text-slate-100">{chapter.title}</div>
                <div className="text-[11.5px] text-slate-400">{chapter.subtitle}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-left">
                <div className="font-display text-[15px] text-amber-200/95">{chapter.verseAr}</div>
                <div className="text-[10.5px] text-slate-500">{chapter.verseRef}</div>
              </div>
              <div className="h-2.5 w-24 overflow-hidden rounded-full bg-slate-900">
                <div
                  className="h-full rounded-full transition-[width] duration-150"
                  style={{ width: `${Math.min(100, Math.max(0, chapterFraction * 100))}%`, background: chapter.accent }}
                />
              </div>
            </div>
          </div>

          {/* صحنه سینمایی 16:9 */}
          <div
            ref={stageWrapRef}
            className="relative overflow-hidden rounded-[22px] border border-slate-800/80 bg-black"
          >
            <div className="relative aspect-video w-full">
              <canvas
                ref={canvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                onClick={togglePlay}
                className="stage-canvas h-full w-full cursor-pointer rounded-[21px]"
              />
              {/* کرنرهای سینمایی */}
              <div className="pointer-events-none absolute inset-0">
                {[
                  'right-3 top-3 border-r-2 border-t-2',
                  'left-3 top-3 border-l-2 border-t-2',
                  'right-3 bottom-3 border-r-2 border-b-2',
                  'left-3 bottom-3 border-l-2 border-b-2',
                ].map((pos, i) => (
                  <span key={i} className={cn('absolute h-4 w-4 border-amber-300/35', pos)} />
                ))}
              </div>
              {/* دکمه پخش مرکزی در حالت توقف */}
              {!isPlaying ? (
                <button
                  type="button"
                  onClick={togglePlay}
                  aria-label="پخش موشن گرافیک"
                  className="group absolute inset-0 m-auto grid h-20 w-20 place-items-center rounded-full border border-amber-300/50 bg-[#05070f]/75 text-amber-200 shadow-[0_0_50px_-6px_rgba(251,191,36,0.8)] backdrop-blur-md transition hover:scale-105 hover:bg-amber-400 hover:text-[#181005]"
                >
                  <Play className="h-9 w-9 fill-current pr-0.5" />
                </button>
              ) : null}
            </div>

            {/* کنترل‌های پخش و تایم‌لاین */}
            <div className="border-t border-slate-800/80 bg-[#070b17]/95 px-4 py-3.5 backdrop-blur">
              {/* نوار زمان با خط‌کش فصل‌ها */}
              <div className="relative mb-3 flex items-center">
                <div className="relative h-2 w-full overflow-hidden rounded-full bg-slate-800/90">
                  <div
                    className="h-full rounded-full transition-[width] duration-75"
                    style={{
                      width: `${playFraction * 100}%`,
                      background: `linear-gradient(270deg, ${chapter.accent}, ${chapter.accentSecondary})`,
                    }}
                  />
                  {chapters.map((c) => (
                    <span
                      key={c.id}
                      style={{ right: `${(c.start / totalDur) * 100}%` }}
                      className="pointer-events-none absolute top-0 h-full w-[2px] bg-[#05070f]/90"
                    />
                  ))}
                </div>
                <input
                  type="range"
                  min={0}
                  max={totalDur}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => seek(Number(e.target.value))}
                  aria-label="زمانِ پخش"
                  className="seek absolute inset-0 h-full w-full cursor-pointer"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="flex items-center gap-1.5 rounded-xl bg-amber-400 px-4 py-2 text-[13px] font-black text-[#181005] shadow-[0_8px_26px_-10px_rgba(251,191,36,0.9)] transition hover:bg-amber-300"
                  >
                    {isPlaying ? <Pause className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 fill-current" />}
                    {isPlaying ? 'توقف' : 'پخش'}
                  </button>
                  <button
                    type="button"
                    onClick={restart}
                    title="از ابتدا"
                    className="grid h-9 w-9 place-items-center rounded-xl border border-slate-700/80 bg-slate-900/70 text-slate-300 transition hover:border-amber-400/50 hover:text-amber-200"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>
                  <span className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-1.5 font-mono text-[12.5px] font-bold text-slate-200">
                    {formatTimeFa(currentTime)} / {formatTimeFa(totalDur)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* کنترل صدا */}
                  <button
                    type="button"
                    onClick={() => setMuted((m) => !m)}
                    title={muted ? 'وصل صدا' : 'بی‌صدا'}
                    className="grid h-9 w-9 place-items-center rounded-xl border border-slate-700/80 bg-slate-900/70 text-slate-300 hover:border-amber-400/50 hover:text-amber-200"
                  >
                    {muted ? <VolumeX className="h-4 w-4 text-rose-400" /> : <Volume2 className="h-4 w-4" />}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={muted ? 0 : volume}
                    onChange={(e) => {
                      setMuted(false);
                      setVolume(Number(e.target.value));
                    }}
                    className="vol hidden w-20 sm:block"
                    aria-label="بلندی صدا"
                  />

                  <button
                    type="button"
                    onClick={() => setShowSubtitles((v) => !v)}
                    title="زیرنویس (S)"
                    className={cn(
                      'grid h-9 w-9 place-items-center rounded-xl border transition',
                      showSubtitles
                        ? 'border-amber-400/50 bg-amber-400/15 text-amber-200'
                        : 'border-slate-700/80 bg-slate-900/70 text-slate-400',
                    )}
                  >
                    <Subtitles className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowHud((v) => !v)}
                    title="نوار اطلاعات (H)"
                    className={cn(
                      'grid h-9 w-9 place-items-center rounded-xl border transition',
                      showHud
                        ? 'border-amber-400/50 bg-amber-400/15 text-amber-200'
                        : 'border-slate-700/80 bg-slate-900/70 text-slate-400',
                    )}
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={toggleFullscreen}
                    title="تمام‌صفحه (F)"
                    className="grid h-9 w-9 place-items-center rounded-xl border border-slate-700/80 bg-slate-900/70 text-slate-300 hover:border-amber-400/50 hover:text-amber-200"
                  >
                    {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* راهنمای کلیدهای میانبر */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-slate-800/60 bg-[#080c1a]/60 px-4 py-2.5 text-[11.5px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              المان‌های هر فصل به‌صورت زنده به انرژیِ صدای گوینده واکنش نشان می‌دهند.
            </span>
            <span className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
              <span>Space: پخش/توقف</span>•<span>←/→: جابه‌جایی ۵ ثانیه</span>•<span>S: زیرنویس</span>•<span>F: تمام‌صفحه</span>
            </span>
          </div>
        </section>

        {/* ستون کناری استودیو (فصل‌ها / زیرنویس / خروجی MP4) */}
        <aside className="flex flex-col gap-4">
          <div className="flex gap-1.5 rounded-2xl border border-slate-800/80 bg-[#080c1a]/90 p-1.5">
            {(
              [
                { id: 'chapters', label: `فصل‌ها (${toFaDigits(chapters.length)})` },
                { id: 'captions', label: 'متن و زمان‌بندی' },
                { id: 'export', label: 'خروجی MP4' },
              ] as const
            ).map((tItem) => (
              <button
                key={tItem.id}
                type="button"
                onClick={() => setTab(tItem.id)}
                className={cn(
                  'flex-1 rounded-xl px-3 py-2.5 text-[12.5px] font-extrabold transition',
                  tab === tItem.id
                    ? 'bg-gradient-to-b from-amber-300 to-amber-500 text-[#1b1206] shadow-[0_6px_24px_-8px_rgba(251,191,36,0.9)]'
                    : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-100',
                )}
              >
                {tItem.label}
              </button>
            ))}
          </div>

          {tab === 'chapters' ? (
            <div className="rail flex max-h-[760px] flex-col gap-2.5 overflow-y-auto pl-1">
              {chapters.map((c) => {
                const active = c.id === chapter.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      seek(c.start + 0.1);
                      if (!isPlaying) play();
                    }}
                    className={cn(
                      'group flex items-center gap-3 rounded-2xl border p-2.5 text-right transition-all duration-200',
                      active
                        ? 'border-amber-400/60 bg-amber-400/12 shadow-[0_0_28px_-14px_rgba(251,191,36,0.8)]'
                        : 'border-slate-800/80 bg-[#080c1a]/75 hover:border-slate-600 hover:bg-slate-900/75',
                    )}
                  >
                    <canvas
                      ref={(el) => {
                        thumbRefs.current[c.id] = el;
                      }}
                      width={160}
                      height={90}
                      className="h-[58px] w-[104px] shrink-0 rounded-xl border border-slate-700/70 bg-[#05070f] object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className="rounded-md px-1.5 py-0.5 text-[10.5px] font-black text-[#090d19]"
                          style={{ background: c.accent }}
                        >
                          {c.badge}
                        </span>
                        <span className="font-mono text-[11px] text-slate-400">
                          {formatTimeFa(c.start)} – {formatTimeFa(c.end)}
                        </span>
                      </div>
                      <div className="mt-1 truncate text-[13px] font-extrabold text-slate-100">
                        {c.title}
                      </div>
                      <div className="truncate text-[11px] text-slate-400">{c.subtitle}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : null}

          {tab === 'captions' ? (
            <div className="rail flex max-h-[760px] flex-col gap-2 overflow-y-auto pl-1">
              {visibleCaptions.map((cue, idx) => {
                const active = cue === activeCaption;
                return (
                  <button
                    key={`${cue.start}-${idx}`}
                    type="button"
                    onClick={() => {
                      seek(cue.start + 0.05);
                      if (!isPlaying) play();
                    }}
                    className={cn(
                      'rounded-xl border p-3 text-right transition',
                      active
                        ? 'border-amber-400/60 bg-amber-400/12 text-amber-100'
                        : 'border-slate-800/75 bg-[#080c1a]/70 text-slate-300 hover:border-slate-600',
                    )}
                  >
                    <div className="mb-1 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="font-mono">
                        {formatTimeFa(cue.start)} → {formatTimeFa(cue.end)}
                      </span>
                      {cue.highlight ? (
                        <span className="rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
                          نکتهٔ کلیدی
                        </span>
                      ) : null}
                    </div>
                    <p className="text-[12.5px] leading-6 font-medium">{cue.text}</p>
                  </button>
                );
              })}
            </div>
          ) : null}

          {tab === 'export' ? (
            <div className="flex flex-col gap-3">
              {isExporting ? (
                <div className="overflow-hidden rounded-2xl border border-amber-400/30 bg-black p-2">
                  <div className="mb-1.5 flex items-center justify-between px-1 text-[11px] font-bold text-amber-300">
                    <span className="flex items-center gap-1.5">
                      <span className="animate-rec h-2 w-2 rounded-full bg-rose-500" />
                      پیش‌نمایشِ زندهٔ رندر
                    </span>
                    <span>
                      {resolution} • {fps}fps
                    </span>
                  </div>
                  <canvas ref={previewRef} width={360} height={202} className="w-full rounded-xl" />
                </div>
              ) : null}
              <ExportPanel
                mode={mode}
                setMode={setMode}
                audioSource={audioSource}
                setAudioSource={setAudioSource}
                resolution={resolution}
                setResolution={setResolution}
                fps={fps}
                setFps={setFps}
                showSubtitles={showSubtitles}
                setShowSubtitles={setShowSubtitles}
                showHud={showHud}
                setShowHud={setShowHud}
                webcodecsOk={webcodecsOk}
                narrationUrl={narrationUrl}
                onPickAudioFile={pickAudioFile}
                isExporting={isExporting}
                startExport={startExport}
                cancelExport={cancelExport}
                progress={exportProgress}
                error={exportError}
                result={exportResult}
                links={links}
                uploading={uploading}
                uploadError={uploadError}
                uploadTo={uploadTo}
              />
            </div>
          ) : null}
        </aside>
      </main>
    </div>
  );
}
