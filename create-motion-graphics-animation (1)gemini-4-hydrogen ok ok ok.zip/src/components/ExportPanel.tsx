import { useCallback, useRef, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FileVideo,
  Film,
  LoaderCircle,
  Music,
  Sparkles,
  Upload,
  XCircle,
  Zap,
} from 'lucide-react';
import { cn } from '@/utils/cn';
import type { AudioSource, ExportResult } from '@/motion/mp4Exporter';
import type { EditionMode } from '@/motion/timeline';
import type { HostedLink } from '@/motion/uploader';

interface Props {
  mode: EditionMode;
  setMode: (m: EditionMode) => void;
  audioSource: AudioSource;
  setAudioSource: (a: AudioSource) => void;
  resolution: '720p' | '1080p';
  setResolution: (r: '720p' | '1080p') => void;
  fps: number;
  setFps: (f: number) => void;
  showSubtitles: boolean;
  setShowSubtitles: (v: boolean) => void;
  showHud: boolean;
  setShowHud: (v: boolean) => void;
  webcodecsOk: boolean;
  narrationUrl: string;
  onPickAudioFile: (file: File) => void;
  isExporting: boolean;
  startExport: () => void;
  cancelExport: () => void;
  progress: {
    phase: string;
    percent: number;
    currentFrame: number;
    totalFrames: number;
    elapsedSec: number;
    etaSec: number;
    detail: string;
  } | null;
  error: string | null;
  result: { data: ExportResult; url: string } | null;
  links: HostedLink[];
  uploading: { host: string; percent: number } | null;
  uploadError: string | null;
  uploadTo: (host: 'tmpfiles.org' | 'gofile.io') => void;
}

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function mb(bytes: number) {
  return (bytes / 1048576).toFixed(1);
}

const PHASE_FA: Record<string, string> = {
  preparing: 'آماده‌سازی',
  audio_build: 'پردازش صدا',
  encoding_audio: 'رمزگذاری صدا',
  rendering_video: 'رندر فریم‌ها',
  finalizing: 'نهایی‌سازی MP4',
};

function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className={cn(
        'group flex w-full items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-right transition-all duration-300',
        on
          ? 'border-amber-400/45 bg-amber-400/10 text-amber-100 shadow-[0_0_24px_-12px_rgba(251,191,36,0.8)]'
          : 'border-slate-700/60 bg-slate-900/40 text-slate-400 hover:border-slate-500/70 hover:text-slate-200',
      )}
    >
      <span className="text-[13px] font-semibold">{label}</span>
      <span
        className={cn(
          'relative h-5 w-9 shrink-0 rounded-full transition-colors duration-300',
          on ? 'bg-amber-400/80' : 'bg-slate-700/70',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-300',
            on ? 'right-0.5' : 'right-4',
          )}
        />
      </span>
    </button>
  );
}

function SegBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex-1 rounded-lg px-2.5 py-2 text-[12.5px] font-bold transition-all duration-300',
        active
          ? 'bg-gradient-to-b from-amber-300 to-amber-500 text-[#20160a] shadow-[0_6px_22px_-8px_rgba(251,191,36,0.9)]'
          : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-100',
      )}
    >
      {children}
    </button>
  );
}

export default function ExportPanel(p: Props) {
  const [copied, setCopied] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const copy = useCallback(async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1800);
    } catch {
      /* noop */
    }
  }, []);

  return (
    <div className="flex flex-col gap-4">
      {/* نسخه ویدیو */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold tracking-tight text-slate-200">
          <Film className="h-4 w-4 text-amber-400" />
          نسخهٔ خروجی MP4
        </h3>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          <SegBtn active={p.mode === '15min'} onClick={() => p.setMode('15min')}>
            ۱۵ دقیقه • ۱۵ فصل
          </SegBtn>
          <SegBtn active={p.mode === 'full'} onClick={() => p.setMode('full')}>
            روایتِ کامل • ۲۸:۳۵
          </SegBtn>
        </div>
        <p className="mt-2 text-[11.5px] leading-6 text-slate-400">
          {p.mode === '15min'
            ? 'نسخهٔ ۱۵ دقیقه‌ای دقیق (۹۰۰ ثانیه) با ۱۵ صحنهٔ المان‌محور روی صدای اصلی و فیدآوتِ نرم.'
            : 'تمامِ ۲۸:۳۵ فایلِ صوتی با ۲۲ صحنهٔ اختصاصی (تا حضرتِ سلیمان، رادیوی قرآن و راه رفتن روی آب).'}
        </p>
      </section>

      {/* باند صوتی */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold text-slate-200">
          <Music className="h-4 w-4 text-sky-400" />
          باندِ صوتیِ خروجی
        </h3>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          <SegBtn active={p.audioSource === 'voice'} onClick={() => p.setAudioSource('voice')}>
            صدای اصلیِ روایت
          </SegBtn>
          <SegBtn active={p.audioSource === 'none'} onClick={() => p.setAudioSource('none')}>
            بی‌صدا
          </SegBtn>
        </div>
        <div className="mt-3 space-y-2">
          <div className="truncate rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-[11px] text-slate-400 dir-ltr">
            {p.narrationUrl}
          </div>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="w-full rounded-lg border border-dashed border-slate-700 px-3 py-2 text-[11.5px] font-semibold text-slate-400 transition hover:border-sky-500/60 hover:text-sky-300"
          >
            یا فایلِ صوتیِ دلخواه را از دستگاه انتخاب کنید (ogg / mp3 / m4a)
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) p.onPickAudioFile(f);
              e.target.value = '';
            }}
          />
        </div>
      </section>

      {/* کیفیت و کدک */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold text-slate-200">
          <Zap className="h-4 w-4 text-emerald-400" />
          کیفیت و تنظیماتِ تصویر
        </h3>
        <div className="mb-2 flex gap-2 rounded-xl bg-slate-900/70 p-1">
          <SegBtn active={p.resolution === '720p'} onClick={() => p.setResolution('720p')}>
            720p • سبک
          </SegBtn>
          <SegBtn active={p.resolution === '1080p'} onClick={() => p.setResolution('1080p')}>
            1080p • سینمایی
          </SegBtn>
        </div>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          {[24, 30, 60].map((f) => (
            <SegBtn key={f} active={p.fps === f} onClick={() => p.setFps(f)}>
              {f} fps
            </SegBtn>
          ))}
        </div>
        <div className="mt-3 grid gap-2">
          <Toggle on={p.showSubtitles} onChange={p.setShowSubtitles} label="زیرنویسِ فارسی همگام" />
          <Toggle on={p.showHud} onChange={p.setShowHud} label="هدرِ فصل و نوارِ زمان" />
        </div>
      </section>

      {/* دکمه ساخت MP4 در مرورگر */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        {!p.webcodecsOk ? (
          <div className="mb-3 flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-[11.5px] leading-6 text-amber-200">
            <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              مرورگرِ شما WebCodecs ندارد؛ از لینک‌های آمادهٔ بالای صفحه استفاده کنید یا با Chrome/Edge خروجی سفارشی بسازید.
            </span>
          </div>
        ) : null}

        {!p.isExporting ? (
          <button
            type="button"
            disabled={!p.webcodecsOk}
            onClick={p.startExport}
            className={cn(
              'relative w-full overflow-hidden rounded-xl px-4 py-3.5 text-[14.5px] font-black tracking-tight transition-all duration-300',
              p.webcodecsOk
                ? 'bg-gradient-to-l from-amber-300 via-amber-400 to-amber-500 text-[#1b1206] shadow-[0_12px_36px_-12px_rgba(251,191,36,0.9)] hover:brightness-110 active:scale-[0.99]'
                : 'cursor-not-allowed bg-slate-800 text-slate-500',
            )}
          >
            <span className="sheen pointer-events-none absolute inset-0 opacity-60" />
            <span className="relative flex items-center justify-center gap-2">
              <Sparkles className="h-4 w-4" />
              ساختِ نسخهٔ سفارشی MP4 در مرورگر
            </span>
          </button>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-[12px]">
              <span className="flex items-center gap-2 font-extrabold text-amber-300">
                <LoaderCircle className="h-4 w-4 animate-spin" />
                {PHASE_FA[p.progress?.phase ?? 'preparing'] ?? 'در حال پردازش'}
              </span>
              <span className="font-mono font-bold text-slate-200">
                {(p.progress?.percent ?? 0).toFixed(1)}٪
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full rounded-full bg-gradient-to-l from-amber-300 to-emerald-400 transition-all duration-200"
                style={{ width: `${Math.min(100, p.progress?.percent ?? 0)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>{p.progress?.detail}</span>
              <span>باقی‌مانده: {fmt(p.progress?.etaSec ?? 0)}</span>
            </div>
            <button
              type="button"
              onClick={p.cancelExport}
              className="w-full rounded-lg border border-rose-500/40 bg-rose-500/10 py-2 text-[12px] font-bold text-rose-300 hover:bg-rose-500/20"
            >
              توقف و لغوِ رندر
            </button>
          </div>
        )}

        {p.error ? (
          <div className="mt-3 rounded-xl border border-rose-500/40 bg-rose-500/10 p-3 text-[12px] leading-6 text-rose-200">
            {p.error}
          </div>
        ) : null}

        {p.result ? (
          <div className="mt-4 space-y-3 rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3.5">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-[13px] font-extrabold text-emerald-200">
                <CheckCircle2 className="h-4 w-4" />
                فایل MP4 آماده شد!
              </span>
              <span className="rounded-md bg-emerald-950/80 px-2 py-0.5 text-[11px] font-bold text-emerald-300">
                {mb(p.result.data.sizeBytes)} MB
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-300">
              <FileVideo className="h-3.5 w-3.5 text-emerald-400" />
              <span>
                {p.result.data.width}×{p.result.data.height} • {p.result.data.fps}fps • {p.result.data.codecLabel}
              </span>
            </div>

            <a
              href={p.result.url}
              download={p.result.data.filename}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 px-3 py-2.5 text-[13px] font-black text-emerald-950 transition hover:bg-emerald-300"
            >
              <Download className="h-4 w-4" />
              دانلودِ مستقیمِ فایل MP4
            </a>

            <div className="grid grid-cols-2 gap-2">
              {(['tmpfiles.org', 'gofile.io'] as const).map((host) => (
                <button
                  key={host}
                  type="button"
                  disabled={Boolean(p.uploading)}
                  onClick={() => p.uploadTo(host)}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/70 px-2.5 py-2 text-[11.5px] font-bold text-slate-200 transition hover:border-amber-400/60 hover:text-amber-200 disabled:opacity-50"
                >
                  <Upload className="h-3.5 w-3.5" />
                  آپلود {host}
                </button>
              ))}
            </div>

            {p.uploading ? (
              <div className="text-center text-[11.5px] font-bold text-amber-300">
                در حال آپلود به {p.uploading.host}… {p.uploading.percent.toFixed(0)}٪
              </div>
            ) : null}

            {p.uploadError ? (
              <div className="rounded-lg border border-rose-500/35 bg-rose-500/10 p-2 text-[11.5px] text-rose-200">
                {p.uploadError}
              </div>
            ) : null}

            {p.links.map((lk) => (
              <div
                key={lk.host}
                className="space-y-1.5 rounded-xl border border-slate-700/70 bg-slate-950/75 p-2.5"
              >
                <div className="flex items-center justify-between text-[12px] font-bold text-amber-200">
                  <span>{lk.host}</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void copy(lk.pageUrl, lk.host)}
                      className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white"
                    >
                      <Copy className="h-3 w-3" />
                      {copied === lk.host ? 'کپی شد!' : 'کپی'}
                    </button>
                    <a
                      href={lk.pageUrl}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="flex items-center gap-1 text-[11px] text-emerald-300 hover:text-emerald-200"
                    >
                      باز کردن
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
                <div className="truncate text-[10.5px] text-slate-400 dir-ltr">{lk.pageUrl}</div>
                <div className="text-[10.5px] text-slate-500">{lk.note}</div>
              </div>
            ))}
          </div>
        ) : null}
      </section>
    </div>
  );
}
